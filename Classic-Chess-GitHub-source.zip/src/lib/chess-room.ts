import type { PieceTone } from '@/constants/chess';

export type OnlineProfile = {
  name: string;
  pieceTone: PieceTone;
  accentColor: string;
  showName: boolean;
};

export type RoomPreview = {
  host_name: string;
  host_piece_tone: PieceTone;
  host_accent_color: string;
  host_show_name: boolean;
  expires_at: string | null;
};

export type ChessRoom = {
  id: string;
  invite_code: string;
  host_id: string;
  guest_id: string | null;
  host_name: string;
  guest_name: string | null;
  host_piece_tone: PieceTone;
  guest_piece_tone: PieceTone;
  host_accent_color: string;
  guest_accent_color: string;
  host_show_name: boolean;
  guest_show_name: boolean;
  moves: string[];
  ply: number;
  status: 'waiting' | 'active' | 'finished';
  created_at: string;
  expires_at: string;
};

type ProfileFields = { name: string; pieceTone: PieceTone; accentColor: string; showName: boolean };
type RoomRequest =
  | ({ action: 'create' | 'join' } & ProfileFields & { code?: string })
  | { action: 'preview'; code: string }
  | { action: 'move'; roomId: string; move: string };

export function isChessRoom(value: unknown): value is ChessRoom {
  if (!value || typeof value !== 'object') return false;
  const room = value as Record<string, unknown>;
  return typeof room.id === 'string'
    && typeof room.invite_code === 'string'
    && /^[A-HJ-NP-Z2-9]{8}$/.test(room.invite_code)
    && typeof room.host_id === 'string'
    && (typeof room.guest_id === 'string' || room.guest_id === null)
    && typeof room.host_name === 'string'
    && (typeof room.guest_name === 'string' || room.guest_name === null)
    && ['pearl', 'silver', 'gold'].includes(String(room.host_piece_tone))
    && ['onyx', 'emerald', 'sapphire'].includes(String(room.guest_piece_tone))
    && typeof room.host_accent_color === 'string'
    && /^#[0-9a-f]{6}$/i.test(room.host_accent_color)
    && typeof room.guest_accent_color === 'string'
    && /^#[0-9a-f]{6}$/i.test(room.guest_accent_color)
    && typeof room.host_show_name === 'boolean'
    && typeof room.guest_show_name === 'boolean'
    && Array.isArray(room.moves)
    && room.moves.every((move) => typeof move === 'string')
    && Number.isInteger(room.ply)
    && room.ply === room.moves.length
    && (room.status === 'waiting' || room.status === 'active' || room.status === 'finished')
    && typeof room.created_at === 'string'
    && Number.isFinite(Date.parse(room.created_at))
    && (room.expires_at === null || typeof room.expires_at === 'string' && Number.isFinite(Date.parse(room.expires_at)));
}

function isRoomPreview(value: unknown): value is RoomPreview {
  if (!value || typeof value !== 'object') return false;
  const preview = value as Record<string, unknown>;
  return typeof preview.host_name === 'string'
    && preview.host_name.length > 0
    && ['pearl', 'silver', 'gold'].includes(String(preview.host_piece_tone))
    && typeof preview.host_accent_color === 'string'
    && /^#[0-9a-f]{6}$/i.test(preview.host_accent_color)
    && typeof preview.host_show_name === 'boolean'
    && typeof preview.expires_at === 'string'
    && Number.isFinite(Date.parse(preview.expires_at));
}

async function invokeChessRoom(
  supabase: import('@supabase/supabase-js').SupabaseClient,
  body: RoomRequest,
) {
  const { data, error } = await supabase.functions.invoke('chess-room', { body });
  if (error) {
    const context = error.context;
    if (context instanceof Response) {
      try {
        const payload = await context.clone().json() as { error?: string };
        if (payload.error) throw new Error(payload.error);
      } catch (parseError) {
        if (parseError instanceof Error && parseError.message !== 'Unexpected end of JSON input') throw parseError;
      }
    }
    throw new Error(error.message || 'The online match request failed.');
  }
  return data as unknown;
}

export async function previewChessRoom(
  supabase: import('@supabase/supabase-js').SupabaseClient,
  code: string,
): Promise<RoomPreview> {
  const data = await invokeChessRoom(supabase, { action: 'preview', code });
  if (!data || typeof data !== 'object' || !('preview' in data) || !isRoomPreview(data.preview)) {
    throw new Error('The room preview response was invalid. Please ask for a new invite.');
  }
  return data.preview;
}

export async function callChessRoom(
  supabase: import('@supabase/supabase-js').SupabaseClient,
  body: RoomRequest,
): Promise<ChessRoom> {
  if (body.action === 'preview') throw new Error('Use previewChessRoom to inspect a room.');
  const data = await invokeChessRoom(supabase, body);
  if (!data || typeof data !== 'object' || !('room' in data) || !isChessRoom(data.room)) {
    throw new Error('The online match server returned an invalid response.');
  }
  return data.room;
}
