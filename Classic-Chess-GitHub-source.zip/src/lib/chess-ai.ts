import { Chess, type Move } from 'chess.js';

import type { ComputerLevel } from '@/constants/chess';

const profiles: Record<ComputerLevel, { depth: number; nodes: number }> = {
  mature: { depth: 1, nodes: 5_000 },
  casual: { depth: 2, nodes: 14_000 },
  classic: { depth: 3, nodes: 30_000 },
  professional: { depth: 4, nodes: 55_000 },
};
const pieceValue: Record<string, number> = { p: 100, n: 320, b: 335, r: 500, q: 900, k: 20_000 };
const files = 'abcdefgh';

function evaluate(chess: Chess) {
  if (chess.isCheckmate()) return -100_000;
  if (chess.isDraw()) return 0;
  const turn = chess.turn();
  let score = 0;
  chess.board().forEach((row, rank) => row.forEach((piece, file) => {
    if (!piece) return;
    const advance = piece.color === 'w' ? 6 - rank : rank - 1;
    const center = 3.5 - (Math.abs(3.5 - rank) + Math.abs(3.5 - file)) / 2;
    const positional = piece.type === 'p' ? advance * 7 + center * 3
      : piece.type === 'n' || piece.type === 'b' ? center * 11
        : piece.type === 'q' ? center * 3 : 0;
    score += (piece.color === turn ? 1 : -1) * (pieceValue[piece.type] + positional);
  }));
  return score;
}

function orderMoves(moves: Move[]) {
  return moves.sort((a, b) => {
    const value = (move: Move) => (move.captured ? 10 * pieceValue[move.captured] - pieceValue[move.piece] : 0)
      + (move.promotion ? pieceValue[move.promotion] : 0);
    return value(b) - value(a);
  });
}

type SearchState = { nodes: number; nodeLimit: number; cancelled: () => boolean };

function yieldToUI() {
  return new Promise<void>((resolve) => setTimeout(resolve, 0));
}

async function negamax(chess: Chess, depth: number, alpha: number, beta: number, state: SearchState): Promise<number> {
  state.nodes += 1;
  if ((state.nodes & 511) === 0) {
    if (state.cancelled()) return 0;
    await yieldToUI();
  }
  if (depth === 0 || chess.isGameOver() || state.nodes >= state.nodeLimit) return evaluate(chess);

  let best = -Infinity;
  for (const move of orderMoves(chess.moves({ verbose: true }))) {
    if (state.cancelled()) return 0;
    chess.move(move);
    const score = -await negamax(chess, depth - 1, -beta, -alpha, state);
    chess.undo();
    best = Math.max(best, score);
    alpha = Math.max(alpha, score);
    if (alpha >= beta || state.nodes >= state.nodeLimit) break;
  }
  return best === -Infinity ? evaluate(chess) : best;
}

export async function chooseComputerMove(fen: string, level: ComputerLevel, cancelled: () => boolean = () => false) {
  const profile = profiles[level];
  if (!profile) throw new Error('Choose a supported computer level.');
  const chess = new Chess(fen);
  const roots = orderMoves(chess.moves({ verbose: true }));
  if (!roots.length) return null;

  let bestMove = roots[0];
  for (let depth = 1; depth <= profile.depth; depth += 1) {
    const state: SearchState = { nodes: 0, nodeLimit: profile.nodes, cancelled };
    let bestScore = -Infinity;
    let iterationBest = bestMove;
    for (const move of roots) {
      if (cancelled()) return null;
      chess.move(move);
      const score = -await negamax(chess, depth - 1, -Infinity, Infinity, state);
      chess.undo();
      if (score > bestScore) {
        bestScore = score;
        iterationBest = move;
      }
      if (state.nodes >= state.nodeLimit) break;
    }
    if (cancelled()) return null;
    bestMove = iterationBest;
  }
  return bestMove.san;
}

export function piecePositions(moves: string[]) {
  const chess = new Chess();
  const identities = new Map<string, string>();
  chess.board().flat().forEach((piece) => { if (piece) identities.set(piece.square, piece.square); });
  for (const san of moves) {
    const action = chess.move(san);
    const identity = identities.get(action.from) ?? action.from;
    identities.delete(action.from);
    identities.delete(action.to);
    if (action.isEnPassant()) identities.delete(`${action.to[0]}${action.from[1]}`);
    identities.set(action.to, identity);
    if (action.isKingsideCastle() || action.isQueensideCastle()) {
      const rank = action.from[1];
      const rookFrom = `${action.isKingsideCastle() ? 'h' : 'a'}${rank}`;
      const rookTo = `${action.isKingsideCastle() ? 'f' : 'd'}${rank}`;
      const rook = identities.get(rookFrom) ?? rookFrom;
      identities.delete(rookFrom);
      identities.set(rookTo, rook);
    }
  }
  return chess.board().flat().filter((piece) => piece !== null).map((piece) => ({ ...piece, id: identities.get(piece.square) ?? piece.square }));
}

export function toSquare(file: number, rank: number) {
  return `${files[file]}${rank + 1}`;
}
