-- Client route guards are a usability layer; enforce permanent, verified accounts at the data boundary too.
do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'chess_rooms',
    'player_profiles',
    'player_daily_completions',
    'scribble_rooms',
    'scribble_members',
    'scribble_drawing_batches',
    'scribble_events',
    'scribble_solved',
    'scribble_score_events'
  ] loop
    execute format('drop policy if exists "Require permanent account" on public.%I', table_name);
    execute format(
      'create policy "Require permanent account" on public.%I as restrictive for select to authenticated using (coalesce(auth.jwt() ->> ''is_anonymous'', ''false'') <> ''true'')',
      table_name
    );
  end loop;
end $$;

alter table public.player_profiles add column if not exists username text;
create unique index if not exists player_profiles_username_lower_uidx
  on public.player_profiles (lower(username))
  where username is not null;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'player_profiles_username_valid'
      and conrelid = 'public.player_profiles'::regclass
  ) then
    alter table public.player_profiles add constraint player_profiles_username_valid
      check (username is null or (username = lower(username) and username ~ '^[a-z0-9._-]{3,20}$'));
  end if;
end $$;

drop policy if exists "Require permanent account profile writes" on public.player_profiles;
create policy "Require permanent account profile writes"
  on public.player_profiles as restrictive for all to authenticated
  using (coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true')
  with check (coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true');
