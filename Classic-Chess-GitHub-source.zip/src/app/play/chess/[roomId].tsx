import { Redirect, useLocalSearchParams } from 'expo-router';

import GameScreen from '../../game';

export default function ChessRoomRoute() {
  const params = useLocalSearchParams<{ roomId?: string | string[]; code?: string | string[] }>();
  const code = Array.isArray(params.code) ? params.code[0] : params.code;
  // Invite links must pass through the existing appearance preview and join flow.
  if (code) return <Redirect href={{ pathname: '/online', params: { code } }} />;
  return <GameScreen />;
}
