export type PlayerColor = 'w' | 'b';
export type GameMode = 'local' | 'computer' | 'online';
export type BoardDesign = 'wood' | 'classic' | 'green';
export type ComputerLevel = 'mature' | 'casual' | 'classic' | 'professional';
export type PieceTone = 'pearl' | 'silver' | 'gold' | 'onyx' | 'emerald' | 'sapphire' | `#${string}`;

export const LEVELS: { id: ComputerLevel; title: string; subtitle: string }[] = [
  { id: 'mature', title: 'Mature', subtitle: 'Relaxed play' },
  { id: 'casual', title: 'Casual', subtitle: 'Spots simple tactics' },
  { id: 'classic', title: 'Classic', subtitle: 'Looks ahead' },
  { id: 'professional', title: 'Professional', subtitle: 'Deepest search' },
];

export const FINISHES: Record<PlayerColor, { id: Exclude<PieceTone, `#${string}`>; title: string; color: string }[]> = {
  w: [
    { id: 'pearl', title: 'Pearl', color: '#eee0c6' },
    { id: 'silver', title: 'Silver', color: '#d7dce4' },
    { id: 'gold', title: 'Gold', color: '#d9a849' },
  ],
  b: [
    { id: 'onyx', title: 'Onyx', color: '#292d33' },
    { id: 'emerald', title: 'Emerald', color: '#306a55' },
    { id: 'sapphire', title: 'Sapphire', color: '#31588b' },
  ],
};

export const BOARD_COLORS: Record<BoardDesign, { title: string; light: string; dark: string; frame: string }> = {
  wood: { title: 'Wood', light: '#d7c4a0', dark: '#79583f', frame: '#49382a' },
  classic: { title: 'Black & White', light: '#e8e8e6', dark: '#303231', frame: '#1c211f' },
  green: { title: 'Green & Cream', light: '#e6e2cc', dark: '#5c7c64', frame: '#25392d' },
};
