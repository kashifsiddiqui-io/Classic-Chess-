import { useMemo, useRef } from 'react';
import { PanResponder, StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, Path, RadialGradient, Stop } from 'react-native-svg';

import { palette } from '@/constants/app-theme';

const SIZE = 184;
const CENTER = SIZE / 2;
const RADIUS = 86;
const SEGMENTS = 48;

function hsvHex(hue: number, saturation: number, value: number) {
  const chroma = value * saturation;
  const section = hue / 60;
  const x = chroma * (1 - Math.abs((section % 2) - 1));
  const rgb = section < 1 ? [chroma, x, 0] : section < 2 ? [x, chroma, 0] : section < 3 ? [0, chroma, x]
    : section < 4 ? [0, x, chroma] : section < 5 ? [x, 0, chroma] : [chroma, 0, x];
  const offset = value - chroma;
  return `#${rgb.map((channel) => Math.round((channel + offset) * 255).toString(16).padStart(2, '0')).join('')}`;
}

function sectorPath(start: number, end: number) {
  const point = (angle: number) => {
    const radians = ((angle - 90) * Math.PI) / 180;
    return [CENTER + RADIUS * Math.cos(radians), CENTER + RADIUS * Math.sin(radians)];
  };
  const [x1, y1] = point(start);
  const [x2, y2] = point(end);
  return `M ${CENTER} ${CENTER} L ${x1} ${y1} A ${RADIUS} ${RADIUS} 0 ${end - start > 180 ? 1 : 0} 1 ${x2} ${y2} Z`;
}

export function ColorWheel({ value, onChange }: { value: string; onChange: (hex: string) => void }) {
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  const responder = useMemo(() => {
    const pick = (x: number, y: number) => {
      const dx = x - CENTER;
      const dy = y - CENTER;
      const distance = Math.min(Math.hypot(dx, dy), RADIUS);
      const hue = (Math.atan2(dy, dx) * 180 / Math.PI + 90 + 360) % 360;
      const saturation = Math.min(1, Math.max(0.08, distance / RADIUS));
      onChangeRef.current(hsvHex(hue, saturation, 0.96));
    };
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (event) => pick(event.nativeEvent.locationX, event.nativeEvent.locationY),
      onPanResponderMove: (event) => pick(event.nativeEvent.locationX, event.nativeEvent.locationY),
    });
  }, []);

  return (
    <View style={styles.container} accessibilityRole="adjustable" accessibilityLabel="Custom piece color wheel" {...responder.panHandlers}>
      <Svg width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`} pointerEvents="none">
        <Defs><RadialGradient id="color-wheel-saturation" cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor="#ffffff" stopOpacity="1" />
          <Stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </RadialGradient></Defs>
        {Array.from({ length: SEGMENTS }, (_, index) => {
          const start = index * 360 / SEGMENTS;
          const end = (index + 1) * 360 / SEGMENTS;
          return <Path key={index} d={sectorPath(start, end)} fill={hsvHex(start + 2, 1, 0.96)} />;
        })}
        <Circle cx={CENTER} cy={CENTER} r={RADIUS} fill="url(#color-wheel-saturation)" />
        <Circle cx={CENTER} cy={CENTER} r={7} fill={value} stroke={palette.white} strokeWidth={2} />
      </Svg>
      <View style={styles.hint}><View style={[styles.swatch, { backgroundColor: value }]} /></View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { width: SIZE, height: SIZE, alignSelf: 'center', alignItems: 'center', justifyContent: 'center' },
  hint: { position: 'absolute', bottom: 0, right: 10 },
  swatch: { width: 16, height: 16, borderRadius: 8, borderColor: palette.white, borderWidth: 2 },
});
