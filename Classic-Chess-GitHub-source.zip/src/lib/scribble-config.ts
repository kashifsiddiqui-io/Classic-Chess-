export const SCRIBBLE_DEFAULT_CYCLES = 3;
export const SCRIBBLE_MAX_PLAYERS = 8;
export const SCRIBBLE_CHOOSE_SECONDS = 15;
export const SCRIBBLE_DRAW_SECONDS = 60;
export const SCRIBBLE_REVEAL_SECONDS = 5;
export const SCRIBBLE_PRESENCE_SECONDS = 6;
export const SCRIBBLE_ONLINE_WINDOW_SECONDS = 18;
export const SCRIBBLE_MAX_STROKES_PER_BATCH = 8;
export const SCRIBBLE_MAX_POINTS_PER_STROKE = 64;
export const SCRIBBLE_MAX_BATCH_BYTES = 32_768;

export type ScribbleTool = 'pen' | 'eraser';
export type ScribblePoint = { x: number; y: number };
export type ScribbleStroke = {
  id: string;
  tool: ScribbleTool;
  color: string;
  width: number;
  points: ScribblePoint[];
};
