import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const manifestPath = join(process.cwd(), 'android/app/src/main/AndroidManifest.xml');
const manifest = readFileSync(manifestPath, 'utf8');
const callbackIntent = `            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="@string/custom_url_scheme" />
            </intent-filter>`;

if (manifest.includes('android:scheme="@string/custom_url_scheme"')) process.exit(0);

const launcherIntent = `            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>`;
if (!manifest.includes(launcherIntent)) {
  throw new Error('Could not locate the generated launcher intent in AndroidManifest.xml.');
}

writeFileSync(manifestPath, manifest.replace(launcherIntent, `${launcherIntent}\n\n${callbackIntent}`));
