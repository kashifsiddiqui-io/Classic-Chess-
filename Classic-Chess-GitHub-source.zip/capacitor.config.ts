import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mystore.classicchess',
  appName: 'Classic Chess',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
