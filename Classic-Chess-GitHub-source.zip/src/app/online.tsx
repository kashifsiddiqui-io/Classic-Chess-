import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ChessPiece } from '@/components/chess-piece';
import { RevealCard } from '@/components/reveal-card';
import { FINISHES, type PlayerColor } from '@/constants/chess';
import { useGame } from '@/context/game';
import { useAuth } from '@/context/auth';
import { callChessRoom, previewChessRoom, type OnlineProfile, type RoomPreview } from '@/lib/chess-room';
import { ensureAuthenticatedSession, getSupabase } from '@/lib/supabase';

const green = '#4e7c6e';
const ACCENTS = [
  { title: 'Forest', color: '#4e7c6e' },
  { title: 'Ocean', color: '#5277ad' },
  { title: 'Citrus', color: '#a07832' },
  { title: 'Berry', color: '#a4555c' },
  { title: 'Slate', color: '#60696b' },
];

export default function OnlineScreen() {
  const params = useLocalSearchParams<{ code?: string | string[] }>();
  const incomingCode = Array.isArray(params.code) ? params.code[0] : params.code;
  const [code, setCode] = useState((incomingCode ?? '').toUpperCase());
  const [preview, setPreview] = useState<RoomPreview | null>(null);
  const [busy, setBusy] = useState(false);
  const [busyPreview, setBusyPreview] = useState(false);
  const [error, setError] = useState('');
  const { settings, setSettings, setMoves, onlineProfile, setOnlineProfile } = useGame();
  const { user } = useAuth();
  const accountName = typeof user?.user_metadata?.display_name === 'string' ? user.user_metadata.display_name : '';
  const normalizedIncomingCode = incomingCode?.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 8);
  const activeCode = normalizedIncomingCode || code;
  const isJoining = Boolean(incomingCode || preview);
  const configurationError = incomingCode && !getSupabase()
    ? 'Supabase is not configured. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY in the Netlify build environment.'
    : '';
  const previewPending = busyPreview || Boolean(incomingCode && !preview && !error && !configurationError);
  const side: PlayerColor = isJoining ? 'b' : 'w';
  const pieceChoices = FINISHES[side];
  const selectedPieceTone = pieceChoices.some((finish) => finish.id === onlineProfile.pieceTone)
    ? onlineProfile.pieceTone
    : pieceChoices[0].id;

  useEffect(() => {
    if (accountName && onlineProfile.name === 'Player') setOnlineProfile((profile) => ({ ...profile, name: accountName }));
  }, [accountName, onlineProfile.name, setOnlineProfile]);

  useEffect(() => {
    if (!incomingCode) return;
    let active = true;
    const inviteCode = normalizedIncomingCode ?? '';
    const supabase = getSupabase();
    if (!supabase) return;
    void ensureAuthenticatedSession(supabase)
      .then(() => previewChessRoom(supabase, inviteCode))
      .then((roomPreview) => { if (active) setPreview(roomPreview); })
      .catch((cause: unknown) => { if (active) setError(cause instanceof Error ? cause.message : 'Could not open this room link.'); })
      .finally(() => { if (active) setBusyPreview(false); });
    return () => { active = false; };
  }, [incomingCode, normalizedIncomingCode]);

  function updateProfile<K extends keyof OnlineProfile>(key: K, value: OnlineProfile[K]) {
    setOnlineProfile({ ...onlineProfile, [key]: value });
  }

  async function loadPreview() {
    if (busyPreview || code.length !== 8) return;
    setBusyPreview(true);
    setError('');
    setPreview(null);
    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase is not configured. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY in the Netlify build environment.');
      await ensureAuthenticatedSession(supabase);
      setPreview(await previewChessRoom(supabase, code));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not preview this room.');
    } finally {
      setBusyPreview(false);
    }
  }

  async function openRoom(action: 'create' | 'join', inviteCode?: string) {
    if (busy) return;
    if (!onlineProfile.name.trim()) {
      setError('Enter a player name to continue.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase is not configured. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY in the Netlify build environment.');
      const session = await ensureAuthenticatedSession(supabase);
      const profileFields = {
        name: onlineProfile.name.trim(),
        pieceTone: selectedPieceTone,
        accentColor: onlineProfile.accentColor,
        showName: onlineProfile.showName,
      };
      const room = await callChessRoom(supabase, action === 'create'
        ? { action, ...profileFields }
        : { action, code: (inviteCode ?? activeCode).trim().toUpperCase(), ...profileFields });
      setSettings({
        ...settings,
        mode: 'online',
        playerColor: room.host_id === session.user.id ? 'w' : 'b',
        whiteTone: room.host_piece_tone,
        blackTone: room.guest_piece_tone,
      });
      setMoves(room.moves);
      router.push({ pathname: '/play/chess/[roomId]', params: { roomId: room.id } });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not open the online match. Try again.');
    } finally {
      setBusy(false);
    }
  }

  const opponentName = preview?.host_show_name ? preview.host_name : 'White player · name hidden';

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Pressable onPress={() => { if (router.canGoBack()) router.back(); else router.replace('/play'); }} hitSlop={12} style={styles.back}>
          <Text style={styles.backText}>← Back</Text>
        </Pressable>

        <View style={styles.hero}>
          <View style={styles.piece}><ChessPiece type="n" color="w" tone="onyx" size={67} /></View>
          <Text style={styles.kicker}>{isJoining ? 'JOIN ROOM' : 'PLAY TOGETHER'}</Text>
          <Text style={styles.heading}>{isJoining ? 'Join a friend’s match' : 'A match with a friend'}</Text>
          <Text style={styles.copy}>{isJoining ? 'Preview your opponent, choose your look, then join.' : 'Create a private room and share a verified invite by WhatsApp.'}</Text>
        </View>

        {isJoining && preview && <RevealCard style={styles.opponentCard}>
          <Text style={styles.sectionLabel}>YOUR OPPONENT</Text>
          <View style={styles.opponentRow}>
            <View style={[styles.opponentMark, { backgroundColor: preview.host_accent_color }]}>
              <ChessPiece type="k" color="w" tone={preview.host_piece_tone} size={33} />
            </View>
            <View style={styles.opponentInfo}>
              <Text style={styles.opponentName}>{opponentName}</Text>
              <Text style={styles.opponentMeta}>WHITE · {preview.host_piece_tone.toUpperCase()} PIECES</Text>
            </View>
            <View style={[styles.accentSwatch, { backgroundColor: preview.host_accent_color }]} />
          </View>
          <Text style={styles.cardCopy}>This room link expires 10 minutes after it was created.</Text>
        </RevealCard>}

        <RevealCard style={styles.profileCard}>
          <Text style={styles.sectionLabel}>YOUR PLAYER LOOK</Text>
          <TextInput
            value={onlineProfile.name}
            onChangeText={(value) => updateProfile('name', value.slice(0, 24))}
            placeholder="PLAYER NAME"
            placeholderTextColor="#87918a"
            autoCapitalize="words"
            autoCorrect={false}
            maxLength={24}
            style={styles.nameInput}
            accessibilityLabel="Player name"
          />

          <Text style={styles.optionLabel}>{side === 'w' ? 'WHITE' : 'BLACK'} PIECE COLOR</Text>
          <View style={styles.toneRow}>
            {pieceChoices.map((finish) => (
              <Pressable key={finish.id} onPress={() => updateProfile('pieceTone', finish.id)} style={[styles.toneOption, selectedPieceTone === finish.id && styles.toneSelected]} accessibilityRole="button" accessibilityState={{ selected: selectedPieceTone === finish.id }}>
                <View style={[styles.toneDot, { backgroundColor: finish.color }]} />
                <Text style={styles.toneText}>{finish.title}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.optionLabel}>ACCENT COLOR</Text>
          <View style={styles.accentRow}>
            {ACCENTS.map((accent) => (
              <Pressable key={accent.color} onPress={() => updateProfile('accentColor', accent.color)} style={[styles.accentOption, onlineProfile.accentColor === accent.color && styles.accentSelected]} accessibilityRole="button" accessibilityLabel={`${accent.title} accent`} accessibilityState={{ selected: onlineProfile.accentColor === accent.color }}>
                <View style={[styles.accentSwatch, styles.accentChoiceSwatch, { backgroundColor: accent.color }]} />
              </Pressable>
            ))}
          </View>

          <Pressable onPress={() => updateProfile('showName', !onlineProfile.showName)} style={styles.nameToggle} accessibilityRole="switch" accessibilityState={{ checked: onlineProfile.showName }}>
            <Text style={styles.optionLabel}>SHOW MY NAME IN THE MATCH</Text>
            <Text style={styles.toggleValue}>{onlineProfile.showName ? 'ON' : 'OFF'}</Text>
          </Pressable>
        </RevealCard>

        {isJoining ? <RevealCard style={styles.joinCard}>
          {!incomingCode && <>
            <Text style={styles.sectionLabel}>ROOM INVITE CODE</Text>
            <TextInput
              value={code}
              onChangeText={(value) => { setCode(value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 8)); setPreview(null); setError(''); }}
              placeholder="8-CHARACTER CODE"
              placeholderTextColor="#7b8580"
              autoCapitalize="characters"
              autoCorrect={false}
              maxLength={8}
              style={styles.codeInput}
              accessibilityLabel="Invite code"
            />
            {!preview && <Pressable onPress={() => void loadPreview()} disabled={previewPending || code.length !== 8} style={({ pressed }) => [styles.secondary, pressed && styles.pressed, (previewPending || code.length !== 8) && styles.disabled]}>
              <Text style={styles.secondaryText}>{previewPending ? 'CHECKING ROOM…' : 'PREVIEW ROOM'}</Text>
            </Pressable>}
          </>}
          {incomingCode && <Text style={styles.sectionLabel}>INVITE CODE · {activeCode}</Text>}
          {previewPending && !preview && <Text style={styles.cardCopy}>Checking the room link…</Text>}
          {preview && <Pressable onPress={() => void openRoom('join', activeCode)} disabled={busy} style={({ pressed }) => [styles.primary, pressed && styles.pressed, busy && styles.disabled]}>
            <Text style={styles.primaryText}>{busy ? 'JOINING…' : 'JOIN ROOM'}</Text>
            <Text style={styles.primaryArrow}>↗</Text>
          </Pressable>}
        </RevealCard> : <>
          <RevealCard style={styles.createCard}>
            <Text style={styles.sectionLabel}>START A NEW MATCH</Text>
            <Text style={styles.cardCopy}>Your invite is valid for 10 minutes. Share it with one friend.</Text>
            <Pressable onPress={() => void openRoom('create')} disabled={busy} style={({ pressed }) => [styles.primary, pressed && styles.pressed, busy && styles.disabled]}>
              <Text style={styles.primaryText}>{busy ? 'CONNECTING…' : 'CREATE INVITE'}</Text>
              <Text style={styles.primaryArrow}>↗</Text>
            </Pressable>
          </RevealCard>

          <View style={styles.orRow}><View style={styles.rule} /><Text style={styles.or}>OR JOIN A FRIEND</Text><View style={styles.rule} /></View>
          <RevealCard style={styles.joinCard}>
            <Text style={styles.sectionLabel}>ROOM INVITE CODE</Text>
            <TextInput
              value={code}
              onChangeText={(value) => { setCode(value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 8)); setError(''); }}
              placeholder="8-CHARACTER CODE"
              placeholderTextColor="#7b8580"
              autoCapitalize="characters"
              autoCorrect={false}
              maxLength={8}
              style={styles.codeInput}
              accessibilityLabel="Invite code"
            />
            <Pressable onPress={() => void loadPreview()} disabled={previewPending || code.length !== 8} style={({ pressed }) => [styles.secondary, pressed && styles.pressed, (previewPending || code.length !== 8) && styles.disabled]}>
              <Text style={styles.secondaryText}>{previewPending ? 'CHECKING ROOM…' : 'PREVIEW ROOM'}</Text>
            </Pressable>
          </RevealCard>
        </>}

        {!!(error || configurationError) && <Text accessibilityRole="alert" style={styles.error}>{error || configurationError}</Text>}
        <Text style={styles.privacy}>Guest sessions keep each match private to its two players.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f3f0eb' },
  content: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 34, flexGrow: 1 },
  back: { height: 36, justifyContent: 'center' },
  backText: { color: '#26332d', fontSize: 13, fontWeight: '700' },
  hero: { alignItems: 'center', paddingTop: 18, paddingBottom: 22 },
  piece: { height: 99, width: 99, borderRadius: 29, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 15 },
  kicker: { color: green, fontSize: 10, fontWeight: '800', letterSpacing: 2 },
  heading: { color: '#18251f', fontSize: 25, fontWeight: '800', marginTop: 7, textAlign: 'center' },
  copy: { color: '#68766f', fontSize: 13, lineHeight: 19, marginTop: 7, maxWidth: 320, textAlign: 'center' },
  profileCard: { padding: 17, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.56)', borderColor: 'rgba(255,255,255,.95)' },
  opponentCard: { padding: 17, marginBottom: 13, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.56)', borderColor: 'rgba(255,255,255,.95)' },
  opponentRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 13 },
  opponentMark: { height: 55, width: 55, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  opponentInfo: { flex: 1 },
  opponentName: { color: '#18251f', fontSize: 15, fontWeight: '800' },
  opponentMeta: { color: '#68766f', fontSize: 9, fontWeight: '700', letterSpacing: 1, marginTop: 4 },
  accentSwatch: { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: '#fff' },
  cardCopy: { color: '#68766f', fontSize: 12, marginTop: 8 },
  nameInput: { height: 48, borderWidth: 1, borderColor: '#d5dbd6', borderRadius: 14, marginTop: 12, paddingHorizontal: 14, color: '#1c2926', backgroundColor: 'rgba(255,255,255,.7)', fontSize: 15, fontWeight: '700' },
  optionLabel: { color: '#52645a', fontSize: 9, fontWeight: '800', letterSpacing: 1.2, marginTop: 17, marginBottom: 9 },
  toneRow: { flexDirection: 'row', gap: 8 },
  toneOption: { flex: 1, minHeight: 51, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderWidth: 1, borderColor: '#d5dbd6', borderRadius: 13, backgroundColor: 'rgba(255,255,255,.45)' },
  toneSelected: { borderColor: green, backgroundColor: 'rgba(78,124,110,.1)' },
  toneDot: { width: 17, height: 17, borderRadius: 9, borderWidth: 1, borderColor: '#7a827c55' },
  toneText: { color: '#26332d', fontSize: 10, fontWeight: '700' },
  accentRow: { flexDirection: 'row', gap: 11 },
  accentOption: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 12, borderWidth: 1, borderColor: 'transparent' },
  accentSelected: { borderColor: '#26332d' },
  accentChoiceSwatch: { width: 23, height: 23, borderWidth: 0 },
  nameToggle: { minHeight: 39, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, borderTopWidth: 1, borderTopColor: '#dfe3df' },
  toggleValue: { color: green, fontSize: 10, fontWeight: '900', letterSpacing: 1 },
  createCard: { padding: 17, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.56)', borderColor: 'rgba(255,255,255,.95)' },
  sectionLabel: { color: '#52645a', fontSize: 10, fontWeight: '800', letterSpacing: 1.7 },
  primary: { height: 54, marginTop: 16, borderRadius: 16, paddingHorizontal: 18, backgroundColor: green, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  primaryText: { color: '#fff', fontWeight: '900', fontSize: 13, letterSpacing: 1.5 },
  primaryArrow: { color: '#e6efe9', fontSize: 18 },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 21 },
  rule: { height: 1, flex: 1, backgroundColor: '#d9ddd9' },
  or: { color: '#849088', fontSize: 9, fontWeight: '700', letterSpacing: 1.5 },
  joinCard: { padding: 17, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.56)', borderColor: 'rgba(255,255,255,.95)', marginTop: 13 },
  codeInput: { height: 54, borderWidth: 1, borderColor: '#d5dbd6', borderRadius: 15, marginTop: 13, paddingHorizontal: 15, color: '#1c2926', backgroundColor: 'rgba(255,255,255,.65)', fontSize: 18, fontWeight: '800', letterSpacing: 4, textAlign: 'center' },
  secondary: { height: 50, marginTop: 11, borderRadius: 15, borderWidth: 1, borderColor: 'rgba(78,124,110,.48)', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(78,124,110,.09)' },
  secondaryText: { color: '#324c40', fontSize: 12, fontWeight: '900', letterSpacing: 1.5 },
  disabled: { opacity: 0.48 },
  pressed: { opacity: 0.8 },
  error: { color: '#a13b32', backgroundColor: '#fbe9e6', overflow: 'hidden', borderRadius: 12, marginTop: 15, padding: 12, fontSize: 12, lineHeight: 17 },
  privacy: { color: '#849088', fontSize: 10, textAlign: 'center', lineHeight: 16, marginTop: 19, paddingHorizontal: 12 },
});
