import type { SupabaseClient } from '@supabase/supabase-js';

export type TrophyWallet = { silver: number; gold: number };
export type TrophyLeader = TrophyWallet & { position: number; user_id: string; player_name: string };

export const emptyTrophyWallet: TrophyWallet = { silver: 0, gold: 0 };

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function readWallet(value: unknown): TrophyWallet | null {
  if (!isRecord(value)) return null;
  const silver = Number(value.silver);
  const gold = Number(value.gold);
  return Number.isSafeInteger(silver) && silver >= 0 && Number.isSafeInteger(gold) && gold >= 0 ? { silver, gold } : null;
}

async function throwFunctionError(error: { message?: string; context?: unknown }, fallback: string): Promise<never> {
  const context = error.context;
  if (context instanceof Response) {
    try {
      const payload: unknown = await context.clone().json();
      if (isRecord(payload) && typeof payload.error === 'string') throw new Error(payload.error);
    } catch (cause) {
      if (cause instanceof Error && cause.message !== 'Unexpected end of JSON input') throw cause;
    }
  }
  throw new Error(error.message || fallback);
}

export async function loadTrophyWallet(supabase: SupabaseClient, userId: string): Promise<TrophyWallet> {
  const { data, error } = await supabase.from('trophy_wallets').select('silver, gold').eq('user_id', userId).maybeSingle();
  if (error) throw new Error(error.message || 'Could not load your trophies.');
  return readWallet(data) ?? emptyTrophyWallet;
}

export async function startTrophyAiMatch(supabase: SupabaseClient, playerColor: 'w' | 'b') {
  const { data, error } = await supabase.functions.invoke('trophy-wallet', { body: { action: 'start-ai', playerColor } });
  if (error) return throwFunctionError(error, 'Could not start trophy tracking for this match.');
  if (!isRecord(data) || typeof data.matchId !== 'string') throw new Error('The trophy service returned an invalid match.');
  return data.matchId;
}

export async function settleTrophyAiMatch(supabase: SupabaseClient, matchId: string, moves: string[]): Promise<TrophyWallet> {
  const { data, error } = await supabase.functions.invoke('trophy-wallet', { body: { action: 'settle-ai', matchId, moves } });
  if (error) return throwFunctionError(error, 'Could not save the trophy result.');
  if (!isRecord(data)) throw new Error('The trophy service returned an invalid result.');
  const wallet = readWallet(data.wallet);
  if (!wallet) throw new Error('The trophy service returned an invalid balance.');
  return wallet;
}

export async function convertSilverTrophies(supabase: SupabaseClient, silverAmount: number): Promise<TrophyWallet> {
  const { data, error } = await supabase.rpc('convert_silver_trophies', { p_silver_amount: silverAmount });
  if (error) throw new Error(error.message || 'Could not convert silver trophies.');
  const wallet = Array.isArray(data) ? readWallet(data[0]) : readWallet(data);
  if (!wallet) throw new Error('The trophy service returned an invalid balance.');
  return wallet;
}

export async function loadTrophyLeaderboard(supabase: SupabaseClient): Promise<TrophyLeader[]> {
  const { data, error } = await supabase.rpc('get_trophy_leaderboard');
  if (error) throw new Error(error.message || 'Could not load the leaderboard.');
  if (!Array.isArray(data)) throw new Error('The leaderboard response was invalid.');
  return data.flatMap((row): TrophyLeader[] => {
    if (!isRecord(row)) return [];
    const wallet = readWallet(row);
    if (!wallet || typeof row.user_id !== 'string' || typeof row.player_name !== 'string' || !row.player_name.trim() || row.player_name.includes('@')) return [];
    const position = Number(row.rank_position);
    if (!Number.isSafeInteger(position) || position < 1) return [];
    return [{ ...wallet, position, user_id: row.user_id, player_name: row.player_name.trim() }];
  });
}
