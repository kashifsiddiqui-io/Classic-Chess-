export const palette = {
  background: '#080c0b',
  surface: '#111715',
  surfaceRaised: '#18211d',
  white: '#f5f4ed',
  muted: '#a8b2aa',
  green: '#5eaa7c',
  greenDark: '#163e2e',
  border: 'rgba(238, 244, 239, 0.18)',
  cream: '#eee0c6',
};
