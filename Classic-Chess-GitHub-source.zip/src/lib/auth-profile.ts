import AsyncStorage from '@react-native-async-storage/async-storage';
import { Capacitor } from '@capacitor/core';
import * as Linking from 'expo-linking';
import type { SupabaseClient, User } from '@supabase/supabase-js';

import { savePlayerName } from '@/lib/player-activity';

const RETURN_TO_KEY = '@classic-chess/auth-return-to-v1';
const PENDING_PROFILE_KEY = '@classic-chess/pending-auth-profile-v1';
export const APP_DEEP_LINK_SCHEME = 'com.mystore.classicchess';

export type PendingAuthProfile = { name: string; username: string; savedAt: number };

export function getAuthCallbackUrl() {
  if (Capacitor.isNativePlatform()) return `${APP_DEEP_LINK_SCHEME}://auth/callback`;
  return Linking.createURL('auth/callback');
}

export async function saveAuthReturnTo(path: string) {
  const safePath = path.startsWith('/') && !path.startsWith('//') && !path.startsWith('/auth') ? path : '/';
  await AsyncStorage.setItem(RETURN_TO_KEY, safePath);
}

export async function consumeAuthReturnTo() {
  const value = await AsyncStorage.getItem(RETURN_TO_KEY);
  await AsyncStorage.removeItem(RETURN_TO_KEY);
  return value?.startsWith('/') && !value.startsWith('//') && !value.startsWith('/auth') ? value : '/';
}

export async function readAuthReturnTo() {
  const value = await AsyncStorage.getItem(RETURN_TO_KEY);
  return value?.startsWith('/') && !value.startsWith('//') && !value.startsWith('/auth') ? value : '/';
}

export async function savePendingAuthProfile(name: string, username: string) {
  const profile = {
    name: name.trim().replace(/\s+/g, ' ').slice(0, 24),
    username: username.trim().replace(/^@/, '').toLowerCase(),
    savedAt: Date.now(),
  } satisfies PendingAuthProfile;
  await AsyncStorage.setItem(PENDING_PROFILE_KEY, JSON.stringify(profile));
}

export async function clearPendingAuthProfile() {
  await AsyncStorage.removeItem(PENDING_PROFILE_KEY);
}

export async function consumePendingAuthProfile(): Promise<PendingAuthProfile | null> {
  const raw = await AsyncStorage.getItem(PENDING_PROFILE_KEY);
  await AsyncStorage.removeItem(PENDING_PROFILE_KEY);
  if (!raw) return null;
  try {
    const value: unknown = JSON.parse(raw);
    if (!value || typeof value !== 'object') return null;
    const profile = value as Partial<PendingAuthProfile>;
    if (typeof profile.name !== 'string' || typeof profile.username !== 'string' || typeof profile.savedAt !== 'number') return null;
    if (Date.now() - profile.savedAt > 15 * 60 * 1000) return null;
    if (!profile.name.trim() || !/^[a-z0-9._-]{3,20}$/.test(profile.username)) return null;
    return { name: profile.name.trim().slice(0, 24), username: profile.username, savedAt: profile.savedAt };
  } catch {
    return null;
  }
}

function metadataText(user: User, keys: string[]) {
  for (const key of keys) {
    const value = user.user_metadata?.[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}

export function profileFromUser(user: User) {
  const emailName = user.email?.split('@')[0]?.replace(/[._-]+/g, ' ').trim() ?? '';
  const name = metadataText(user, ['display_name', 'full_name', 'name']) || emailName || 'Chess Player';
  const suggestedUsername = metadataText(user, ['username', 'preferred_username'])
    || user.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9._-]/g, '').slice(0, 20)
    || 'chessplayer';
  const normalizedUsername = suggestedUsername.toLowerCase().replace(/[^a-z0-9._-]/g, '').slice(0, 20);
  return { name: name.slice(0, 24), username: normalizedUsername.length >= 3 ? normalizedUsername : 'chessplayer' };
}

export async function completeAuthProfile(supabase: SupabaseClient, user: User, pendingProfile?: PendingAuthProfile | null) {
  const current = profileFromUser(user);
  const profile = pendingProfile
    ? { name: pendingProfile.name.trim().replace(/\s+/g, ' ').slice(0, 24), username: pendingProfile.username.trim().replace(/^@/, '').toLowerCase() }
    : current;
  if (!profile.name || !/^[a-z0-9._-]{3,20}$/.test(profile.username)) {
    throw new Error('Enter a name and a username of 3–20 letters, numbers, dots, underscores or hyphens.');
  }
  const hasDisplayName = Boolean(metadataText(user, ['display_name', 'full_name', 'name']));
  const hasUsername = Boolean(metadataText(user, ['username', 'preferred_username']));
  if (pendingProfile || !hasDisplayName || !hasUsername) {
    const { data, error } = await supabase.auth.updateUser({ data: {
      ...user.user_metadata,
      display_name: profile.name,
      full_name: profile.name,
      username: profile.username,
    } });
    if (error) throw new Error(error.message || 'Signed in, but could not save your player profile.');
    const { error: profileError } = await supabase.from('player_profiles').upsert({
      user_id: data.user.id,
      display_name: profile.name,
      username: profile.username,
    }, { onConflict: 'user_id' });
    if (profileError) {
      if (profileError.code === '23505') throw new Error('USERNAME_TAKEN: Choose another username to finish setting up your profile.');
      throw new Error(profileError.message || 'Signed in, but could not save your player profile.');
    }
  } else {
    const { error: profileError } = await supabase.from('player_profiles').upsert({
      user_id: user.id,
      display_name: profile.name,
      username: profile.username,
    }, { onConflict: 'user_id' });
    if (profileError) {
      if (profileError.code === '23505') throw new Error('USERNAME_TAKEN: Choose another username to finish setting up your profile.');
      throw new Error(profileError.message || 'Signed in, but could not save your player profile.');
    }
  }
  await savePlayerName(profile.name, user.id);
  return profile;
}
