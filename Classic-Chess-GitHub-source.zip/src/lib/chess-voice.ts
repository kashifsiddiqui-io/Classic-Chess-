import { Platform } from 'react-native';

import { getSupabase } from '@/lib/supabase';

let currentAudio: HTMLAudioElement | null = null;
let currentObjectUrl: string | null = null;

function speakWithBrowserVoice(text: string) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.94;
  utterance.pitch = 1.08;
  utterance.volume = 1;
  const voices = window.speechSynthesis.getVoices();
  const feminineVoice = voices.find((voice) => /^en([_-]|$)/i.test(voice.lang)
    && /female|samantha|karen|victoria|zira|aria|ava|susan|serena|tessa/i.test(voice.name))
    ?? voices.find((voice) => /female|samantha|karen|victoria|zira|aria|ava|susan|serena|tessa/i.test(voice.name));
  if (feminineVoice) utterance.voice = feminineVoice;
  window.speechSynthesis.speak(utterance);
}

export async function speakChessAnnouncement(text: string) {
  if (Platform.OS !== 'web') return;
  const announcement = text.trim().slice(0, 240);
  if (!announcement) return;

  try {
    const supabase = getSupabase();
    if (!supabase) throw new Error('Voice service is not configured.');
    const { data, error } = await supabase.functions.invoke('chess-voice', { body: { text: announcement } });
    if (error) throw error;
    if (!(data instanceof Blob)) throw new Error('Voice service returned invalid audio.');

    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = '';
    }
    if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);

    currentObjectUrl = URL.createObjectURL(data);
    currentAudio = new Audio(currentObjectUrl);
    currentAudio.volume = 0.96;
    currentAudio.onended = () => {
      if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
      currentObjectUrl = null;
      currentAudio = null;
    };
    await currentAudio.play();
  } catch {
    speakWithBrowserVoice(announcement);
  }
}
