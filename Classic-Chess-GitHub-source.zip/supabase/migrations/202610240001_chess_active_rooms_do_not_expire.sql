-- Invitation expiry applies only while a chess room is waiting for its second player.
-- Existing active/finished room data is preserved; those rows become non-expiring.
alter table public.chess_rooms alter column expires_at drop not null;

update public.chess_rooms
set expires_at = null
where status in ('active', 'finished');

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id
  for update;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if current_room.expires_at is not null and current_room.expires_at <= clock_timestamp() then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id
    and ply = p_expected_ply
    and (expires_at is null or expires_at > clock_timestamp())
  returning * into updated_room;

  if not found then
    raise exception 'The board changed or this invitation expired.' using errcode = '40001';
  end if;

  return to_jsonb(updated_room);
end;
$$;

revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean) to service_role;
