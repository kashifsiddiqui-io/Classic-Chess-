import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useGame } from '@/context/game';
import { useAuth } from '@/context/auth';
import { loadPlayerActivity, savePlayerName } from '@/lib/player-activity';
import { callScribbleRoom } from '@/lib/scribble-room';
import { ensureAuthenticatedSession, getSupabase } from '@/lib/supabase';

const blue = '#4775b7';

export default function ScribbleLobbyEntry() {
  const params = useLocalSearchParams<{ intent?: string | string[]; code?: string | string[] }>();
  const intent = Array.isArray(params.intent) ? params.intent[0] : params.intent;
  const inviteCode = Array.isArray(params.code) ? params.code[0] : params.code;
  const { setOnlineProfile } = useGame();
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [code, setCode] = useState((inviteCode ?? '').toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 8));
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [action, setAction] = useState<'create' | 'join' | null>(null);

  useEffect(() => {
    let active = true;
    void loadPlayerActivity(user?.id).then((activity) => {
      if (!active) return;
      const profileName = activity.name || (typeof user?.user_metadata?.display_name === 'string' ? user.user_metadata.display_name : '');
      if (profileName) setName(profileName);
      setLoaded(true);
    }).catch(() => {
      if (active) { setLoaded(true); setError('Could not load your saved player name.'); }
    });
    return () => { active = false; };
  }, [user?.id, user?.user_metadata?.display_name]);

  useEffect(() => {
    if (loaded && name.trim() && (intent === 'create' || inviteCode)) void openRoom(intent === 'create' ? 'create' : 'join');
    // Opening a room from an invite is intentionally automatic after the local name has loaded.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded, name, intent, inviteCode]);

  async function openRoom(kind: 'create' | 'join') {
    if (busy || !name.trim()) return;
    setBusy(true);
    setAction(kind);
    setError('');
    try {
      await savePlayerName(name, user?.id);
      setOnlineProfile((profile) => ({ ...profile, name: name.trim() }));
      const supabase = getSupabase();
      if (!supabase) throw new Error('Supabase is not configured. Add EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY to the app environment.');
      await ensureAuthenticatedSession(supabase);
      const result = await callScribbleRoom(supabase, kind === 'create'
        ? { action: 'create', name: name.trim() }
        : { action: 'join', code: code.trim().toUpperCase(), name: name.trim() });
      const room = result.room;
      if (!room) throw new Error('The Scribble service returned an invalid room. Try again.');
      router.replace({ pathname: '/play/scribble/[roomId]', params: { roomId: room.id, code: result.code ?? room.invite_code } });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not open this Scribble room. Try again.');
    } finally {
      setBusy(false);
      setAction(null);
    }
  }

  async function createFromShare() {
    if (!roomlessCanCreate) return;
    await openRoom('create');
  }

  const roomlessCanCreate = loaded && Boolean(name.trim()) && !busy;
  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <Pressable onPress={() => router.back()} style={styles.back} accessibilityRole="button"><Text style={styles.backText}>← Back</Text></Pressable>
      <View style={styles.hero}>
        <View style={styles.art}><Text style={styles.artLine}>〰</Text><Text style={styles.artPencil}>✎</Text></View>
        <Text style={styles.kicker}>DRAW & GUESS</Text>
        <Text style={styles.title}>Scribble</Text>
        <Text style={styles.subtitle}>Draw a word. Let your friends guess.</Text>
      </View>
      <View style={styles.card}>
        <Text style={styles.label}>PLAYER NAME</Text>
        <TextInput value={name} onChangeText={(value) => setName(value.slice(0, 24))} placeholder="What should we call you?" placeholderTextColor="#8a969f" maxLength={24} autoCapitalize="words" style={styles.input} accessibilityLabel="Scribble display name" />
        {inviteCode ? <>
          <Text style={[styles.label, styles.codeLabel]}>ROOM CODE</Text>
          <Text style={styles.code}>{code}</Text>
          <Pressable onPress={() => void openRoom('join')} disabled={!roomlessCanCreate || code.length !== 8} style={({ pressed }) => [styles.primary, pressed && styles.pressed, (!roomlessCanCreate || code.length !== 8) && styles.disabled]} accessibilityRole="button">
            <Text style={styles.primaryText}>{busy ? 'JOINING ROOM…' : 'JOIN ROOM'}</Text>
          </Pressable>
        </> : <>
          <Text style={[styles.label, styles.codeLabel]}>PRIVATE ROOM</Text>
          <Pressable onPress={() => void createFromShare()} disabled={!roomlessCanCreate} style={({ pressed }) => [styles.primary, pressed && styles.pressed, !roomlessCanCreate && styles.disabled]} accessibilityRole="button">
            <Text style={styles.primaryText}>{busy && action === 'create' ? 'CREATING ROOM…' : 'CREATE ROOM'}</Text>
          </Pressable>
          <View style={styles.orRow}><View style={styles.rule} /><Text style={styles.or}>OR JOIN A FRIEND</Text><View style={styles.rule} /></View>
          <TextInput value={code} onChangeText={(value) => setCode(value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 8))} placeholder="8-CHARACTER ROOM CODE" placeholderTextColor="#8a969f" maxLength={8} autoCapitalize="characters" style={[styles.input, styles.codeInput]} accessibilityLabel="Room invitation code" />
          <Pressable onPress={() => void openRoom('join')} disabled={!roomlessCanCreate || code.length !== 8} style={({ pressed }) => [styles.secondary, pressed && styles.pressed, (!roomlessCanCreate || code.length !== 8) && styles.disabled]} accessibilityRole="button">
            <Text style={styles.secondaryText}>{busy && action === 'join' ? 'JOINING ROOM…' : 'JOIN ROOM'}</Text>
          </Pressable>
        </>}
        {!!error && <Text style={styles.error} accessibilityRole="alert">{error}</Text>}
      </View>
      <Text style={styles.privacy}>Private rooms · 2–8 verified players</Text>
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f7f7f4' },
  content: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 35 },
  back: { height: 38, justifyContent: 'center' },
  backText: { color: '#26332d', fontSize: 13, fontWeight: '700' },
  hero: { alignItems: 'center', paddingTop: 8, paddingBottom: 22 },
  art: { width: 94, height: 94, borderRadius: 28, backgroundColor: '#eaf1fb', borderWidth: 1, borderColor: '#d5e2f3', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  artLine: { color: blue, fontSize: 43, fontWeight: '700', transform: [{ rotate: '-16deg' }], marginTop: -6 },
  artPencil: { color: '#315f9e', fontSize: 28, position: 'absolute', right: 18, bottom: 10 },
  kicker: { color: blue, fontSize: 9, fontWeight: '800', letterSpacing: 2 },
  title: { color: '#202923', fontSize: 27, fontWeight: '800', letterSpacing: -0.7, marginTop: 5 },
  subtitle: { color: '#6f7b74', fontSize: 12, marginTop: 5 },
  card: { borderRadius: 23, borderWidth: 1, borderColor: '#d7e2ef', backgroundColor: '#fff', padding: 17, shadowColor: '#45678f', shadowOpacity: 0.08, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  label: { color: '#64788c', fontSize: 9, fontWeight: '800', letterSpacing: 1.5 },
  input: { height: 49, borderRadius: 14, borderWidth: 1, borderColor: '#d6e0e9', backgroundColor: '#fbfcfd', color: '#24313c', fontSize: 14, fontWeight: '600', paddingHorizontal: 13, marginTop: 9 },
  codeLabel: { marginTop: 19 },
  code: { color: '#3e6da9', fontSize: 16, letterSpacing: 3, fontWeight: '900', marginTop: 7 },
  codeInput: { textAlign: 'center', letterSpacing: 3, fontWeight: '800', fontSize: 15 },
  primary: { height: 49, borderRadius: 15, backgroundColor: blue, alignItems: 'center', justifyContent: 'center', marginTop: 12 },
  primaryText: { color: '#fff', fontSize: 11, fontWeight: '900', letterSpacing: 1.5 },
  secondary: { height: 46, borderRadius: 14, borderWidth: 1, borderColor: '#c8d8ec', backgroundColor: '#f0f5fc', alignItems: 'center', justifyContent: 'center', marginTop: 9 },
  secondaryText: { color: '#355d92', fontSize: 10, fontWeight: '900', letterSpacing: 1.2 },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 17 },
  rule: { height: 1, flex: 1, backgroundColor: '#e2e8ed' },
  or: { color: '#8a969f', fontSize: 8, fontWeight: '800', letterSpacing: 1.3 },
  disabled: { opacity: 0.48 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
  error: { color: '#9e3c34', backgroundColor: '#fbe9e6', borderRadius: 12, overflow: 'hidden', padding: 11, marginTop: 12, fontSize: 11, lineHeight: 16 },
  privacy: { color: '#849088', fontSize: 10, textAlign: 'center', marginTop: 17 },
});
