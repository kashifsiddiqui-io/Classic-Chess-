import { withSupabase } from '@supabase/server';

const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...cors, 'Content-Type': 'application/json' },
});

function inviteCode() {
  return Array.from(crypto.getRandomValues(new Uint8Array(8)), (byte) => alphabet[byte % alphabet.length]).join('');
}

function validRoomId(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function validName(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= 24 && !/[\u0000-\u001f\u007f]/.test(value);
}

function rpcError(error: { code?: string; message: string }) {
  const code = error.code ?? '';
  if (['PGRST202', '42883', '42P01', '42703'].includes(code)) {
    return json({ error: 'Scribble’s database setup is incomplete. Run the full supabase/SETUP_MULTIPLAYER.sql in Supabase SQL Editor, then reload this room.' }, 503);
  }
  const status = code === '42501' ? 403 : code === 'P0002' ? 404 : code === 'P0001' || code === '40001' ? 409 : code === '22023' ? 400 : 500;
  if (status === 500) console.error(`[scribble-room] Database action failed (${code || 'unknown code'}).`);
  const safeMessage = status === 500 ? 'The Scribble service could not complete that action. Try again.' : error.message;
  return json({ error: safeMessage }, status);
}

function validateStrokes(value: unknown) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 8 || new TextEncoder().encode(JSON.stringify(value)).length > 32768) return false;
  return value.every((stroke) => {
    if (!stroke || typeof stroke !== 'object') return false;
    const item = stroke as Record<string, unknown>;
    if (typeof item.id !== 'string' || item.id.length < 1 || item.id.length > 80 || !['pen', 'eraser'].includes(String(item.tool))) return false;
    if (item.tool === 'pen' && (typeof item.color !== 'string' || !/^#[0-9a-f]{6}$/i.test(item.color))) return false;
    if (typeof item.width !== 'number' || item.width < 1 || item.width > 32 || !Array.isArray(item.points) || item.points.length < 1 || item.points.length > 64) return false;
    return item.points.every((point) => point && typeof point === 'object'
      && typeof (point as Record<string, unknown>).x === 'number'
      && typeof (point as Record<string, unknown>).y === 'number'
      && (point as Record<string, number>).x >= 0 && (point as Record<string, number>).x <= 1
      && (point as Record<string, number>).y >= 0 && (point as Record<string, number>).y <= 1);
  });
}

const handler = withSupabase({ auth: 'user' }, async (request, ctx) => {
  if (request.method !== 'POST') return json({ error: 'Use POST for Scribble actions.' }, 405);
  const { data: auth, error: authError } = await ctx.supabase.auth.getUser();
  if (authError || !auth.user || auth.user.is_anonymous || !auth.user.email_confirmed_at) {
    return json({ error: 'Verify your email or sign in with Google before opening a room.' }, 401);
  }
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return json({ error: 'The Scribble request was not valid JSON.' }, 400); }
  const db = ctx.supabaseAdmin;

  if (body.action === 'create') {
    if (!validName(body.name)) return json({ error: 'Enter a display name up to 24 characters.' }, 400);
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const code = inviteCode();
      const { data, error } = await db.rpc('scribble_create_room', { p_user_id: auth.user.id, p_name: body.name.trim(), p_code: code });
      if (!error && data) return json({ room: data, code });
      if (error?.code !== '23505') return rpcError(error);
    }
    return json({ error: 'Could not create a unique room code. Try again.' }, 503);
  }

  if (body.action === 'join') {
    const code = typeof body.code === 'string' ? body.code.trim().toUpperCase() : '';
    if (!/^[A-HJ-NP-Z2-9]{8}$/.test(code) || !validName(body.name)) return json({ error: 'Enter a valid 8-character room code and display name.' }, 400);
    const { data, error } = await db.rpc('scribble_join_room', { p_code: code, p_user_id: auth.user.id, p_name: body.name.trim() });
    return error ? rpcError(error) : json({ room: data?.room, code });
  }

  if (!validRoomId(body.roomId)) return json({ error: 'The Scribble room ID is invalid.' }, 400);
  const roomId = body.roomId;

  if (body.action === 'start') {
    const cycles = body.cycles ?? 3;
    if (!Number.isInteger(cycles) || Number(cycles) < 1 || Number(cycles) > 5) return json({ error: 'Cycles must be between one and five.' }, 400);
    const { data, error } = await db.rpc('scribble_start_room', { p_room_id: roomId, p_user_id: auth.user.id, p_cycles: cycles });
    return error ? rpcError(error) : json({ room: data });
  }
  if (body.action === 'choose') {
    if (typeof body.word !== 'string' || body.word.trim().length > 24) return json({ error: 'Choose one of the available words.' }, 400);
    const { data, error } = await db.rpc('scribble_choose_word', { p_room_id: roomId, p_user_id: auth.user.id, p_word: body.word.trim() });
    return error ? rpcError(error) : json({ room: data });
  }
  if (body.action === 'guess') {
    if (typeof body.guess !== 'string' || body.guess.length > 80) return json({ error: 'Keep guesses to 80 characters or fewer.' }, 400);
    const { data, error } = await db.rpc('scribble_guess', { p_room_id: roomId, p_user_id: auth.user.id, p_guess: body.guess });
    return error ? rpcError(error) : json(data);
  }
  if (body.action === 'strokes') {
    if (!validRoomId(body.turnId) || !Number.isInteger(body.revision) || Number(body.revision) < 0 || !validateStrokes(body.strokes)) return json({ error: 'The drawing update is invalid or too large.' }, 400);
    const { data, error } = await db.rpc('scribble_append_strokes', { p_room_id: roomId, p_user_id: auth.user.id, p_turn_id: body.turnId, p_revision: body.revision, p_strokes: body.strokes });
    return error ? rpcError(error) : json(data);
  }
  if (body.action === 'clear') {
    if (!validRoomId(body.turnId) || !Number.isInteger(body.revision) || Number(body.revision) < 0) return json({ error: 'The canvas revision is invalid.' }, 400);
    const { data, error } = await db.rpc('scribble_clear_canvas', { p_room_id: roomId, p_user_id: auth.user.id, p_turn_id: body.turnId, p_revision: body.revision });
    return error ? rpcError(error) : json(data);
  }
  if (body.action === 'ping') {
    const { data, error } = await db.rpc('scribble_ping', { p_room_id: roomId, p_user_id: auth.user.id });
    return error ? rpcError(error) : json({ lastSeenAt: data });
  }
  if (body.action === 'leave') {
    const { data, error } = await db.rpc('scribble_leave_room', { p_room_id: roomId, p_user_id: auth.user.id });
    return error ? rpcError(error) : json(data);
  }
  if (body.action === 'rematch') {
    const { data, error } = await db.rpc('scribble_rematch', { p_room_id: roomId, p_user_id: auth.user.id });
    return error ? rpcError(error) : json({ room: data });
  }
  if (body.action === 'sync') {
    const { data: member, error: memberError } = await db.from('scribble_members').select('user_id,status').eq('room_id', roomId).eq('user_id', auth.user.id).maybeSingle();
    if (memberError || !member || member.status === 'left') return json({ error: 'Join this private room before opening its game state.' }, 403);
    const { error: advanceError } = await db.rpc('scribble_advance_due_rooms', { p_room_id: roomId });
    if (advanceError) return rpcError(advanceError);
    const { data: room, error: roomError } = await db.from('scribble_rooms').select('*').eq('id', roomId).maybeSingle();
    if (roomError) return json({ error: 'Could not load this Scribble room.' }, 500);
    if (!room) return json({ error: 'This Scribble room has expired or was removed.' }, 404);
    const [{ data: members, error: membersError }, { data: events, error: eventsError }] = await Promise.all([
      db.from('scribble_members').select('user_id,display_name,seat,status,is_host,score,last_seen_at').eq('room_id', roomId).neq('status', 'left').order('seat', { ascending: true, nullsFirst: false }),
      db.from('scribble_events').select('id,actor_id,event_type,body,created_at').eq('room_id', roomId).order('id', { ascending: false }).limit(100),
    ]);
    if (membersError || eventsError) return json({ error: 'Could not load the room roster or activity.' }, 500);
    let privateTurn: { choices?: string[]; answer?: string } | null = null;
    if (room.current_turn_id && room.current_drawer_id === auth.user.id && ['choosing', 'drawing'].includes(room.phase)) {
      const { data: turn, error: turnError } = await db.from('scribble_turns').select('choices,answer').eq('id', room.current_turn_id).single();
      if (turnError) return json({ error: 'Could not load the private drawing turn.' }, 500);
      privateTurn = { choices: room.phase === 'choosing' ? turn.choices : undefined, answer: turn.answer ?? undefined };
    }
    let strokes: unknown[] = [];
    if (room.current_turn_id && ['drawing', 'reveal'].includes(room.phase)) {
      const { data, error } = await db.from('scribble_drawing_batches').select('canvas_revision,sequence,strokes')
        .eq('turn_id', room.current_turn_id).eq('canvas_revision', room.canvas_revision).order('sequence', { ascending: true }).limit(600);
      if (error) return json({ error: 'Could not restore the drawing canvas.' }, 500);
      strokes = data ?? [];
    }
    const now = new Date();
    return json({ snapshot: {
      room,
      members: (members ?? []).map((player) => ({ ...player, online: now.getTime() - Date.parse(player.last_seen_at) <= 18_000 })),
      turn: room.current_turn_id ? { number: room.turn_number, cycle: room.cycle_number, drawerId: room.current_drawer_id, phase: room.phase, deadline: room.phase_deadline, revision: room.canvas_revision } : null,
      privateTurn,
      strokes,
      events: (events ?? []).reverse(),
      serverNow: now.toISOString(),
    } });
  }
  return json({ error: 'Unknown Scribble action.' }, 400);
});

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const response = await handler(request);
    const headers = new Headers(response.headers);
    Object.entries(cors).forEach(([key, value]) => headers.set(key, value));
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch {
    return json({ error: 'The Scribble service is temporarily unavailable.' }, 500);
  }
});
