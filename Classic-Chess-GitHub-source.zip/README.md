# Classic Chess

<p align="center">
  <img src="docs/app-architecture.jpg" alt="MyStore Chess app architecture: app screens, game features, services, and Supabase backend" width="100%">
</p>

Classic Chess is a mobile-first chess app built with Expo, React Native, Expo Router, and Capacitor. It includes local and computer matches, online chess, Scribble, player profiles, rewards, voice announcements, and Supabase-backed accounts and multiplayer services.

## Run Locally

Install Node.js and npm, then install the app dependencies:

```bash
npm install
```

Copy `.env.example` to `.env.local` and set the public Supabase project URL and publishable key:

```dotenv
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Start the web app:

```bash
npm run web
```

## Build Web

Create the static web export in `dist/`:

```bash
npm run build:web
```

Netlify is configured by `netlify.toml` to publish `dist`. Set `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` in the Netlify build environment. Do not put Groq, ElevenLabs, Supabase secret, or service-role keys in Netlify or any `EXPO_PUBLIC_*` variable.

## Android

The Android project and Gradle wrapper are included. Install a compatible JDK and Android SDK, then build the web assets and sync them into Android:

```bash
npm run cap:sync
```

Build a release APK or Play Store bundle:

```bash
npm run android:release-apk
npm run android:release-bundle
```

Release signing files are intentionally excluded. Configure a private upload keystore and `android/keystore/release-signing.properties` for signed store releases; keep both out of GitHub.

## Supabase

Set up Supabase Authentication and the Google provider in the Supabase dashboard. Add the Supabase callback URL shown under Authentication provider settings to the Google Cloud OAuth client, and add the app's web and deep-link return URLs to Supabase's redirect allow list.

Apply database migrations and deploy the Edge Functions:

```bash
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase migration up --linked
npx supabase functions deploy chess-room
npx supabase functions deploy scribble-room
npx supabase functions deploy chess-voice
npx supabase functions deploy trophy-wallet
npx supabase functions deploy chess-hint
```

Configure `GROQ_API_KEY`, `ELEVENLABS_API_KEY`, and optionally `ELEVENLABS_VOICE_ID` as Supabase Edge Function secrets. A template is in `supabase/functions/.env.example`; never commit actual credentials.

## Project Map

- `src/app/` contains the Expo Router screens.
- `src/components/`, `src/context/`, and `src/lib/` contain shared UI, state, and service code.
- `assets/` contains app artwork and chess assets.
- `supabase/migrations/` and `supabase/functions/` contain the backend schema and Edge Functions.
- `APP-FLOWCHART.mmd` and `APP-FLOWCHART.svg` contain editable and rendered app flow diagrams.
- `docs/app-architecture.jpg` is the architecture reference shown above.

## Security Notes

This source archive omits local `.env` files, dependency folders, generated web and Android builds, and Android signing keys. Use `.env.example` as a template and keep server credentials in Supabase Edge Function secrets. Review the Supabase RLS policies and OAuth redirect allow list before deploying your own project.

No project license is included. Choose a license before making the repository public.
