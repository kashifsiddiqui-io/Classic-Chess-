import { withSupabase } from '@supabase/server';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

const userHandler = withSupabase({ auth: 'user' }, async (request, ctx) => {
  if (request.method !== 'POST') return json({ error: 'Use POST to request voice narration.' }, 405);

  const { data: { user }, error: authError } = await ctx.supabase.auth.getUser();
  if (authError || !user || user.is_anonymous || !user.email_confirmed_at) {
    return json({ error: 'Sign in with a verified account to use voice narration.' }, 401);
  }

  let body: { text?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'The voice request is invalid.' }, 400);
  }

  const text = typeof body.text === 'string' ? body.text.trim() : '';
  if (!text || text.length > 240 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(text)) {
    return json({ error: 'Provide a short, valid move announcement.' }, 400);
  }

  const apiKey = Deno.env.get('ELEVENLABS_API_KEY');
  if (!apiKey) return json({ error: 'Voice narration is not configured on the server.' }, 503);

  const voiceId = Deno.env.get('ELEVENLABS_VOICE_ID') || '21m00Tcm4TlvDq8ikWAM';
  let response: Response;
  try {
    response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128&enable_logging=false`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.54, similarity_boost: 0.8, style: 0.2, speed: 0.96, use_speaker_boost: true },
      }),
      signal: AbortSignal.timeout(20_000),
    });
  } catch {
    return json({ error: 'The voice service could not be reached.' }, 502);
  }

  if (!response.ok) return json({ error: 'The voice service could not create narration.' }, response.status === 429 ? 429 : 502);
  return new Response(response.body, {
    status: 200,
    headers: {
      ...corsHeaders,
      'Content-Type': 'application/octet-stream',
      'Cache-Control': 'no-store',
    },
  });
});

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const response = await userHandler(request);
    const headers = new Headers(response.headers);
    Object.entries(corsHeaders).forEach(([name, value]) => headers.set(name, value));
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch {
    return json({ error: 'Voice narration is temporarily unavailable.' }, 500);
  }
});
