-- Classic Chess multiplayer setup for a fresh Supabase project.
-- Paste and run this script once in Supabase SQL Editor.
-- This creates the chess/Scribble room schema, room RPCs, policies,
-- expiry jobs, daily completion tracking, and verified-player policies.


-- ===== 202610230001_chess_rooms.sql =====

create table if not exists public.chess_rooms (
  id uuid primary key default gen_random_uuid(),
  invite_code text not null unique,
  host_id uuid not null references auth.users (id) on delete cascade,
  guest_id uuid references auth.users (id) on delete set null,
  moves text[] not null default array[]::text[],
  ply integer not null default 0 check (ply = cardinality(moves)),
  status text not null default 'waiting' check (status in ('waiting', 'active', 'finished')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours'),
  constraint chess_rooms_two_distinct_players check (guest_id is null or guest_id <> host_id)
);

create index if not exists chess_rooms_expires_at_idx on public.chess_rooms (expires_at);

alter table public.chess_rooms enable row level security;
revoke all on public.chess_rooms from anon, authenticated;
grant select on public.chess_rooms to authenticated;
grant all on public.chess_rooms to service_role;

drop policy if exists "Players can read their own chess room" on public.chess_rooms;
create policy "Players can read their own chess room"
  on public.chess_rooms for select to authenticated
  using (auth.uid() = host_id or auth.uid() = guest_id);

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id and ply = p_expected_ply
  returning * into updated_room;

  if not found then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  return to_jsonb(updated_room);
end;
$$;

revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean) to service_role;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'chess_rooms'
  ) then
    alter publication supabase_realtime add table public.chess_rooms;
  end if;
end $$;


-- ===== 202610230002_multiplayer_identity_expiry.sql =====

alter table public.chess_rooms
  add column host_name text not null default 'Player 1',
  add column guest_name text,
  add column host_piece_tone text not null default 'pearl',
  add column guest_piece_tone text not null default 'onyx',
  add column host_accent_color text not null default '#4e7c6e',
  add column guest_accent_color text not null default '#5277ad',
  add column host_show_name boolean not null default true,
  add column guest_show_name boolean not null default true;

alter table public.chess_rooms
  alter column expires_at set default (now() + interval '10 minutes'),
  add constraint chess_rooms_host_name_length check (char_length(btrim(host_name)) between 1 and 24),
  add constraint chess_rooms_guest_name_length check (guest_name is null or char_length(btrim(guest_name)) between 1 and 24),
  add constraint chess_rooms_host_tone_valid check (host_piece_tone in ('pearl', 'silver', 'gold')),
  add constraint chess_rooms_guest_tone_valid check (guest_piece_tone in ('onyx', 'emerald', 'sapphire')),
  add constraint chess_rooms_host_accent_valid check (host_accent_color ~ '^#[0-9A-Fa-f]{6}$'),
  add constraint chess_rooms_guest_accent_valid check (guest_accent_color ~ '^#[0-9A-Fa-f]{6}$');

-- Existing rooms keep their original server creation time and expire ten minutes after it.
update public.chess_rooms
set expires_at = created_at + interval '10 minutes';

create extension if not exists pg_cron;

select cron.unschedule(jobid)
from cron.job
where jobname = 'cleanup-expired-chess-rooms';

select cron.schedule(
  'cleanup-expired-chess-rooms',
  '* * * * *',
  $job$delete from public.chess_rooms where expires_at <= now();$job$
);

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id
  for update;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if current_room.expires_at <= clock_timestamp() then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id and ply = p_expected_ply and expires_at > clock_timestamp()
  returning * into updated_room;

  if not found then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  return to_jsonb(updated_room);
end;
$$;


-- ===== 202610240001_chess_active_rooms_do_not_expire.sql =====

-- Invitation expiry applies only while a chess room is waiting for its second player.
-- Existing active/finished room data is preserved; those rows become non-expiring.
alter table public.chess_rooms alter column expires_at drop not null;

update public.chess_rooms
set expires_at = null
where status in ('active', 'finished');

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id
  for update;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if current_room.expires_at is not null and current_room.expires_at <= clock_timestamp() then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id
    and ply = p_expected_ply
    and (expires_at is null or expires_at > clock_timestamp())
  returning * into updated_room;

  if not found then
    raise exception 'The board changed or this invitation expired.' using errcode = '40001';
  end if;

  return to_jsonb(updated_room);
end;
$$;

revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean) to service_role;


-- ===== 202610240002_scribble_schema.sql =====

-- Additive Scribble schema. This migration does not modify or drop chess data.
create extension if not exists pgcrypto;

create table public.player_profiles (
  user_id uuid primary key references auth.users (id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 24),
  updated_at timestamptz not null default now()
);

create table public.scribble_rooms (
  id uuid primary key default gen_random_uuid(),
  invite_code text not null unique check (invite_code ~ '^[A-HJ-NP-Z2-9]{8}$'),
  host_id uuid not null references auth.users (id) on delete cascade,
  status text not null default 'waiting' check (status in ('waiting', 'active', 'results', 'closed')),
  phase text not null default 'waiting' check (phase in ('waiting', 'choosing', 'drawing', 'reveal', 'results')),
  max_players smallint not null default 8 check (max_players between 2 and 8),
  cycles smallint not null default 3 check (cycles between 1 and 5),
  choose_seconds smallint not null default 15 check (choose_seconds between 5 and 30),
  draw_seconds smallint not null default 60 check (draw_seconds between 30 and 120),
  reveal_seconds smallint not null default 5 check (reveal_seconds between 3 and 12),
  state_version bigint not null default 0 check (state_version >= 0),
  turn_number integer not null default 0 check (turn_number >= 0),
  cycle_number smallint not null default 0 check (cycle_number >= 0),
  turn_order uuid[] not null default '{}',
  drawn_this_cycle uuid[] not null default '{}',
  current_drawer_id uuid references auth.users (id) on delete set null,
  current_turn_id uuid,
  phase_deadline timestamptz,
  drawer_grace_deadline timestamptz,
  canvas_revision integer not null default 0 check (canvas_revision >= 0),
  public_state jsonb not null default '{}'::jsonb check (jsonb_typeof(public_state) = 'object'),
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz,
  invite_expires_at timestamptz default (now() + interval '10 minutes'),
  updated_at timestamptz not null default now(),
  constraint scribble_waiting_expiry check (status <> 'waiting' or invite_expires_at is not null)
);

create index scribble_rooms_expiry_idx on public.scribble_rooms (invite_expires_at) where status = 'waiting';
create index scribble_rooms_live_idx on public.scribble_rooms (updated_at) where status in ('waiting', 'active');

create table public.scribble_members (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 24),
  seat smallint,
  status text not null default 'active' check (status in ('active', 'waiting', 'left')),
  is_host boolean not null default false,
  score integer not null default 0 check (score >= 0),
  joined_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  left_at timestamptz,
  primary key (room_id, user_id),
  constraint scribble_member_seat_range check (seat is null or seat between 1 and 8)
);

create unique index scribble_member_seat_unique on public.scribble_members (room_id, seat) where seat is not null and status <> 'left';
create index scribble_members_user_active_idx on public.scribble_members (user_id, last_seen_at desc) where status in ('active', 'waiting');

create table public.scribble_word_bank (
  id bigint generated always as identity primary key,
  word text not null unique check (char_length(word) between 3 and 24 and word = lower(btrim(word))),
  category text not null default 'Everyday' check (char_length(category) between 1 and 32),
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.scribble_turns (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_number integer not null check (turn_number > 0),
  cycle_number smallint not null check (cycle_number > 0),
  drawer_id uuid not null references auth.users (id) on delete cascade,
  choices text[] not null check (cardinality(choices) = 3),
  answer text,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  canvas_revision integer not null default 0,
  unique (room_id, turn_number)
);

create index scribble_turns_room_recent_idx on public.scribble_turns (room_id, turn_number desc);

create table public.scribble_drawing_batches (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  canvas_revision integer not null check (canvas_revision >= 0),
  sequence bigint not null check (sequence > 0),
  drawer_id uuid not null references auth.users (id) on delete cascade,
  strokes jsonb not null check (jsonb_typeof(strokes) = 'array'),
  created_at timestamptz not null default now(),
  primary key (turn_id, canvas_revision, sequence)
);

create index scribble_drawing_snapshot_idx on public.scribble_drawing_batches (room_id, turn_id, canvas_revision, sequence);

create table public.scribble_events (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid references public.scribble_turns (id) on delete cascade,
  actor_id uuid references auth.users (id) on delete set null,
  event_type text not null check (event_type in ('guess', 'correct', 'system', 'reveal')),
  body jsonb not null check (jsonb_typeof(body) = 'object'),
  created_at timestamptz not null default now()
);

create index scribble_events_room_feed_idx on public.scribble_events (room_id, id desc);
create index scribble_events_rate_limit_idx on public.scribble_events (room_id, actor_id, created_at desc) where event_type = 'guess';

create table public.scribble_solved (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  points integer not null check (points between 100 and 200),
  solved_at timestamptz not null default now(),
  primary key (turn_id, user_id)
);

create table public.scribble_score_events (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  recipient_id uuid not null references auth.users (id) on delete cascade,
  source_user_id uuid not null references auth.users (id) on delete cascade,
  event_type text not null check (event_type in ('correct_guess', 'drawer_bonus')),
  points integer not null check (points between 25 and 200),
  created_at timestamptz not null default now(),
  unique (turn_id, recipient_id, source_user_id, event_type)
);

create index scribble_score_room_idx on public.scribble_score_events (room_id, created_at);

create or replace function public.scribble_is_member(p_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.scribble_members m
    where m.room_id = p_room_id
      and m.user_id = (select auth.uid())
      and m.status in ('active', 'waiting')
  );
$$;

revoke all on function public.scribble_is_member(uuid) from public, anon;
grant execute on function public.scribble_is_member(uuid) to authenticated;

alter table public.player_profiles enable row level security;
alter table public.scribble_rooms enable row level security;
alter table public.scribble_members enable row level security;
alter table public.scribble_word_bank enable row level security;
alter table public.scribble_turns enable row level security;
alter table public.scribble_drawing_batches enable row level security;
alter table public.scribble_events enable row level security;
alter table public.scribble_solved enable row level security;
alter table public.scribble_score_events enable row level security;

revoke all on public.player_profiles, public.scribble_rooms, public.scribble_members, public.scribble_word_bank,
  public.scribble_turns, public.scribble_drawing_batches, public.scribble_events, public.scribble_solved,
  public.scribble_score_events from anon, authenticated;
grant select, insert, update on public.player_profiles to authenticated;
grant select on public.scribble_rooms, public.scribble_members, public.scribble_drawing_batches,
  public.scribble_events, public.scribble_solved, public.scribble_score_events to authenticated;
grant all on public.player_profiles, public.scribble_rooms, public.scribble_members, public.scribble_word_bank,
  public.scribble_turns, public.scribble_drawing_batches, public.scribble_events, public.scribble_solved,
  public.scribble_score_events to service_role;

create policy "Players read own profile" on public.player_profiles for select to authenticated using (user_id = (select auth.uid()));
create policy "Players create own profile" on public.player_profiles for insert to authenticated with check (user_id = (select auth.uid()));
create policy "Players update own profile" on public.player_profiles for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "Room members read room state" on public.scribble_rooms for select to authenticated using (public.scribble_is_member(id));
create policy "Room members read roster" on public.scribble_members for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read drawing batches" on public.scribble_drawing_batches for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read safe events" on public.scribble_events for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read solve results" on public.scribble_solved for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read scores" on public.scribble_score_events for select to authenticated using (public.scribble_is_member(room_id));

revoke all on public.scribble_word_bank, public.scribble_turns from anon, authenticated;
revoke all on public.scribble_solved, public.scribble_score_events from anon, authenticated;

insert into public.scribble_word_bank (word, category) values
  ('apple', 'Food'), ('backpack', 'Everyday'), ('balloon', 'Objects'), ('bicycle', 'Transport'),
  ('butterfly', 'Nature'), ('campfire', 'Nature'), ('castle', 'Places'), ('caterpillar', 'Nature'),
  ('cheesecake', 'Food'), ('clock', 'Objects'), ('cloud', 'Nature'), ('coconut', 'Food'),
  ('dolphin', 'Animals'), ('drum', 'Music'), ('elephant', 'Animals'), ('envelope', 'Objects'),
  ('fireworks', 'Events'), ('football', 'Sports'), ('giraffe', 'Animals'), ('guitar', 'Music'),
  ('hamburger', 'Food'), ('helicopter', 'Transport'), ('ice cream', 'Food'), ('igloo', 'Places'),
  ('jellyfish', 'Animals'), ('kite', 'Objects'), ('lantern', 'Objects'), ('lighthouse', 'Places'),
  ('mountain', 'Nature'), ('mushroom', 'Nature'), ('octopus', 'Animals'), ('paintbrush', 'Objects'),
  ('parachute', 'Objects'), ('penguin', 'Animals'), ('piano', 'Music'), ('pineapple', 'Food'),
  ('rainbow', 'Nature'), ('robot', 'Objects'), ('sandcastle', 'Places'), ('saxophone', 'Music'),
  ('snowman', 'Nature'), ('spaceship', 'Transport'), ('spider', 'Animals'), ('sunflower', 'Nature'),
  ('teapot', 'Objects'), ('telescope', 'Objects'), ('turtle', 'Animals'), ('volcano', 'Nature'),
  ('waterfall', 'Nature'), ('windmill', 'Places'), ('wizard', 'People')
on conflict (word) do nothing;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_rooms'
  ) then alter publication supabase_realtime add table public.scribble_rooms; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_members'
  ) then alter publication supabase_realtime add table public.scribble_members; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_drawing_batches'
  ) then alter publication supabase_realtime add table public.scribble_drawing_batches; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_events'
  ) then alter publication supabase_realtime add table public.scribble_events; end if;
end $$;


-- ===== 202610240003_scribble_server_actions.sql =====

create or replace function public.scribble_create_room(p_user_id uuid, p_name text, p_code text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype;
begin
  if p_user_id is null or char_length(btrim(p_name)) not between 1 and 24 or p_name ~ '[[:cntrl:]]'
     or p_code !~ '^[A-HJ-NP-Z2-9]{8}$' then raise exception 'Invalid player name or invite code.' using errcode = '22023'; end if;
  insert into public.player_profiles (user_id, display_name) values (p_user_id, btrim(p_name))
    on conflict (user_id) do update set display_name = excluded.display_name, updated_at = now();
  insert into public.scribble_rooms (invite_code, host_id) values (p_code, p_user_id) returning * into room;
  insert into public.scribble_members (room_id, user_id, display_name, seat, status, is_host)
    values (room.id, p_user_id, btrim(p_name), 1, 'active', true);
  return to_jsonb(room);
end $$;

create or replace function public.scribble_join_room(p_code text, p_user_id uuid, p_name text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; member public.scribble_members%rowtype; seats integer; occupied integer;
begin
  if p_user_id is null or p_name is null or char_length(btrim(p_name)) not between 1 and 24 or p_name ~ '[[:cntrl:]]' then
    raise exception 'Enter a valid display name before joining.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where invite_code = upper(btrim(p_code)) for update;
  if not found then raise exception 'This Scribble room was not found.' using errcode = 'P0002'; end if;
  if room.status = 'waiting' and room.invite_expires_at <= clock_timestamp() then
    update public.scribble_rooms set status = 'closed', phase = 'results', state_version = state_version + 1 where id = room.id;
    raise exception 'This invite has expired. Ask for a new room link.' using errcode = 'P0001'; end if;
  if room.status in ('results', 'closed') then raise exception 'This Scribble room has ended.' using errcode = 'P0001'; end if;
  insert into public.player_profiles (user_id, display_name) values (p_user_id, btrim(p_name))
    on conflict (user_id) do update set display_name = excluded.display_name, updated_at = now();
  select * into member from public.scribble_members where room_id = room.id and user_id = p_user_id for update;
  if found and member.status in ('active', 'waiting') then
    update public.scribble_members set display_name = btrim(p_name), last_seen_at = now()
      where room_id = room.id and user_id = p_user_id returning * into member;
  else
    select count(*) into occupied from public.scribble_members where room_id = room.id and status in ('active', 'waiting');
    if occupied >= room.max_players then raise exception 'This Scribble room is full.' using errcode = 'P0001'; end if;
    if room.status = 'waiting' then
      select coalesce(max(seat), 0) + 1 into seats from public.scribble_members where room_id = room.id and seat is not null;
      insert into public.scribble_members (room_id, user_id, display_name, seat, status)
        values (room.id, p_user_id, btrim(p_name), seats, 'active')
      on conflict (room_id, user_id) do update set display_name = excluded.display_name, seat = excluded.seat, status = 'active', left_at = null, last_seen_at = now()
      returning * into member;
    else
      insert into public.scribble_members (room_id, user_id, display_name, status)
        values (room.id, p_user_id, btrim(p_name), 'waiting')
      on conflict (room_id, user_id) do update set display_name = excluded.display_name, status = 'waiting', left_at = null, last_seen_at = now()
      returning * into member;
    end if;
  end if;
  update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = room.id returning * into room;
  return jsonb_build_object('room', to_jsonb(room), 'member', to_jsonb(member));
end $$;

create or replace function public.scribble_make_turn(p_room uuid, p_number integer, p_cycle smallint, p_drawer uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare options text[]; result_id uuid;
begin
  select array_agg(word order by random()) into options from
    (select word from public.scribble_word_bank where enabled order by random() limit 3) words;
  if cardinality(options) <> 3 then raise exception 'At least three Scribble words must be enabled.' using errcode = 'P0001'; end if;
  insert into public.scribble_turns (room_id, turn_number, cycle_number, drawer_id, choices)
    values (p_room, p_number, p_cycle, p_drawer, options) returning id into result_id;
  return result_id;
end $$;

create or replace function public.scribble_start_room(p_room_id uuid, p_user_id uuid, p_cycles smallint default 3)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; roster uuid[]; turn_id uuid;
begin
  if p_cycles not between 1 and 5 then raise exception 'Cycles must be between one and five.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'waiting' or room.invite_expires_at <= clock_timestamp() then raise exception 'This room can no longer start.' using errcode = 'P0001'; end if;
  if room.host_id <> p_user_id then raise exception 'Only the host can start the game.' using errcode = '42501'; end if;
  select array_agg(user_id order by gen_random_uuid()) into roster from public.scribble_members where room_id = p_room_id and status = 'active';
  if cardinality(roster) < 2 then raise exception 'At least two players are needed to start.' using errcode = 'P0001'; end if;
  turn_id := public.scribble_make_turn(p_room_id, 1, 1::smallint, roster[1]);
  update public.scribble_rooms set status = 'active', phase = 'choosing', cycles = p_cycles,
    turn_number = 1, cycle_number = 1, turn_order = roster, drawn_this_cycle = '{}', current_drawer_id = roster[1],
    current_turn_id = turn_id, phase_deadline = now() + make_interval(secs => choose_seconds),
    invite_expires_at = null, started_at = now(), state_version = state_version + 1, updated_at = now()
    where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;

create or replace function public.scribble_choose_word(p_room_id uuid, p_user_id uuid, p_word text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'choosing' or room.phase_deadline <= clock_timestamp() then raise exception 'The word choice window has ended.' using errcode = 'P0001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the drawer can choose a word.' using errcode = '42501'; end if;
  select * into turn from public.scribble_turns where id = room.current_turn_id for update;
  if not (btrim(p_word) = any(turn.choices)) then raise exception 'Choose one of the words provided.' using errcode = '22023'; end if;
  update public.scribble_turns set answer = btrim(p_word) where id = turn.id;
  update public.scribble_rooms set phase = 'drawing', phase_deadline = now() + make_interval(secs => draw_seconds),
    drawer_grace_deadline = null,
    canvas_revision = 0, public_state = jsonb_build_object('masked', regexp_replace(btrim(p_word), '[A-Za-z]', '_', 'g')),
    state_version = state_version + 1, updated_at = now()
    where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;

create or replace function public.scribble_guess(p_room_id uuid, p_user_id uuid, p_guess text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; player_name text;
  points integer; eligible integer; solved_count integer; inserted boolean; correct_answer text;
begin
  if p_guess is null or char_length(btrim(p_guess)) not between 1 and 80 or p_guess ~ '[[:cntrl:]]' then raise exception 'A guess must contain one to eighty characters.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_drawer_id = p_user_id then raise exception 'The drawer cannot guess.' using errcode = '42501'; end if;
  select display_name into player_name from public.scribble_members where room_id = p_room_id and user_id = p_user_id and status = 'active';
  if not found then raise exception 'Join this room before guessing.' using errcode = '42501'; end if;
  if (select count(*) from public.scribble_events where room_id = p_room_id and actor_id = p_user_id and event_type = 'guess' and created_at > now() - interval '10 seconds') >= 6 then
    raise exception 'Slow down before sending another guess.' using errcode = 'P0001'; end if;
  select * into turn from public.scribble_turns where id = room.current_turn_id for update;
  if exists (select 1 from public.scribble_solved where turn_id = turn.id and user_id = p_user_id) then return jsonb_build_object('correct', true, 'alreadySolved', true, 'points', 0); end if;
  correct_answer := lower(regexp_replace(btrim(turn.answer), '\s+', ' ', 'g'));
  if lower(regexp_replace(btrim(p_guess), '\s+', ' ', 'g')) <> correct_answer then
    insert into public.scribble_events (room_id, turn_id, actor_id, event_type, body) values
      (p_room_id, turn.id, p_user_id, 'guess', jsonb_build_object('name', player_name, 'text', btrim(p_guess)));
    update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id;
    return jsonb_build_object('correct', false, 'alreadySolved', false, 'points', 0);
  end if;
  points := 100 + greatest(0, least(100, round(100 * greatest(0, extract(epoch from (room.phase_deadline - clock_timestamp())) / room.draw_seconds)::numeric)::integer));
  insert into public.scribble_solved (room_id, turn_id, user_id, points) values (p_room_id, turn.id, p_user_id, points)
    on conflict (turn_id, user_id) do nothing returning true into inserted;
  if not coalesce(inserted, false) then return jsonb_build_object('correct', true, 'alreadySolved', true, 'points', 0); end if;
  insert into public.scribble_score_events (room_id, turn_id, recipient_id, source_user_id, event_type, points)
    values (p_room_id, turn.id, p_user_id, p_user_id, 'correct_guess', points),
           (p_room_id, turn.id, room.current_drawer_id, p_user_id, 'drawer_bonus', 25);
  update public.scribble_members set score = score + points where room_id = p_room_id and user_id = p_user_id;
  update public.scribble_members set score = score + 25 where room_id = p_room_id and user_id = room.current_drawer_id;
  insert into public.scribble_events (room_id, turn_id, actor_id, event_type, body)
    values (p_room_id, turn.id, p_user_id, 'correct', jsonb_build_object('name', player_name, 'text', player_name || ' guessed the word!', 'points', points));
  select count(*) into eligible from public.scribble_members where room_id = p_room_id and status = 'active' and user_id <> room.current_drawer_id;
  select count(*) into solved_count from public.scribble_solved where turn_id = turn.id;
  if eligible > 0 and solved_count >= eligible then
    update public.scribble_turns set ended_at = now() where id = turn.id;
    update public.scribble_rooms set phase = 'reveal', phase_deadline = now() + make_interval(secs => reveal_seconds),
      public_state = jsonb_build_object('answer', turn.answer, 'reason', 'all_solved'), state_version = state_version + 1, updated_at = now()
      where id = p_room_id;
    insert into public.scribble_events (room_id, turn_id, event_type, body) values
      (p_room_id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'Everyone found the word.'));
  else update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id; end if;
  return jsonb_build_object('correct', true, 'alreadySolved', false, 'points', points);
end $$;

create or replace function public.scribble_append_strokes(p_room_id uuid, p_user_id uuid, p_turn_id uuid, p_revision integer, p_strokes jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; seq bigint; batches integer; stroke jsonb; point jsonb;
begin
  if jsonb_typeof(p_strokes) <> 'array' or jsonb_array_length(p_strokes) not between 1 and 8 or octet_length(p_strokes::text) > 32768 then raise exception 'Drawing update is too large.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_turn_id is distinct from p_turn_id then raise exception 'The drawing turn changed.' using errcode = '40001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the current drawer can draw.' using errcode = '42501'; end if;
  if room.canvas_revision <> p_revision then raise exception 'Canvas revision changed.' using errcode = '40001'; end if;
  for stroke in select value from jsonb_array_elements(p_strokes) loop
    if jsonb_typeof(stroke) <> 'object' or stroke->>'tool' not in ('pen', 'eraser') or coalesce(length(stroke->>'id'), 0) not between 1 and 80
       or (stroke->>'tool' = 'pen' and coalesce(stroke->>'color', '') !~ '^#[0-9a-fA-F]{6}$')
       or jsonb_typeof(stroke->'points') <> 'array' or jsonb_array_length(stroke->'points') not between 1 and 64 then raise exception 'Invalid drawing stroke.' using errcode = '22023'; end if;
    if (stroke->>'width')::numeric not between 1 and 32 then raise exception 'Invalid stroke width.' using errcode = '22023'; end if;
    for point in select value from jsonb_array_elements(stroke->'points') loop
      if (point->>'x')::numeric not between 0 and 1 or (point->>'y')::numeric not between 0 and 1 then raise exception 'Drawing coordinates must be normalized.' using errcode = '22023'; end if;
    end loop;
  end loop;
  select count(*) into batches from public.scribble_drawing_batches where turn_id = room.current_turn_id and canvas_revision = p_revision;
  if batches >= 600 then raise exception 'Drawing turn reached its update limit.' using errcode = 'P0001'; end if;
  select coalesce(max(sequence), 0) + 1 into seq from public.scribble_drawing_batches where turn_id = room.current_turn_id and canvas_revision = p_revision;
  insert into public.scribble_drawing_batches (room_id, turn_id, canvas_revision, sequence, drawer_id, strokes)
    values (p_room_id, room.current_turn_id, p_revision, seq, p_user_id, p_strokes);
  update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id;
  return jsonb_build_object('sequence', seq, 'revision', p_revision);
end $$;

create or replace function public.scribble_clear_canvas(p_room_id uuid, p_user_id uuid, p_turn_id uuid, p_revision integer)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; revision integer;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_turn_id is distinct from p_turn_id then raise exception 'The drawing turn changed.' using errcode = '40001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the drawer can clear the canvas.' using errcode = '42501'; end if;
  if room.canvas_revision <> p_revision then raise exception 'Canvas revision changed.' using errcode = '40001'; end if;
  revision := p_revision + 1;
  update public.scribble_turns set canvas_revision = revision where id = room.current_turn_id;
  update public.scribble_rooms set canvas_revision = revision, state_version = state_version + 1, updated_at = now() where id = p_room_id;
  return jsonb_build_object('revision', revision);
end $$;

create or replace function public.scribble_ping(p_room_id uuid, p_user_id uuid)
returns timestamptz language plpgsql security definer set search_path = '' as $$
declare seen timestamptz;
begin
  update public.scribble_members set last_seen_at = now() where room_id = p_room_id and user_id = p_user_id and status in ('active', 'waiting') returning last_seen_at into seen;
  if seen is null then raise exception 'You are not an active member of this room.' using errcode = '42501'; end if;
  update public.scribble_rooms set drawer_grace_deadline = null
    where id = p_room_id and phase = 'drawing' and current_drawer_id = p_user_id and drawer_grace_deadline is not null;
  return seen;
end $$;

create or replace function public.scribble_leave_room(p_room_id uuid, p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; next_host uuid;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found then return jsonb_build_object('left', true); end if;
  update public.scribble_members set status = 'left', seat = null, left_at = now() where room_id = p_room_id and user_id = p_user_id and status <> 'left';
  if not found then return jsonb_build_object('left', true); end if;
  if room.current_drawer_id = p_user_id and room.phase in ('choosing', 'drawing') then
    select * into turn from public.scribble_turns where id = room.current_turn_id for update;
    update public.scribble_turns set ended_at = now() where id = turn.id;
    update public.scribble_rooms set phase = 'reveal', phase_deadline = now() + interval '3 seconds',
      public_state = jsonb_build_object('answer', turn.answer, 'reason', 'drawer_left'), state_version = state_version + 1, updated_at = now() where id = p_room_id;
    insert into public.scribble_events (room_id, turn_id, event_type, body) values
      (p_room_id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'The drawer left; the word is revealed.'));
  end if;
  if room.host_id = p_user_id then
    select user_id into next_host from public.scribble_members where room_id = p_room_id and status = 'active' order by seat limit 1;
    if next_host is null then update public.scribble_rooms set status = 'closed', phase = 'results', phase_deadline = null, state_version = state_version + 1, updated_at = now() where id = p_room_id;
    else
      update public.scribble_members set is_host = (user_id = next_host) where room_id = p_room_id and status = 'active';
      update public.scribble_rooms set host_id = next_host, state_version = state_version + 1, updated_at = now() where id = p_room_id;
    end if;
  else update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id; end if;
  return jsonb_build_object('left', true, 'hostId', next_host);
end $$;

create or replace function public.scribble_rematch(p_room_id uuid, p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.host_id <> p_user_id then raise exception 'Only the host can start a rematch.' using errcode = '42501'; end if;
  if room.status <> 'results' then raise exception 'The current Scribble game has not ended.' using errcode = 'P0001'; end if;
  delete from public.scribble_turns where room_id = p_room_id;
  delete from public.scribble_events where room_id = p_room_id;
  with seated as (
    select user_id, row_number() over (order by joined_at)::smallint as new_seat
    from public.scribble_members where room_id = p_room_id and status in ('active', 'waiting')
  )
  update public.scribble_members m set score = 0, status = 'active', seat = seated.new_seat, left_at = null, is_host = (m.user_id = p_user_id)
  from seated where m.room_id = p_room_id and m.user_id = seated.user_id;
  update public.scribble_rooms set status = 'waiting', phase = 'waiting', turn_number = 0, cycle_number = 0, turn_order = '{}',
    drawn_this_cycle = '{}', current_drawer_id = null, current_turn_id = null, phase_deadline = null, canvas_revision = 0,
    public_state = '{}'::jsonb, started_at = null, finished_at = null, invite_expires_at = now() + interval '10 minutes',
    state_version = state_version + 1, updated_at = now() where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;


-- ===== 202610240004_scribble_deadlines_and_privileges.sql =====

create or replace function public.scribble_advance_due_rooms(p_room_id uuid default null)
returns integer language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; player record;
  active_ids uuid[]; next_drawer uuid; next_turn uuid; next_number integer; processed integer := 0;
begin
  for room in select * from public.scribble_rooms
    where status = 'active' and (p_room_id is null or id = p_room_id) and (
      phase_deadline <= clock_timestamp()
      or (phase = 'drawing' and drawer_grace_deadline is not null and drawer_grace_deadline <= clock_timestamp())
      or (phase = 'drawing' and drawer_grace_deadline is null and phase_deadline > clock_timestamp()
        and exists (select 1 from public.scribble_members m where m.room_id = public.scribble_rooms.id
          and m.user_id = public.scribble_rooms.current_drawer_id and m.status = 'active'
          and m.last_seen_at < clock_timestamp() - interval '18 seconds'))
    )
    order by phase_deadline for update skip locked
  loop
    select * into turn from public.scribble_turns where id = room.current_turn_id for update;
    if room.phase = 'drawing' and room.phase_deadline > clock_timestamp() and exists (
      select 1 from public.scribble_members m where m.room_id = room.id and m.user_id = room.current_drawer_id
        and m.status = 'active' and m.last_seen_at < clock_timestamp() - interval '18 seconds'
    ) then
      if room.drawer_grace_deadline is null then
        update public.scribble_rooms set drawer_grace_deadline = clock_timestamp() + interval '15 seconds',
          state_version = state_version + 1, updated_at = now() where id = room.id;
        continue;
      elsif room.drawer_grace_deadline > clock_timestamp() then
        continue;
      else
        update public.scribble_turns set ended_at = now() where id = turn.id;
        update public.scribble_rooms set phase = 'reveal', phase_deadline = clock_timestamp() + make_interval(secs => room.reveal_seconds),
          drawer_grace_deadline = null, public_state = jsonb_build_object('answer', turn.answer, 'reason', 'drawer_disconnected'),
          state_version = state_version + 1, updated_at = now() where id = room.id;
        insert into public.scribble_events (room_id, turn_id, event_type, body) values
          (room.id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'The drawer did not reconnect in time.'));
        processed := processed + 1;
        continue;
      end if;
    end if;
    if room.phase = 'choosing' then
      update public.scribble_turns set answer = choices[1] where id = turn.id;
      update public.scribble_rooms set phase = 'drawing', phase_deadline = clock_timestamp() + make_interval(secs => room.draw_seconds),
        public_state = jsonb_build_object('masked', regexp_replace(btrim(turn.choices[1]), '[A-Za-z]', '_', 'g')),
        state_version = state_version + 1, updated_at = now() where id = room.id;
    elsif room.phase = 'drawing' then
      update public.scribble_turns set ended_at = now() where id = turn.id;
      update public.scribble_rooms set phase = 'reveal', phase_deadline = clock_timestamp() + make_interval(secs => room.reveal_seconds),
        public_state = jsonb_build_object('answer', turn.answer, 'reason', 'time'), state_version = state_version + 1, updated_at = now()
        where id = room.id;
      insert into public.scribble_events (room_id, turn_id, event_type, body) values
        (room.id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'Time is up.'));
    elsif room.phase = 'reveal' then
      room.drawn_this_cycle := array_append(room.drawn_this_cycle, room.current_drawer_id);
      for player in select user_id from public.scribble_members where room_id = room.id and status = 'waiting' order by joined_at for update loop
        update public.scribble_members set status = 'active',
          seat = (select coalesce(max(seat), 0) + 1 from public.scribble_members where room_id = room.id and status = 'active'),
          last_seen_at = now() where room_id = room.id and user_id = player.user_id;
        room.turn_order := array_append(room.turn_order, player.user_id);
      end loop;

      select array_agg(user_id order by seat) into active_ids
        from public.scribble_members where room_id = room.id and status = 'active';
      if coalesce(cardinality(active_ids), 0) < 2 then
        update public.scribble_rooms set status = 'results', phase = 'results', phase_deadline = null, finished_at = now(),
          public_state = jsonb_build_object('answer', turn.answer, 'reason', 'players_left'), state_version = state_version + 1, updated_at = now()
          where id = room.id;
      else
        if active_ids <@ room.drawn_this_cycle then
          if room.cycle_number >= room.cycles then
            update public.scribble_rooms set status = 'results', phase = 'results', phase_deadline = null, finished_at = now(),
              public_state = jsonb_build_object('answer', turn.answer, 'reason', 'complete'), state_version = state_version + 1, updated_at = now()
              where id = room.id;
          else
            room.cycle_number := room.cycle_number + 1;
            room.drawn_this_cycle := '{}';
          end if;
        end if;

        if room.cycle_number > 0 and not exists (
          select 1 from public.scribble_rooms r where r.id = room.id and r.status = 'results'
        ) then
          select roster.user_id into next_drawer
            from unnest(room.turn_order) with ordinality as roster(user_id, position)
            where roster.user_id = any(active_ids) and not (roster.user_id = any(room.drawn_this_cycle))
            order by roster.position limit 1;
          if next_drawer is null then
            next_drawer := active_ids[1];
            room.cycle_number := least(room.cycles, room.cycle_number + 1);
            room.drawn_this_cycle := '{}';
          end if;
          next_number := room.turn_number + 1;
          next_turn := public.scribble_make_turn(room.id, next_number, room.cycle_number, next_drawer);
          update public.scribble_rooms set phase = 'choosing', turn_number = next_number, cycle_number = room.cycle_number,
            turn_order = room.turn_order, drawn_this_cycle = room.drawn_this_cycle, current_drawer_id = next_drawer,
            current_turn_id = next_turn, phase_deadline = clock_timestamp() + make_interval(secs => room.choose_seconds),
            drawer_grace_deadline = null, canvas_revision = 0, public_state = '{}'::jsonb, state_version = state_version + 1, updated_at = now()
            where id = room.id;
        end if;
      end if;
    end if;
    processed := processed + 1;
  end loop;
  return processed;
end $$;

-- Cron is the authoritative fallback for deadlines when every player is offline.
do $$
declare job_id bigint;
begin
  for job_id in select jobid from cron.job where jobname in ('scribble-advance-deadlines', 'scribble-cleanup-expired-invites') loop
    perform cron.unschedule(job_id);
  end loop;
  perform cron.schedule('scribble-advance-deadlines', '* * * * *', 'select public.scribble_advance_due_rooms();');
  perform cron.schedule('scribble-cleanup-expired-invites', '* * * * *', $cleanup$
    delete from public.scribble_rooms where status = 'waiting' and invite_expires_at <= now();
    delete from public.scribble_rooms where status in ('results', 'closed') and updated_at < now() - interval '30 days';
  $cleanup$);
end $$;

revoke all on function public.scribble_create_room(uuid, text, text), public.scribble_join_room(text, uuid, text),
  public.scribble_start_room(uuid, uuid, smallint), public.scribble_choose_word(uuid, uuid, text),
  public.scribble_guess(uuid, uuid, text), public.scribble_append_strokes(uuid, uuid, uuid, integer, jsonb),
  public.scribble_clear_canvas(uuid, uuid, uuid, integer), public.scribble_ping(uuid, uuid),
  public.scribble_leave_room(uuid, uuid), public.scribble_rematch(uuid, uuid), public.scribble_advance_due_rooms(uuid),
  public.scribble_make_turn(uuid, integer, smallint, uuid)
from public, anon, authenticated;
grant execute on function public.scribble_create_room(uuid, text, text), public.scribble_join_room(text, uuid, text),
  public.scribble_start_room(uuid, uuid, smallint), public.scribble_choose_word(uuid, uuid, text),
  public.scribble_guess(uuid, uuid, text), public.scribble_append_strokes(uuid, uuid, uuid, integer, jsonb),
  public.scribble_clear_canvas(uuid, uuid, uuid, integer), public.scribble_ping(uuid, uuid),
  public.scribble_leave_room(uuid, uuid), public.scribble_rematch(uuid, uuid), public.scribble_advance_due_rooms(uuid),
  public.scribble_make_turn(uuid, integer, smallint, uuid)
to service_role;
grant execute on function public.scribble_advance_due_rooms(uuid) to postgres;


-- ===== 202610240005_daily_game_completions.sql =====

-- Server-side daily awards use the same 06:00 Asia/Kolkata tracking-day boundary as the app.
create table if not exists public.player_daily_completions (
  user_id uuid not null references auth.users (id) on delete cascade,
  tracking_day date not null,
  source text not null check (source in ('chess', 'scribble')),
  completed_at timestamptz not null default now(),
  primary key (user_id, tracking_day)
);

alter table public.player_daily_completions enable row level security;
revoke all on public.player_daily_completions from anon, authenticated;
grant select on public.player_daily_completions to authenticated;
create policy "Players read their own completed days" on public.player_daily_completions
  for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.record_daily_game_completion(p_user_id uuid, p_source text, p_at timestamptz default clock_timestamp())
returns void language plpgsql security definer set search_path = '' as $$
declare day_key date;
begin
  if p_user_id is null or p_source not in ('chess', 'scribble') then return; end if;
  day_key := ((p_at at time zone 'Asia/Kolkata') - interval '6 hours')::date;
  insert into public.player_daily_completions (user_id, tracking_day, source)
    values (p_user_id, day_key, p_source)
    on conflict (user_id, tracking_day) do nothing;
end $$;

create or replace function public.record_finished_chess_room()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'finished' and old.status is distinct from 'finished' then
    perform public.record_daily_game_completion(new.host_id, 'chess', clock_timestamp());
    if new.guest_id is not null then perform public.record_daily_game_completion(new.guest_id, 'chess', clock_timestamp()); end if;
  end if;
  return new;
end $$;

create trigger chess_room_daily_completion
  after update of status on public.chess_rooms
  for each row execute function public.record_finished_chess_room();

create or replace function public.record_finished_scribble_room()
returns trigger language plpgsql security definer set search_path = '' as $$
declare player record;
begin
  if new.status = 'results' and old.status is distinct from 'results' then
    for player in select user_id from public.scribble_members where room_id = new.id and status = 'active' loop
      perform public.record_daily_game_completion(player.user_id, 'scribble', clock_timestamp());
    end loop;
  end if;
  return new;
end $$;

create trigger scribble_room_daily_completion
  after update of status on public.scribble_rooms
  for each row execute function public.record_finished_scribble_room();

revoke all on function public.record_daily_game_completion(uuid, text, timestamptz),
  public.record_finished_chess_room(), public.record_finished_scribble_room()
from public, anon, authenticated;


-- ===== 202610240006_require_verified_players.sql =====

-- Client route guards are a usability layer; enforce permanent, verified accounts at the data boundary too.
do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'chess_rooms',
    'player_profiles',
    'player_daily_completions',
    'scribble_rooms',
    'scribble_members',
    'scribble_drawing_batches',
    'scribble_events',
    'scribble_solved',
    'scribble_score_events'
  ] loop
    execute format('drop policy if exists "Require permanent account" on public.%I', table_name);
    execute format(
      'create policy "Require permanent account" on public.%I as restrictive for select to authenticated using (coalesce(auth.jwt() ->> ''is_anonymous'', ''false'') <> ''true'')',
      table_name
    );
  end loop;
end $$;

alter table public.player_profiles add column if not exists username text;
create unique index if not exists player_profiles_username_lower_uidx
  on public.player_profiles (lower(username))
  where username is not null;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'player_profiles_username_valid'
      and conrelid = 'public.player_profiles'::regclass
  ) then
    alter table public.player_profiles add constraint player_profiles_username_valid
      check (username is null or (username = lower(username) and username ~ '^[a-z0-9._-]{3,20}$'));
  end if;
end $$;

drop policy if exists "Require permanent account profile writes" on public.player_profiles;
create policy "Require permanent account profile writes"
  on public.player_profiles as restrictive for all to authenticated
  using (coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true')
  with check (coalesce(auth.jwt() ->> 'is_anonymous', 'false') <> 'true');
create table public.trophy_wallets (
  user_id uuid primary key references auth.users (id) on delete cascade,
  silver integer not null default 0 check (silver >= 0),
  gold integer not null default 0 check (gold >= 0),
  updated_at timestamptz not null default now()
);

create table public.trophy_transactions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  currency text not null check (currency in ('silver', 'gold')),
  amount integer not null check (amount <> 0),
  source text not null check (source in ('computer_chess', 'multiplayer_chess', 'conversion')),
  source_id uuid not null,
  created_at timestamptz not null default now(),
  unique (user_id, currency, source, source_id)
);

create table public.trophy_ai_matches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  player_color text not null check (player_color in ('w', 'b')),
  status text not null default 'active' check (status in ('active', 'settled')),
  result text check (result in ('win', 'loss', 'draw')),
  started_at timestamptz not null default now(),
  settled_at timestamptz
);

create table public.trophy_chess_awards (
  room_id uuid primary key references public.chess_rooms (id) on delete cascade,
  winner_id uuid not null references auth.users (id) on delete cascade,
  awarded_at timestamptz not null default now()
);

alter table public.trophy_wallets enable row level security;
alter table public.trophy_transactions enable row level security;
alter table public.trophy_ai_matches enable row level security;
alter table public.trophy_chess_awards enable row level security;

revoke all on public.trophy_wallets, public.trophy_transactions, public.trophy_ai_matches, public.trophy_chess_awards from anon, authenticated;
grant all on public.trophy_wallets, public.trophy_transactions, public.trophy_ai_matches, public.trophy_chess_awards to service_role;
grant usage, select on sequence public.trophy_transactions_id_seq to service_role;
grant select on public.trophy_wallets to authenticated;
grant select on public.trophy_transactions to authenticated;

create policy "Players read their own trophy wallet" on public.trophy_wallets
  for select to authenticated using (user_id = (select auth.uid()));
create policy "Players read their own trophy history" on public.trophy_transactions
  for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.seed_trophy_wallet()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.trophy_wallets (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists seed_new_player_trophy_wallet on auth.users;
create trigger seed_new_player_trophy_wallet after insert on auth.users
  for each row execute function public.seed_trophy_wallet();

insert into public.trophy_wallets (user_id)
select id from auth.users on conflict (user_id) do nothing;

create or replace function public.convert_silver_trophies(p_silver_amount integer)
returns table(silver integer, gold integer)
language plpgsql security definer set search_path = '' as $$
declare
  player_id uuid := (select auth.uid());
  conversion_id uuid := gen_random_uuid();
  wallet public.trophy_wallets%rowtype;
begin
  if player_id is null then raise exception 'Sign in to convert trophies.' using errcode = '28000'; end if;
  if p_silver_amount is null or p_silver_amount < 100 or mod(p_silver_amount, 100) <> 0 then
    raise exception 'Convert silver in multiples of 100.' using errcode = '22023';
  end if;

  insert into public.trophy_wallets (user_id) values (player_id) on conflict (user_id) do nothing;
  update public.trophy_wallets as wallet_row
    set silver = wallet_row.silver - p_silver_amount,
        gold = wallet_row.gold + (p_silver_amount / 2),
        updated_at = now()
    where wallet_row.user_id = player_id and wallet_row.silver >= p_silver_amount
    returning wallet_row.* into wallet;
  if not found then raise exception 'You do not have enough silver trophies.' using errcode = 'P0001'; end if;

  insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
    values (player_id, 'silver', -p_silver_amount, 'conversion', conversion_id),
           (player_id, 'gold', p_silver_amount / 2, 'conversion', conversion_id);
  return query select wallet.silver, wallet.gold;
end $$;

create or replace function public.start_trophy_ai_match(p_player_color text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  player_id uuid := (select auth.uid());
  match_id uuid;
begin
  if player_id is null then raise exception 'Sign in to play for trophies.' using errcode = '28000'; end if;
  if p_player_color not in ('w', 'b') then raise exception 'Choose a valid player color.' using errcode = '22023'; end if;
  insert into public.trophy_wallets (user_id) values (player_id) on conflict (user_id) do nothing;
  insert into public.trophy_ai_matches (user_id, player_color) values (player_id, p_player_color) returning id into match_id;
  return match_id;
end $$;

create or replace function public.settle_trophy_ai_match(p_match_id uuid, p_result text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  match_row public.trophy_ai_matches%rowtype;
  wallet public.trophy_wallets%rowtype;
  award integer := 0;
begin
  if p_result not in ('win', 'loss', 'draw') then raise exception 'Invalid match result.' using errcode = '22023'; end if;
  select * into match_row from public.trophy_ai_matches where id = p_match_id for update;
  if not found then raise exception 'Trophy match was not found.' using errcode = 'P0002'; end if;
  if match_row.status = 'settled' then
    select * into wallet from public.trophy_wallets where user_id = match_row.user_id;
    return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'alreadySettled', true);
  end if;
  if match_row.started_at < now() - interval '12 hours' then raise exception 'This trophy match has expired.' using errcode = 'P0001'; end if;

  insert into public.trophy_wallets (user_id) values (match_row.user_id) on conflict (user_id) do nothing;
  select * into wallet from public.trophy_wallets where user_id = match_row.user_id for update;
  if p_result = 'win' then award := 200;
  elsif p_result = 'loss' and wallet.silver >= 200 then award := -20;
  end if;

  update public.trophy_wallets
    set silver = silver + award, updated_at = now()
    where user_id = match_row.user_id returning * into wallet;
  update public.trophy_ai_matches set status = 'settled', result = p_result, settled_at = now() where id = p_match_id;
  if award <> 0 then
    insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
      values (match_row.user_id, 'silver', award, 'computer_chess', p_match_id);
  end if;
  return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'awardedSilver', award, 'alreadySettled', false);
end $$;

alter table public.chess_rooms add column if not exists winner_id uuid references auth.users (id) on delete set null;

create or replace function public.award_finished_chess_trophies()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status <> 'finished' or old.status = 'finished' or new.winner_id is null then return new; end if;
  if new.winner_id <> new.host_id and new.winner_id is distinct from new.guest_id then
    raise exception 'Chess winner must be a player in this room.' using errcode = '22023';
  end if;
  insert into public.trophy_wallets (user_id) values (new.winner_id) on conflict (user_id) do nothing;
  insert into public.trophy_chess_awards (room_id, winner_id) values (new.id, new.winner_id)
    on conflict (room_id) do nothing;
  if not found then return new; end if;
  update public.trophy_wallets set gold = gold + 500, updated_at = now() where user_id = new.winner_id;
  insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
    values (new.winner_id, 'gold', 500, 'multiplayer_chess', new.id);
  return new;
end $$;

drop trigger if exists chess_room_trophy_award on public.chess_rooms;
create trigger chess_room_trophy_award after update of status, winner_id on public.chess_rooms
  for each row execute function public.award_finished_chess_trophies();

drop function if exists public.append_chess_move(uuid, uuid, integer, text, boolean);
create function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean,
  p_winner_id uuid
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room from public.chess_rooms where id = p_room_id for update;
  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;
  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;
  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;
  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;
  if (p_finished and p_winner_id is not null and p_winner_id <> p_player_id)
     or (not p_finished and p_winner_id is not null) then
    raise exception 'The reported chess winner is invalid.' using errcode = '22023';
  end if;

  update public.chess_rooms
    set moves = array_append(moves, p_san), ply = ply + 1,
        status = case when p_finished then 'finished' else 'active' end,
        winner_id = case when p_finished then p_winner_id else null end,
        updated_at = now()
    where id = p_room_id and ply = p_expected_ply
    returning * into updated_room;
  if not found then raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001'; end if;
  return to_jsonb(updated_room);
end $$;

create or replace function public.get_trophy_leaderboard()
returns table(rank_position bigint, user_id uuid, username text, display_name text, silver integer, gold integer)
language sql stable security definer set search_path = '' as $$
  select row_number() over (order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc),
         wallet.user_id, profile.username, profile.display_name, wallet.silver, wallet.gold
  from public.trophy_wallets as wallet
  join public.player_profiles as profile on profile.user_id = wallet.user_id
  where profile.username is not null and btrim(profile.username) <> ''
  order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc
  limit 100;
$$;

revoke all on function public.seed_trophy_wallet(), public.award_finished_chess_trophies() from public, anon, authenticated;
revoke all on function public.convert_silver_trophies(integer), public.start_trophy_ai_match(text), public.settle_trophy_ai_match(uuid, text), public.get_trophy_leaderboard() from public, anon;
grant execute on function public.convert_silver_trophies(integer), public.start_trophy_ai_match(text), public.get_trophy_leaderboard() to authenticated;
grant execute on function public.settle_trophy_ai_match(uuid, text) to service_role;
revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean, uuid) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean, uuid) to service_role;
