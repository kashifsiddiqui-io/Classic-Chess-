create table if not exists public.chess_hint_rate_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  window_started_at timestamptz not null default now(),
  last_requested_at timestamptz not null default now(),
  request_count integer not null default 1 check (request_count between 1 and 40)
);

alter table public.chess_hint_rate_limits enable row level security;
revoke all on table public.chess_hint_rate_limits from public, anon, authenticated;
grant all on table public.chess_hint_rate_limits to service_role;

create or replace function public.allow_chess_hint_request(p_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  request_allowed boolean;
begin
  if p_user_id is null then
    return false;
  end if;

  insert into public.chess_hint_rate_limits (user_id)
  values (p_user_id)
  on conflict (user_id) do update
    set window_started_at = case
          when public.chess_hint_rate_limits.window_started_at <= now() - interval '24 hours' then now()
          else public.chess_hint_rate_limits.window_started_at
        end,
        last_requested_at = now(),
        request_count = case
          when public.chess_hint_rate_limits.window_started_at <= now() - interval '24 hours' then 1
          else public.chess_hint_rate_limits.request_count + 1
        end
    where public.chess_hint_rate_limits.last_requested_at <= now() - interval '3 seconds'
      and (
        public.chess_hint_rate_limits.window_started_at <= now() - interval '24 hours'
        or public.chess_hint_rate_limits.request_count < 40
      )
  returning true into request_allowed;

  return coalesce(request_allowed, false);
end;
$$;

revoke all on function public.allow_chess_hint_request(uuid) from public, anon, authenticated;
grant execute on function public.allow_chess_hint_request(uuid) to service_role;
