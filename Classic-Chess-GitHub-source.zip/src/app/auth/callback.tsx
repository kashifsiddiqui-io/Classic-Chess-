import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import type { EmailOtpType } from '@supabase/supabase-js';

import { clearPendingAuthProfile, completeAuthProfile, consumeAuthReturnTo, consumePendingAuthProfile, readAuthReturnTo } from '@/lib/auth-profile';
import { getSupabase } from '@/lib/supabase';

const validOtpTypes: EmailOtpType[] = ['signup', 'invite', 'magiclink', 'recovery', 'email_change', 'email'];

export default function AuthCallbackScreen() {
  const params = useLocalSearchParams<{ code?: string | string[]; token_hash?: string | string[]; type?: string | string[]; error_description?: string | string[] }>();
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    const first = (value?: string | string[]) => Array.isArray(value) ? value[0] : value;

    void (async () => {
      try {
        const supabase = getSupabase();
        if (!supabase) throw new Error('Supabase is not configured.');
        const authError = first(params.error_description);
        if (authError) {
          await clearPendingAuthProfile();
          throw new Error(decodeURIComponent(authError.replace(/\+/g, ' ')));
        }

        const code = first(params.code);
        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) throw new Error(exchangeError.message);
        } else {
          const tokenHash = first(params.token_hash);
          const type = first(params.type);
          if (!tokenHash || !type || !validOtpTypes.includes(type as EmailOtpType)) {
            throw new Error('The sign-in link is incomplete or expired. Return to sign in and request a new link.');
          }
          const { error: verifyError } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: type as EmailOtpType });
          if (verifyError) throw new Error(verifyError.message);
        }

        const { data, error: userError } = await supabase.auth.getUser();
        if (userError || !data.user || data.user.is_anonymous || !data.user.email_confirmed_at) {
          throw new Error(userError?.message || 'Verify your email before continuing.');
        }
        const pendingProfile = await consumePendingAuthProfile();
        await completeAuthProfile(supabase, data.user, pendingProfile);
        const target = await consumeAuthReturnTo();
        if (active) router.replace(target as never);
      } catch (cause) {
        const message = cause instanceof Error ? cause.message : '';
        if (message.startsWith('USERNAME_TAKEN:')) {
          const target = await readAuthReturnTo();
          if (active) router.replace({ pathname: '/auth', params: { profileSetup: '1', profileError: 'username', returnTo: target } });
          return;
        }
        await clearPendingAuthProfile();
        if (active) setError(message || 'Could not complete sign-in. Request a new email link and try again.');
      }
    })();

    return () => { active = false; };
  }, [params.code, params.error_description, params.token_hash, params.type]);

  return <SafeAreaView style={styles.safe}>
    <StatusBar style="dark" animated />
    <View style={styles.content}>
      {error ? <>
        <Text style={styles.title}>We couldn’t finish sign-in</Text>
        <Text style={styles.error}>{error}</Text>
        <Text onPress={() => router.replace('/auth')} style={styles.action}>RETURN TO SIGN IN</Text>
      </> : <>
        <ActivityIndicator color="#4e7c6e" size="small" />
        <Text style={styles.title}>Finishing your sign-in…</Text>
        <Text style={styles.subtitle}>We’re securing your player profile.</Text>
      </>}
    </View>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f4f3ef' },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  title: { color: '#1f2c26', fontSize: 21, fontWeight: '800', marginTop: 17, textAlign: 'center' },
  subtitle: { color: '#69756e', fontSize: 12, marginTop: 6, textAlign: 'center' },
  error: { color: '#9c4036', fontSize: 12, lineHeight: 18, textAlign: 'center', marginTop: 8 },
  action: { color: '#4e7c6e', fontSize: 11, fontWeight: '900', letterSpacing: 1.3, marginTop: 20, padding: 10 },
});
