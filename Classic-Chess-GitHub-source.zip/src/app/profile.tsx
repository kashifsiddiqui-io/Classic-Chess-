import { router, useFocusEffect } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { TrophyIcon } from '@/components/trophy-icon';
import { useAuth } from '@/context/auth';
import { completeAuthProfile, profileFromUser } from '@/lib/auth-profile';
import { loadTrophyWallet, emptyTrophyWallet, type TrophyWallet } from '@/lib/trophies';
import { getSupabase } from '@/lib/supabase';

const green = '#4e7c6e';
const ink = '#1f2c26';

export default function ProfileScreen() {
  const { user } = useAuth();
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [draftName, setDraftName] = useState('');
  const [draftUsername, setDraftUsername] = useState('');
  const [wallet, setWallet] = useState<TrophyWallet>(emptyTrophyWallet);
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useFocusEffect(useCallback(() => {
    let active = true;
    const supabase = getSupabase();
    if (!supabase || !user?.id) {
      setError('Sign in to view and edit your profile.');
      setLoading(false);
      return () => { active = false; };
    }

    const fallback = profileFromUser(user);
    setLoading(true);
    setError('');
    void Promise.all([
      supabase.from('player_profiles').select('display_name, username').eq('user_id', user.id).maybeSingle(),
      loadTrophyWallet(supabase, user.id),
    ]).then(([profileResult, nextWallet]) => {
      if (!active) return;
      if (profileResult.error) throw new Error(profileResult.error.message || 'Could not load your profile.');
      const nextName = typeof profileResult.data?.display_name === 'string' && profileResult.data.display_name.trim()
        ? profileResult.data.display_name.trim() : fallback.name;
      const nextUsername = typeof profileResult.data?.username === 'string' && profileResult.data.username.trim()
        ? profileResult.data.username.trim() : fallback.username;
      setDisplayName(nextName);
      setUsername(nextUsername);
      setDraftName(nextName);
      setDraftUsername(nextUsername);
      setWallet(nextWallet);
    }).catch((cause: unknown) => {
      if (active) setError(cause instanceof Error ? cause.message : 'Could not load your profile.');
    }).finally(() => { if (active) setLoading(false); });

    return () => { active = false; };
  }, [user]));

  async function saveProfile() {
    if (!user) return;
    const supabase = getSupabase();
    if (!supabase) {
      setError('Profile service is unavailable. Check the app configuration and try again.');
      return;
    }
    const cleanName = draftName.trim().replace(/\s+/g, ' ').slice(0, 24);
    const cleanUsername = draftUsername.trim().replace(/^@/, '').toLowerCase();
    if (!cleanName) {
      setError('Enter your display name.');
      return;
    }
    if (!/^[a-z0-9._-]{3,20}$/.test(cleanUsername)) {
      setError('Username must be 3–20 characters using letters, numbers, dots, underscores or hyphens.');
      return;
    }

    setSaving(true);
    setError('');
    setNotice('');
    try {
      await completeAuthProfile(supabase, user, { name: cleanName, username: cleanUsername, savedAt: Date.now() });
      setDisplayName(cleanName);
      setUsername(cleanUsername);
      setDraftName(cleanName);
      setDraftUsername(cleanUsername);
      setEditing(false);
      setNotice('Profile saved. Your leaderboard name will use your display name.');
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'Could not save your profile.';
      setError(message.startsWith('USERNAME_TAKEN:') ? 'That username is already in use. Choose another one.' : message);
    } finally {
      setSaving(false);
    }
  }

  function cancelEditing() {
    setDraftName(displayName);
    setDraftUsername(username);
    setEditing(false);
    setError('');
  }

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <StatusBar style="dark" animated />
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      <Pressable onPress={() => router.back()} style={styles.back} accessibilityRole="button"><Text style={styles.backText}>← Back</Text></Pressable>

      <View style={styles.heading}>
        <View style={styles.avatar}><Text style={styles.avatarText}>{(displayName || 'C').slice(0, 1).toUpperCase()}</Text></View>
        <View style={styles.headingCopy}>
          <Text style={styles.eyebrow}>CLASSIC CHESS PROFILE</Text>
          <Text style={styles.title}>{displayName || 'Your profile'}</Text>
          <Text style={styles.username}>@{username || 'username'}</Text>
        </View>
      </View>

      <View style={styles.accountCard}>
        <View style={styles.sectionHead}><Text style={styles.sectionTitle}>Account</Text>
          {!editing ? <Pressable onPress={() => { setError(''); setNotice(''); setEditing(true); }} style={styles.editButton} accessibilityRole="button"><Text style={styles.editButtonText}>Edit profile</Text></Pressable> : null}
        </View>

        {editing ? <>
          <Text style={styles.fieldLabel}>DISPLAY NAME</Text>
          <TextInput value={draftName} onChangeText={(value) => { setDraftName(value.slice(0, 24)); setError(''); }} maxLength={24} autoCapitalize="words" autoCorrect={false} placeholder="Your name" placeholderTextColor="#89958d" style={styles.input} accessibilityLabel="Display name" />
          <Text style={styles.fieldLabel}>USERNAME</Text>
          <TextInput value={draftUsername} onChangeText={(value) => { setDraftUsername(value.replace(/\s/g, '').replace(/^@/, '').slice(0, 20)); setError(''); }} maxLength={20} autoCapitalize="none" autoCorrect={false} placeholder="your.username" placeholderTextColor="#89958d" style={styles.input} accessibilityLabel="Username" />
          <Text style={styles.helper}>Your username is unique. Your display name appears on the leaderboard.</Text>
          <View style={styles.formActions}>
            <Pressable onPress={cancelEditing} disabled={saving} style={[styles.cancelButton, saving && styles.disabled]} accessibilityRole="button"><Text style={styles.cancelText}>Cancel</Text></Pressable>
            <Pressable onPress={() => void saveProfile()} disabled={saving} style={[styles.saveButton, saving && styles.disabled]} accessibilityRole="button">{saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveText}>Save profile</Text>}</Pressable>
          </View>
        </> : <>
          <Text style={styles.fieldLabel}>DISPLAY NAME</Text>
          <Text style={styles.accountValue}>{displayName || 'Add your display name'}</Text>
          <View style={styles.separator} />
          <Text style={styles.fieldLabel}>USERNAME</Text>
          <Text style={styles.accountValue}>@{username || 'username'}</Text>
          <View style={styles.separator} />
          <Text style={styles.fieldLabel}>EMAIL</Text>
          <Text selectable style={styles.accountValue}>{user?.email || 'No email on this account'}</Text>
        </>}
      </View>

      <Pressable onPress={() => router.push('/trophy')} style={({ pressed }) => [styles.trophyCard, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Open trophy wallet. ${wallet.silver} silver and ${wallet.gold} gold trophies`}>
        <View style={styles.trophyCardHeading}>
          <View style={styles.trophyHeadingCopy}><Text style={styles.fieldLabel}>YOUR REWARDS</Text><Text style={styles.trophyTitle}>Trophy wallet</Text></View>
          <Text style={styles.walletArrow}>↗</Text>
        </View>
        <View style={styles.walletRow}>
          <View style={styles.walletBalance}>
            <TrophyIcon metal="silver" label="Silver trophy" size={50} showBackdrop={false} idPrefix="profile-silver" />
            <View><Text style={styles.balanceLabel}>SILVER</Text><Text style={styles.balanceValue}>{wallet.silver}</Text></View>
          </View>
          <View style={styles.walletDivider} />
          <View style={styles.walletBalance}>
            <TrophyIcon metal="gold" label="Gold trophy" size={50} showBackdrop={false} idPrefix="profile-gold" />
            <View><Text style={styles.balanceLabelGold}>GOLD</Text><Text style={styles.balanceValue}>{wallet.gold}</Text></View>
          </View>
        </View>
        <Text style={styles.trophyHint}>Open wallet to see rewards and conversion options</Text>
      </Pressable>

      {loading ? <View style={styles.loading}><ActivityIndicator color={green} /><Text style={styles.loadingText}>Loading your profile…</Text></View> : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {notice ? <Text style={styles.notice}>{notice}</Text> : null}
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f7f7f4' },
  content: { width: '100%', maxWidth: 600, alignSelf: 'center', paddingHorizontal: 20, paddingTop: 12, paddingBottom: 32 },
  back: { alignSelf: 'flex-start', paddingVertical: 9, paddingHorizontal: 14, marginBottom: 21, borderRadius: 18, backgroundColor: '#202923' },
  backText: { color: '#fff', fontSize: 11, fontWeight: '800' },
  heading: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 22 },
  avatar: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e5eee8', borderWidth: 1, borderColor: '#d4e1d8' },
  avatarText: { color: green, fontSize: 23, fontWeight: '900' },
  headingCopy: { flex: 1, minWidth: 0 },
  eyebrow: { color: green, fontSize: 8, fontWeight: '900', letterSpacing: 1.6 },
  title: { color: ink, fontSize: 25, fontWeight: '900', letterSpacing: -0.7, marginTop: 4 },
  username: { color: '#7a867e', fontSize: 11, fontWeight: '700', marginTop: 3 },
  accountCard: { padding: 17, borderRadius: 23, borderWidth: 1, borderColor: '#dfe7e0', backgroundColor: '#fff', shadowColor: '#263a30', shadowOpacity: 0.05, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 15 },
  sectionTitle: { color: ink, fontSize: 17, fontWeight: '900', letterSpacing: -0.3 },
  editButton: { minHeight: 32, justifyContent: 'center', paddingHorizontal: 13, borderRadius: 16, backgroundColor: '#eaf2ed' },
  editButtonText: { color: green, fontSize: 10, fontWeight: '900' },
  fieldLabel: { color: '#839087', fontSize: 8, fontWeight: '900', letterSpacing: 1.2 },
  accountValue: { color: ink, fontSize: 14, fontWeight: '700', marginTop: 5 },
  separator: { height: 1, backgroundColor: '#edf1ed', marginVertical: 13 },
  input: { minHeight: 47, borderWidth: 1, borderColor: '#dce5de', borderRadius: 14, backgroundColor: '#fbfcfa', paddingHorizontal: 13, marginTop: 7, marginBottom: 14, color: ink, fontSize: 14, outlineStyle: 'none' } as object,
  helper: { color: '#849087', fontSize: 10, lineHeight: 15, marginTop: -7 },
  formActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 9, marginTop: 15 },
  cancelButton: { minHeight: 42, justifyContent: 'center', paddingHorizontal: 16, borderRadius: 14, backgroundColor: '#eef2ee' },
  cancelText: { color: '#58665d', fontSize: 11, fontWeight: '800' },
  saveButton: { minWidth: 120, minHeight: 42, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, borderRadius: 14, backgroundColor: green },
  saveText: { color: '#fff', fontSize: 11, fontWeight: '900' },
  disabled: { opacity: 0.65 },
  trophyCard: { marginTop: 15, padding: 17, borderRadius: 23, borderWidth: 1, borderColor: '#dce6dd', backgroundColor: '#fff', shadowColor: '#263a30', shadowOpacity: 0.05, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  trophyCardHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  trophyHeadingCopy: { gap: 4 },
  trophyTitle: { color: ink, fontSize: 18, fontWeight: '900', letterSpacing: -0.4 },
  walletArrow: { color: green, fontSize: 20, fontWeight: '800' },
  walletRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 13, paddingVertical: 9 },
  walletBalance: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  walletDivider: { width: 1, height: 44, backgroundColor: '#e8ede9', marginHorizontal: 4 },
  balanceLabel: { color: '#73828a', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 },
  balanceLabelGold: { color: '#a98232', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 },
  balanceValue: { color: ink, fontSize: 23, fontWeight: '900', marginTop: 1, fontVariant: ['tabular-nums'] },
  trophyHint: { color: '#849087', fontSize: 10, marginTop: 4 },
  pressed: { opacity: 0.85, transform: [{ scale: 0.99 }] },
  loading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 16 },
  loadingText: { color: '#78847c', fontSize: 11 },
  error: { color: '#a33b32', fontSize: 11, lineHeight: 16, marginTop: 13 },
  notice: { color: green, fontSize: 11, lineHeight: 16, fontWeight: '700', marginTop: 13 },
});
