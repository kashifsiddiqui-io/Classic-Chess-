-- Additive Scribble schema. This migration does not modify or drop chess data.
create extension if not exists pgcrypto;

create table public.player_profiles (
  user_id uuid primary key references auth.users (id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 24),
  updated_at timestamptz not null default now()
);

create table public.scribble_rooms (
  id uuid primary key default gen_random_uuid(),
  invite_code text not null unique check (invite_code ~ '^[A-HJ-NP-Z2-9]{8}$'),
  host_id uuid not null references auth.users (id) on delete cascade,
  status text not null default 'waiting' check (status in ('waiting', 'active', 'results', 'closed')),
  phase text not null default 'waiting' check (phase in ('waiting', 'choosing', 'drawing', 'reveal', 'results')),
  max_players smallint not null default 8 check (max_players between 2 and 8),
  cycles smallint not null default 3 check (cycles between 1 and 5),
  choose_seconds smallint not null default 15 check (choose_seconds between 5 and 30),
  draw_seconds smallint not null default 60 check (draw_seconds between 30 and 120),
  reveal_seconds smallint not null default 5 check (reveal_seconds between 3 and 12),
  state_version bigint not null default 0 check (state_version >= 0),
  turn_number integer not null default 0 check (turn_number >= 0),
  cycle_number smallint not null default 0 check (cycle_number >= 0),
  turn_order uuid[] not null default '{}',
  drawn_this_cycle uuid[] not null default '{}',
  current_drawer_id uuid references auth.users (id) on delete set null,
  current_turn_id uuid,
  phase_deadline timestamptz,
  drawer_grace_deadline timestamptz,
  canvas_revision integer not null default 0 check (canvas_revision >= 0),
  public_state jsonb not null default '{}'::jsonb check (jsonb_typeof(public_state) = 'object'),
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz,
  invite_expires_at timestamptz default (now() + interval '10 minutes'),
  updated_at timestamptz not null default now(),
  constraint scribble_waiting_expiry check (status <> 'waiting' or invite_expires_at is not null)
);

create index scribble_rooms_expiry_idx on public.scribble_rooms (invite_expires_at) where status = 'waiting';
create index scribble_rooms_live_idx on public.scribble_rooms (updated_at) where status in ('waiting', 'active');

create table public.scribble_members (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 24),
  seat smallint,
  status text not null default 'active' check (status in ('active', 'waiting', 'left')),
  is_host boolean not null default false,
  score integer not null default 0 check (score >= 0),
  joined_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  left_at timestamptz,
  primary key (room_id, user_id),
  constraint scribble_member_seat_range check (seat is null or seat between 1 and 8)
);

create unique index scribble_member_seat_unique on public.scribble_members (room_id, seat) where seat is not null and status <> 'left';
create index scribble_members_user_active_idx on public.scribble_members (user_id, last_seen_at desc) where status in ('active', 'waiting');

create table public.scribble_word_bank (
  id bigint generated always as identity primary key,
  word text not null unique check (char_length(word) between 3 and 24 and word = lower(btrim(word))),
  category text not null default 'Everyday' check (char_length(category) between 1 and 32),
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.scribble_turns (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_number integer not null check (turn_number > 0),
  cycle_number smallint not null check (cycle_number > 0),
  drawer_id uuid not null references auth.users (id) on delete cascade,
  choices text[] not null check (cardinality(choices) = 3),
  answer text,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  canvas_revision integer not null default 0,
  unique (room_id, turn_number)
);

create index scribble_turns_room_recent_idx on public.scribble_turns (room_id, turn_number desc);

create table public.scribble_drawing_batches (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  canvas_revision integer not null check (canvas_revision >= 0),
  sequence bigint not null check (sequence > 0),
  drawer_id uuid not null references auth.users (id) on delete cascade,
  strokes jsonb not null check (jsonb_typeof(strokes) = 'array'),
  created_at timestamptz not null default now(),
  primary key (turn_id, canvas_revision, sequence)
);

create index scribble_drawing_snapshot_idx on public.scribble_drawing_batches (room_id, turn_id, canvas_revision, sequence);

create table public.scribble_events (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid references public.scribble_turns (id) on delete cascade,
  actor_id uuid references auth.users (id) on delete set null,
  event_type text not null check (event_type in ('guess', 'correct', 'system', 'reveal')),
  body jsonb not null check (jsonb_typeof(body) = 'object'),
  created_at timestamptz not null default now()
);

create index scribble_events_room_feed_idx on public.scribble_events (room_id, id desc);
create index scribble_events_rate_limit_idx on public.scribble_events (room_id, actor_id, created_at desc) where event_type = 'guess';

create table public.scribble_solved (
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  points integer not null check (points between 100 and 200),
  solved_at timestamptz not null default now(),
  primary key (turn_id, user_id)
);

create table public.scribble_score_events (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.scribble_rooms (id) on delete cascade,
  turn_id uuid not null references public.scribble_turns (id) on delete cascade,
  recipient_id uuid not null references auth.users (id) on delete cascade,
  source_user_id uuid not null references auth.users (id) on delete cascade,
  event_type text not null check (event_type in ('correct_guess', 'drawer_bonus')),
  points integer not null check (points between 25 and 200),
  created_at timestamptz not null default now(),
  unique (turn_id, recipient_id, source_user_id, event_type)
);

create index scribble_score_room_idx on public.scribble_score_events (room_id, created_at);

create or replace function public.scribble_is_member(p_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.scribble_members m
    where m.room_id = p_room_id
      and m.user_id = (select auth.uid())
      and m.status in ('active', 'waiting')
  );
$$;

revoke all on function public.scribble_is_member(uuid) from public, anon;
grant execute on function public.scribble_is_member(uuid) to authenticated;

alter table public.player_profiles enable row level security;
alter table public.scribble_rooms enable row level security;
alter table public.scribble_members enable row level security;
alter table public.scribble_word_bank enable row level security;
alter table public.scribble_turns enable row level security;
alter table public.scribble_drawing_batches enable row level security;
alter table public.scribble_events enable row level security;
alter table public.scribble_solved enable row level security;
alter table public.scribble_score_events enable row level security;

revoke all on public.player_profiles, public.scribble_rooms, public.scribble_members, public.scribble_word_bank,
  public.scribble_turns, public.scribble_drawing_batches, public.scribble_events, public.scribble_solved,
  public.scribble_score_events from anon, authenticated;
grant select, insert, update on public.player_profiles to authenticated;
grant select on public.scribble_rooms, public.scribble_members, public.scribble_drawing_batches,
  public.scribble_events, public.scribble_solved, public.scribble_score_events to authenticated;
grant all on public.player_profiles, public.scribble_rooms, public.scribble_members, public.scribble_word_bank,
  public.scribble_turns, public.scribble_drawing_batches, public.scribble_events, public.scribble_solved,
  public.scribble_score_events to service_role;

create policy "Players read own profile" on public.player_profiles for select to authenticated using (user_id = (select auth.uid()));
create policy "Players create own profile" on public.player_profiles for insert to authenticated with check (user_id = (select auth.uid()));
create policy "Players update own profile" on public.player_profiles for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "Room members read room state" on public.scribble_rooms for select to authenticated using (public.scribble_is_member(id));
create policy "Room members read roster" on public.scribble_members for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read drawing batches" on public.scribble_drawing_batches for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read safe events" on public.scribble_events for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read solve results" on public.scribble_solved for select to authenticated using (public.scribble_is_member(room_id));
create policy "Room members read scores" on public.scribble_score_events for select to authenticated using (public.scribble_is_member(room_id));

revoke all on public.scribble_word_bank, public.scribble_turns from anon, authenticated;
revoke all on public.scribble_solved, public.scribble_score_events from anon, authenticated;

insert into public.scribble_word_bank (word, category) values
  ('apple', 'Food'), ('backpack', 'Everyday'), ('balloon', 'Objects'), ('bicycle', 'Transport'),
  ('butterfly', 'Nature'), ('campfire', 'Nature'), ('castle', 'Places'), ('caterpillar', 'Nature'),
  ('cheesecake', 'Food'), ('clock', 'Objects'), ('cloud', 'Nature'), ('coconut', 'Food'),
  ('dolphin', 'Animals'), ('drum', 'Music'), ('elephant', 'Animals'), ('envelope', 'Objects'),
  ('fireworks', 'Events'), ('football', 'Sports'), ('giraffe', 'Animals'), ('guitar', 'Music'),
  ('hamburger', 'Food'), ('helicopter', 'Transport'), ('ice cream', 'Food'), ('igloo', 'Places'),
  ('jellyfish', 'Animals'), ('kite', 'Objects'), ('lantern', 'Objects'), ('lighthouse', 'Places'),
  ('mountain', 'Nature'), ('mushroom', 'Nature'), ('octopus', 'Animals'), ('paintbrush', 'Objects'),
  ('parachute', 'Objects'), ('penguin', 'Animals'), ('piano', 'Music'), ('pineapple', 'Food'),
  ('rainbow', 'Nature'), ('robot', 'Objects'), ('sandcastle', 'Places'), ('saxophone', 'Music'),
  ('snowman', 'Nature'), ('spaceship', 'Transport'), ('spider', 'Animals'), ('sunflower', 'Nature'),
  ('teapot', 'Objects'), ('telescope', 'Objects'), ('turtle', 'Animals'), ('volcano', 'Nature'),
  ('waterfall', 'Nature'), ('windmill', 'Places'), ('wizard', 'People')
on conflict (word) do nothing;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_rooms'
  ) then alter publication supabase_realtime add table public.scribble_rooms; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_members'
  ) then alter publication supabase_realtime add table public.scribble_members; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_drawing_batches'
  ) then alter publication supabase_realtime add table public.scribble_drawing_batches; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scribble_events'
  ) then alter publication supabase_realtime add table public.scribble_events; end if;
end $$;
