create table if not exists public.chess_rooms (
  id uuid primary key default gen_random_uuid(),
  invite_code text not null unique,
  host_id uuid not null references auth.users (id) on delete cascade,
  guest_id uuid references auth.users (id) on delete set null,
  moves text[] not null default array[]::text[],
  ply integer not null default 0 check (ply = cardinality(moves)),
  status text not null default 'waiting' check (status in ('waiting', 'active', 'finished')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours'),
  constraint chess_rooms_two_distinct_players check (guest_id is null or guest_id <> host_id)
);

create index if not exists chess_rooms_expires_at_idx on public.chess_rooms (expires_at);

alter table public.chess_rooms enable row level security;
revoke all on public.chess_rooms from anon, authenticated;
grant select on public.chess_rooms to authenticated;
grant all on public.chess_rooms to service_role;

drop policy if exists "Players can read their own chess room" on public.chess_rooms;
create policy "Players can read their own chess room"
  on public.chess_rooms for select to authenticated
  using (auth.uid() = host_id or auth.uid() = guest_id);

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id and ply = p_expected_ply
  returning * into updated_room;

  if not found then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  return to_jsonb(updated_room);
end;
$$;

revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean) to service_role;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'chess_rooms'
  ) then
    alter publication supabase_realtime add table public.chess_rooms;
  end if;
end $$;
