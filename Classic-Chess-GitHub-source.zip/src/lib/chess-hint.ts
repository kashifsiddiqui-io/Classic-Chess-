import type { SupabaseClient } from '@supabase/supabase-js';

export type ChessMoveHint = {
  san: string;
  from: string;
  to: string;
  piece: string;
  reasons: string[];
};

function parseChessMoveHint(value: unknown): ChessMoveHint {
  if (!value || typeof value !== 'object') throw new Error('The coach returned an invalid move hint. Try again.');
  const move = value as Record<string, unknown>;
  if (typeof move.san !== 'string' || typeof move.from !== 'string' || typeof move.to !== 'string'
    || typeof move.piece !== 'string' || !Array.isArray(move.reasons)
    || !move.reasons.every((reason) => typeof reason === 'string')) {
    throw new Error('The coach returned an invalid move hint. Try again.');
  }
  return {
    san: move.san,
    from: move.from,
    to: move.to,
    piece: move.piece,
    reasons: move.reasons as string[],
  };
}

export async function getChessMoveHint(supabase: SupabaseClient, fen: string): Promise<ChessMoveHint> {
  const { data, error } = await supabase.functions.invoke('chess-hint', { body: { fen } });
  if (error) {
    const context = error.context;
    if (context instanceof Response) {
      try {
        const payload = await context.clone().json() as { error?: unknown };
        if (typeof payload.error === 'string') throw new Error(payload.error);
      } catch (cause) {
        if (cause instanceof Error && cause.message !== 'Unexpected end of JSON input') throw cause;
      }
    }
    throw new Error(error.message || 'The chess coach could not answer. Try again.');
  }
  return parseChessMoveHint(data);
}
