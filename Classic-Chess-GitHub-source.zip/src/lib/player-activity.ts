import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@classic-chess/player-activity-v3';
const LEGACY_STORAGE_KEYS = ['@classic-chess/player-activity-v2', '@classic-chess/player-activity-v1'];
const IST = 'Asia/Kolkata';
const DAY_MS = 24 * 60 * 60 * 1000;

type PlayerActivity = {
  name: string;
  completedByDay: Record<string, true>;
};

export type StreakDay = { key: string; label: string; completed: boolean; isToday: boolean };
export type ActivitySummary = { streakDays: number; completedToday: boolean; lastSevenDays: StreakDay[] };

const emptyActivity = (): PlayerActivity => ({ name: '', completedByDay: {} });
const formatter = new Intl.DateTimeFormat('en-GB', {
  timeZone: IST,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});
const weekdayFormatter = new Intl.DateTimeFormat('en-US', { timeZone: IST, weekday: 'short' });

function istParts(date: Date) {
  const parts = Object.fromEntries(formatter.formatToParts(date).map(({ type, value }) => [type, value]));
  return { year: Number(parts.year), month: Number(parts.month), day: Number(parts.day), hour: Number(parts.hour), minute: Number(parts.minute) };
}

function dateKey(date: Date) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
}

function shiftedDateKey(key: string, offsetDays: number) {
  const [year, month, day] = key.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + offsetDays));
  return dateKey(date);
}

export function getTrackingDayKey(at = new Date()) {
  const { year, month, day, hour } = istParts(at);
  const trackingDate = new Date(Date.UTC(year, month - 1, day - (hour < 6 ? 1 : 0)));
  return dateKey(trackingDate);
}

export function getNextDailyReset(at = new Date()) {
  const { year, month, day } = istParts(at);
  // 06:00 IST is 00:30 UTC. India has no daylight-saving transition.
  let reset = Date.UTC(year, month - 1, day, 0, 30);
  if (reset <= at.getTime()) reset += DAY_MS;
  return reset;
}

function activityKey(userId?: string) {
  return userId ? `${STORAGE_KEY}:${userId}` : STORAGE_KEY;
}

async function readActivity(userId?: string): Promise<PlayerActivity> {
  const key = activityKey(userId);
  const raw = await AsyncStorage.getItem(key);
  if (raw) {
    try {
      const value: unknown = JSON.parse(raw);
      if (!value || typeof value !== 'object') return emptyActivity();
      const record = value as Partial<PlayerActivity>;
      const completedByDay = record.completedByDay && typeof record.completedByDay === 'object'
        ? Object.fromEntries(Object.entries(record.completedByDay).filter(([day, completed]) => /^\d{4}-\d{2}-\d{2}$/.test(day) && completed === true)) as Record<string, true>
        : {};
      return { name: typeof record.name === 'string' ? record.name.trim().slice(0, 24) : '', completedByDay };
    } catch {
      return emptyActivity();
    }
  }

  // Move the prior device-only profile into the first account without carrying it into later accounts.
  const legacyKeys = userId ? [STORAGE_KEY, ...LEGACY_STORAGE_KEYS] : LEGACY_STORAGE_KEYS;
  for (const legacyKey of legacyKeys) {
    const legacy = await AsyncStorage.getItem(legacyKey);
    if (!legacy) continue;
    try {
      const prior: unknown = JSON.parse(legacy);
      const name = prior && typeof prior === 'object' && 'name' in prior && typeof prior.name === 'string' ? prior.name.trim().slice(0, 24) : '';
      const oldCompletions = legacyKey === STORAGE_KEY && prior && typeof prior === 'object' && 'completedByDay' in prior
        && prior.completedByDay && typeof prior.completedByDay === 'object'
        ? Object.fromEntries(Object.entries(prior.completedByDay).filter(([day, completed]) => /^\d{4}-\d{2}-\d{2}$/.test(day) && completed === true)) as Record<string, true>
        : {};
      const migrated = { name, completedByDay: oldCompletions };
      if (userId) {
        await AsyncStorage.setItem(key, JSON.stringify(migrated));
        await AsyncStorage.removeItem(legacyKey);
      }
      return migrated;
    } catch {
      return emptyActivity();
    }
  }
  return emptyActivity();
}

export async function loadPlayerActivity(userId?: string) {
  const activity = await readActivity(userId);
  return { name: activity.name, summary: summarize(activity.completedByDay) };
}

export async function savePlayerName(name: string, userId?: string) {
  const activity = await readActivity(userId);
  activity.name = name.trim().slice(0, 24);
  await AsyncStorage.setItem(activityKey(userId), JSON.stringify(activity));
  return activity.name;
}

export async function recordCompletedGame(at = new Date(), userId?: string) {
  const activity = await readActivity(userId);
  const today = getTrackingDayKey(at);
  activity.completedByDay[today] = true;
  await AsyncStorage.setItem(activityKey(userId), JSON.stringify(activity));
  return summarize(activity.completedByDay, at);
}

function summarize(completedByDay: Record<string, true>, at = new Date()): ActivitySummary {
  const today = getTrackingDayKey(at);
  const previous = shiftedDateKey(today, -1);
  let cursor = completedByDay[today] ? today : completedByDay[previous] ? previous : '';
  let streakDays = 0;
  while (cursor && completedByDay[cursor]) {
    streakDays += 1;
    cursor = shiftedDateKey(cursor, -1);
  }

  const lastSevenDays = Array.from({ length: 7 }, (_, index) => {
    const key = shiftedDateKey(today, index - 6);
    const [year, month, day] = key.split('-').map(Number);
    const weekday = weekdayFormatter.format(new Date(Date.UTC(year, month - 1, day, 12)));
    return { key, label: weekday.slice(0, 1), completed: Boolean(completedByDay[key]), isToday: key === today };
  });
  return { streakDays, completedToday: Boolean(completedByDay[today]), lastSevenDays };
}
