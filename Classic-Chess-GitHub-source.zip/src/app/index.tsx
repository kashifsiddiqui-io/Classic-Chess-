import { router } from 'expo-router';
import { ImageBackground, Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import Animated, { FadeIn, FadeInDown, FadeInUp, useReducedMotion } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import { palette } from '@/constants/app-theme';
import { useAuth } from '@/context/auth';
import { getSupabase } from '@/lib/supabase';

const hero = require('@/assets/images/chess-home.png');

export default function HomeScreen() {
  const { user } = useAuth();
  const reducedMotion = useReducedMotion();

  async function logOut() {
    const supabase = getSupabase();
    if (!supabase) return;
    await supabase.auth.signOut({ scope: 'local' });
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ImageBackground source={hero} resizeMode="cover" style={styles.hero}>
        <View style={styles.scrim} />
        <Animated.View entering={reducedMotion ? undefined : FadeIn.duration(420).delay(100)} style={styles.topline}>
          <View>
            <Text style={styles.credit}>FROM MYSTORE</Text>
            {!!user?.email && <Text style={styles.accountEmail}>{user.email}</Text>}
          </View>
          <Pressable onPress={() => void logOut()} style={({ pressed }) => [styles.logoutButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Log out of your chess account">
            <Svg width={18} height={18} viewBox="0 0 24 24" accessibilityLabel="Log out">
              <Path d="M13 4h5a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5M10 16l4-4-4-4m4 4H3" fill="none" stroke="#f5f4ed" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          </Pressable>
        </Animated.View>
        <View style={styles.footerPattern}>
          <View style={styles.content}>
            <Animated.Text entering={reducedMotion ? undefined : FadeIn.duration(560).delay(120)} style={styles.eyebrow}>A CLASSIC, REIMAGINED</Animated.Text>
            <Animated.Text entering={reducedMotion ? undefined : FadeInUp.duration(620).delay(230)} style={styles.title}>CLASSIC<Text style={styles.titleAccent}> CHESS</Text></Animated.Text>
            <Animated.Text entering={reducedMotion ? undefined : FadeInUp.duration(620).delay(370)} style={styles.subtitle}>One board. Endless possibilities.</Animated.Text>
          </View>
          <Animated.View entering={reducedMotion ? undefined : FadeInDown.duration(560).delay(500)} style={styles.actions}>
            <Pressable onPress={() => router.push('/play')} style={({ pressed }) => [styles.playButton, pressed && styles.pressed]} accessibilityRole="button">
              <Text style={styles.playLabel}>PLAY</Text><Text style={styles.playIcon}>▶</Text>
            </Pressable>
            <Animated.View entering={reducedMotion ? undefined : FadeInDown.duration(520).delay(620)} style={styles.quickModes}>
              <Pressable onPress={() => router.push({ pathname: '/setup', params: { mode: 'local' } })} style={({ pressed }) => [styles.quickButton, pressed && styles.pressed]}><Text style={styles.quickText}>1 VS 1</Text></Pressable>
              <Pressable onPress={() => router.push({ pathname: '/setup', params: { mode: 'computer' } })} style={({ pressed }) => [styles.quickButton, pressed && styles.pressed]}><Text style={styles.quickText}>VS COMPUTER</Text></Pressable>
            </Animated.View>
          </Animated.View>
          <Animated.Text entering={reducedMotion ? undefined : FadeIn.duration(560).delay(760)} style={styles.footer}>THINK CLEAR. MOVE WITH INTENT.</Animated.Text>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: palette.background },
  hero: { flex: 1, justifyContent: 'space-between', paddingHorizontal: 24, paddingTop: 14, paddingBottom: 8 },
  scrim: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(3, 9, 7, .48)' },
  topline: { height: 36, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  credit: { color: palette.white, fontSize: 11, letterSpacing: 4, fontWeight: '700' },
  accountEmail: { color: '#d5ded7', fontSize: 9, marginTop: 4 },
  logoutButton: { width: 37, height: 37, borderRadius: 19, borderWidth: 1, borderColor: 'rgba(245,244,237,.5)', backgroundColor: 'rgba(10,16,13,.36)', alignItems: 'center', justifyContent: 'center' },
  content: { alignItems: 'center', marginBottom: 5 },
  eyebrow: { color: '#d2dfd5', fontSize: 10, fontWeight: '700', letterSpacing: 3, marginBottom: 12 },
  title: { color: palette.white, fontSize: 32, lineHeight: 38, fontWeight: '900', letterSpacing: 0.6, textAlign: 'center' },
  titleAccent: { color: palette.cream },
  subtitle: { color: '#e0e6e0', fontSize: 15, marginTop: 8, textAlign: 'center' },
  playButton: { height: 62, borderRadius: 16, backgroundColor: palette.white, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 14 },
  playLabel: { color: '#111512', fontSize: 15, fontWeight: '800', letterSpacing: 3 },
  playIcon: { color: '#111512', fontSize: 16 },
  actions: { gap: 10 },
  footerPattern: { position: 'absolute', left: 24, right: 24, top: '50%', transform: [{ translateY: -112 }], gap: 8 },
  quickModes: { flexDirection: 'row', gap: 10 },
  quickButton: { flex: 1, height: 43, borderRadius: 13, borderWidth: 1, borderColor: 'rgba(255,255,255,.72)', backgroundColor: 'rgba(8,12,11,.48)', alignItems: 'center', justifyContent: 'center' },
  quickText: { color: palette.white, fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
  footer: { width: '100%', color: '#dce5de', fontSize: 9, letterSpacing: 2.5, textAlign: 'center' },
});
