-- Run against a database with at least one auth user. Every fixture is rolled back.
do $$
declare
  player_id uuid;
  guest_id uuid;
  match_id uuid;
  room_id uuid;
  outcome jsonb;
  current_silver integer;
  current_gold integer;
begin
  select user_id into player_id from public.trophy_wallets order by user_id limit 1;
  if player_id is null then raise exception 'Trophy smoke test requires a signed-in user.'; end if;
  select id into guest_id from auth.users where id <> player_id order by id limit 1;

  begin
    update public.trophy_wallets set silver = 0, gold = 0 where user_id = player_id;
    perform set_config('request.jwt.claim.sub', player_id::text, true);

    match_id := public.start_trophy_ai_match('w');
    outcome := public.settle_trophy_ai_match(match_id, 'win');
    if outcome ->> 'silver' <> '200' or outcome ->> 'awardedSilver' <> '200' then
      raise exception 'AI win did not award 200 silver trophies.';
    end if;

    match_id := public.start_trophy_ai_match('b');
    outcome := public.settle_trophy_ai_match(match_id, 'loss');
    if outcome ->> 'silver' <> '180' or outcome ->> 'awardedSilver' <> '-20' then
      raise exception 'AI loss at 200 silver did not deduct exactly 20.';
    end if;

    match_id := public.start_trophy_ai_match('w');
    outcome := public.settle_trophy_ai_match(match_id, 'loss');
    if outcome ->> 'silver' <> '180' or outcome ->> 'awardedSilver' <> '0' then
      raise exception 'AI loss below 200 silver was not free.';
    end if;

    update public.trophy_wallets set silver = 200, gold = 0 where user_id = player_id;
    select silver, gold into current_silver, current_gold from public.convert_silver_trophies(100);
    if current_silver <> 100 or current_gold <> 50 then
      raise exception 'Silver to gold conversion was not 100 to 50.';
    end if;

    if guest_id is not null then
      update public.trophy_wallets set silver = 0, gold = 0 where user_id = guest_id;
      insert into public.chess_rooms (invite_code, host_id, guest_id, status, expires_at)
        values (upper(substr(md5(gen_random_uuid()::text), 1, 8)), player_id, guest_id, 'active', null)
        returning id into room_id;
      update public.chess_rooms set status = 'finished', winner_id = player_id where id = room_id;
      select silver, gold into current_silver, current_gold from public.trophy_wallets where user_id = player_id;
      if current_gold <> 550 then raise exception 'Multiplayer winner did not receive 500 gold trophies.'; end if;
      if exists (select 1 from public.trophy_wallets where user_id = guest_id and (silver <> 0 or gold <> 0)) then
        raise exception 'Multiplayer loss changed the other player’s trophy balance.';
      end if;
    end if;

    raise exception using errcode = 'ZX001', message = 'ROLLBACK_TROPHY_SMOKE_TEST';
  exception when sqlstate 'ZX001' then
    raise notice 'Trophy wallet smoke test passed; fixtures rolled back.';
  end;
end;
$$;
