import { router, useFocusEffect } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { TrophyIcon } from '@/components/trophy-icon';
import { useAuth } from '@/context/auth';
import { convertSilverTrophies, emptyTrophyWallet, loadTrophyWallet, type TrophyWallet } from '@/lib/trophies';
import { getSupabase } from '@/lib/supabase';

const green = '#4e7c6e';
const ink = '#1f2c26';

export default function TrophyScreen() {
  const { user } = useAuth();
  const [wallet, setWallet] = useState<TrophyWallet>(emptyTrophyWallet);
  const [loading, setLoading] = useState(true);
  const [converting, setConverting] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useFocusEffect(useCallback(() => {
    let active = true;
    const supabase = getSupabase();
    if (!supabase || !user?.id) {
      setError('Sign in to view your trophy wallet.');
      setLoading(false);
      return () => { active = false; };
    }
    setLoading(true);
    void loadTrophyWallet(supabase, user.id).then((next) => {
      if (active) { setWallet(next); setError(''); }
    }).catch((cause: unknown) => {
      if (active) setError(cause instanceof Error ? cause.message : 'Could not load trophies.');
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [user]));

  async function convert() {
    const supabase = getSupabase();
    if (!supabase || converting || wallet.silver < 100) return;
    setConverting(true);
    setError('');
    setNotice('');
    try {
      const next = await convertSilverTrophies(supabase, 100);
      setWallet(next);
      setNotice('Converted 100 silver trophies into 50 gold trophies.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not convert trophies.');
    } finally {
      setConverting(false);
    }
  }

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <StatusBar style="dark" animated />
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Pressable onPress={() => router.back()} style={styles.back} accessibilityRole="button"><Text style={styles.backText}>‹  Back</Text></Pressable>
      <View style={styles.headingBlock}>
        <View style={styles.eyebrowPill}><Text style={styles.eyebrow}>YOUR REWARDS</Text></View>
        <Text style={styles.title}>Trophy wallet</Text>
        <Text style={styles.subtitle}>Every match is a chance to earn.</Text>
      </View>

      <View style={styles.walletRow}>
        <View style={[styles.walletCard, styles.silverCard]}>
          <View style={styles.walletCardTop}>
            <View><Text style={styles.walletOverline}>VS COMPUTER</Text><View style={styles.walletLabelPill}><View style={[styles.walletLabelDot, styles.silverLabelDot]} /><Text style={styles.walletLabel}>SILVER</Text></View></View>
            <TrophyIcon metal="silver" label="Silver trophy" idPrefix="wallet-silver" />
          </View>
          <Text style={styles.walletValue}>{wallet.silver}</Text>
          <Text style={styles.walletCaption}>Silver trophies</Text>
        </View>
        <View style={[styles.walletCard, styles.goldCard]}>
          <View style={styles.walletCardTop}>
            <View><Text style={styles.walletOverline}>VS A FRIEND</Text><View style={styles.walletLabelPill}><View style={[styles.walletLabelDot, styles.goldLabelDot]} /><Text style={styles.walletLabel}>GOLD</Text></View></View>
            <TrophyIcon metal="gold" label="Gold trophy" idPrefix="wallet-gold" />
          </View>
          <Text style={styles.walletValue}>{wallet.gold}</Text>
          <Text style={styles.walletCaption}>Gold trophies</Text>
        </View>
      </View>

      <View style={styles.convertCard}>
        <View style={styles.convertHeading}>
          <View style={styles.convertIcon}><Text style={styles.convertIconText}>⇄</Text></View>
          <View style={styles.convertHeadingCopy}><Text style={styles.cardTitle}>Convert trophies</Text><Text style={styles.cardCopy}>Move rewards between your wallets.</Text></View>
        </View>
        <Pressable onPress={() => void convert()} disabled={converting || wallet.silver < 100} style={({ pressed }) => [styles.convertButton, (converting || wallet.silver < 100) && styles.disabled, pressed && styles.pressed]} accessibilityRole="button">
          {converting ? <ActivityIndicator color="#fff" /> : <><Text style={styles.convertButtonText}>100 SILVER</Text><Text style={styles.convertArrow}>→</Text><Text style={styles.convertButtonText}>50 GOLD</Text></>}
        </Pressable>
        {wallet.silver < 100 && <Text style={styles.requirement}>You need {100 - wallet.silver} more silver to make a conversion.</Text>}
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionHeading}>How trophies work</Text>
        <View style={styles.sectionHintPill}><Text style={styles.sectionHint}>MATCH REWARDS</Text></View>
      </View>
      <View style={[styles.ruleCard, styles.computerRule]}>
        <View style={[styles.ruleMark, styles.silverMark]}><Text style={styles.ruleMarkText}>S</Text></View>
        <View style={styles.ruleBody}>
          <Text style={styles.ruleTitle}>You vs Computer</Text>
          <Text style={styles.ruleCopy}>Win <Text style={styles.rewardSilver}>+200 silver</Text> plus the <Text style={styles.rewardSilver}>+50 silver gift</Text>. Losses are free below 200; after that, a loss costs 20. Draws do not change your balance.</Text>
        </View>
      </View>
      <View style={[styles.ruleCard, styles.multiplayerRule]}>
        <View style={[styles.ruleMark, styles.goldMark]}><Text style={[styles.ruleMarkText, styles.goldMarkText]}>G</Text></View>
        <View style={styles.ruleBody}>
          <Text style={styles.ruleTitle}>Multiplayer chess</Text>
          <Text style={styles.ruleCopy}>The winner earns <Text style={styles.rewardGold}>500 gold</Text>. The other player’s balance stays the same.</Text>
        </View>
      </View>

      {loading && <View style={styles.loading}><ActivityIndicator color={green} /><Text style={styles.loadingText}>Loading your trophies…</Text></View>}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {notice ? <Text style={styles.notice}>{notice}</Text> : null}
      <Pressable onPress={() => router.push('/leaderboard')} style={styles.leaderboardLink} accessibilityRole="button"><Text style={styles.leaderboardLinkText}>VIEW LEADERBOARD  ↗</Text></Pressable>
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f4f5f1' },
  content: { width: '100%', maxWidth: 620, alignSelf: 'center', paddingHorizontal: 20, paddingTop: 12, paddingBottom: 36 },
  back: { alignSelf: 'flex-start', paddingVertical: 9, paddingHorizontal: 15, marginBottom: 21, borderRadius: 20, backgroundColor: '#202923' },
  backText: { color: '#fff', fontSize: 12, fontWeight: '800' },
  headingBlock: { marginBottom: 21 },
  eyebrowPill: { alignItems: 'center', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: '#202923' },
  eyebrow: { color: '#fff', fontSize: 9, fontWeight: '900', letterSpacing: 1.8 },
  title: { color: ink, fontSize: 32, fontWeight: '900', letterSpacing: -1, marginTop: 10 },
  subtitle: { color: '#758078', fontSize: 13, marginTop: 4 },
  walletRow: { flexDirection: 'row', gap: 12 },
  walletCard: { flex: 1, minHeight: 174, padding: 16, borderRadius: 24, borderWidth: 1, overflow: 'hidden', shadowColor: '#24372f', shadowOpacity: 0.06, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, elevation: 2 },
  silverCard: { backgroundColor: '#fff', borderColor: '#d7e0e4' },
  goldCard: { backgroundColor: '#fffdf7', borderColor: '#eadfbe' },
  walletCardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  walletOverline: { color: '#89958f', fontSize: 8, fontWeight: '900', letterSpacing: 1.1, marginBottom: 4 },
  walletLabelPill: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 6 },
  walletLabelDot: { width: 6, height: 6, borderRadius: 3 },
  silverLabelDot: { backgroundColor: '#c5d0d5' },
  goldLabelDot: { backgroundColor: '#e5bd61' },
  walletLabel: { color: '#59675f', fontSize: 9, fontWeight: '900', letterSpacing: 1.5 },
  walletValue: { color: ink, fontSize: 36, fontWeight: '900', letterSpacing: -1.2, marginTop: 9 },
  walletCaption: { color: '#7d8980', fontSize: 11, marginTop: 1 },
  convertCard: { padding: 17, marginTop: 15, borderRadius: 23, borderWidth: 1, borderColor: '#dce6dd', backgroundColor: '#fff', shadowColor: '#24372f', shadowOpacity: 0.04, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 1 },
  convertHeading: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  convertIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e9f1ec' },
  convertIconText: { color: green, fontSize: 24, fontWeight: '800', lineHeight: 27 },
  convertHeadingCopy: { flex: 1 },
  cardTitle: { color: ink, fontSize: 16, fontWeight: '800' },
  cardCopy: { color: '#77837a', fontSize: 11, lineHeight: 16, marginTop: 3 },
  convertButton: { minHeight: 47, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 11, marginTop: 15, paddingHorizontal: 12, borderRadius: 15, backgroundColor: green },
  disabled: { backgroundColor: '#b7c9c1' },
  pressed: { transform: [{ scale: 0.99 }], opacity: 0.88 },
  convertButtonText: { color: '#fff', fontSize: 10, fontWeight: '900', letterSpacing: 0.8 },
  convertArrow: { color: '#d7e8df', fontSize: 16, fontWeight: '800' },
  requirement: { color: '#8a948d', fontSize: 10, marginTop: 9, textAlign: 'center' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 26, marginBottom: 11 },
  sectionHeading: { color: ink, fontSize: 18, fontWeight: '900', letterSpacing: -0.3 },
  sectionHintPill: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 12, backgroundColor: '#202923' },
  sectionHint: { color: '#fff', fontSize: 7, fontWeight: '900', letterSpacing: 1.1 },
  ruleCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, padding: 15, marginBottom: 10, borderRadius: 20, borderWidth: 1 },
  computerRule: { borderColor: '#dce5e8', backgroundColor: '#fff' },
  multiplayerRule: { borderColor: '#e9dfc5', backgroundColor: '#fffdf8' },
  ruleMark: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  silverMark: { backgroundColor: '#edf2f4' },
  goldMark: { backgroundColor: '#f8efd8' },
  ruleMarkText: { color: '#71808a', fontSize: 14, fontWeight: '900' },
  goldMarkText: { color: '#a98232' },
  ruleBody: { flex: 1 },
  ruleTitle: { color: ink, fontSize: 13, fontWeight: '900' },
  ruleCopy: { color: '#748078', fontSize: 11, lineHeight: 17, marginTop: 5 },
  rewardSilver: { color: '#647a86', fontWeight: '900' },
  rewardGold: { color: '#a98232', fontWeight: '900' },
  loading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 15 },
  loadingText: { color: '#748078', fontSize: 11 },
  error: { color: '#a33b32', fontSize: 11, marginTop: 12 },
  notice: { color: green, fontSize: 11, fontWeight: '700', marginTop: 12 },
  leaderboardLink: { minHeight: 52, alignItems: 'center', justifyContent: 'center', marginTop: 13, borderRadius: 16, backgroundColor: '#202923' },
  leaderboardLinkText: { color: '#fff', fontSize: 12, fontWeight: '900', letterSpacing: 1.2 },
});
