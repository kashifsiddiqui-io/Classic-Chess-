create table if not exists public.chess_chat_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.chess_rooms(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  kind text not null,
  content text not null,
  created_at timestamptz not null default now(),
  constraint chess_chat_messages_kind_check
    check (kind in ('text', 'emoji', 'sticker')),
  constraint chess_chat_messages_payload_check
    check (
      (kind = 'text' and char_length(btrim(content)) between 1 and 500)
      or (kind = 'emoji' and content in ('😂', '😍', '👏', '🔥', '😮', '👍'))
      or (kind = 'sticker' and content in ('gg', 'nice', 'fire', 'wow', 'heart', 'oops'))
    ),
  constraint chess_chat_messages_id_room_unique unique (id, room_id)
);

create index if not exists chess_chat_messages_room_created_idx
  on public.chess_chat_messages (room_id, created_at desc);

alter table public.chess_chat_messages enable row level security;
revoke all on public.chess_chat_messages from anon, authenticated;
grant select, insert on public.chess_chat_messages to authenticated;
grant all on public.chess_chat_messages to service_role;

drop policy if exists "Room players can read chess chat" on public.chess_chat_messages;
create policy "Room players can read chess chat"
  on public.chess_chat_messages for select to authenticated
  using (
    exists (
      select 1 from public.chess_rooms as room
      where room.id = chess_chat_messages.room_id
        and (room.host_id = auth.uid() or room.guest_id = auth.uid())
        and room.status in ('waiting', 'active')
        and (room.expires_at is null or room.expires_at > now())
    )
  );

drop policy if exists "Room players can send chess chat" on public.chess_chat_messages;
create policy "Room players can send chess chat"
  on public.chess_chat_messages for insert to authenticated
  with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.chess_rooms as room
      where room.id = chess_chat_messages.room_id
        and (room.host_id = auth.uid() or room.guest_id = auth.uid())
        and room.status in ('waiting', 'active')
        and (room.expires_at is null or room.expires_at > now())
    )
  );

create table if not exists public.chess_chat_reactions (
  room_id uuid not null references public.chess_rooms(id) on delete cascade,
  message_id uuid not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  emoji text not null check (emoji in ('😂', '😍', '👏', '🔥', '😮', '👍')),
  created_at timestamptz not null default now(),
  primary key (message_id, user_id, emoji),
  constraint chess_chat_reactions_message_room_fk
    foreign key (message_id, room_id)
    references public.chess_chat_messages(id, room_id) on delete cascade
);

create index if not exists chess_chat_reactions_room_idx
  on public.chess_chat_reactions (room_id);

alter table public.chess_chat_reactions enable row level security;
revoke all on public.chess_chat_reactions from anon, authenticated;
grant select, insert, delete on public.chess_chat_reactions to authenticated;
grant all on public.chess_chat_reactions to service_role;

drop policy if exists "Room players can read chess chat reactions" on public.chess_chat_reactions;
create policy "Room players can read chess chat reactions"
  on public.chess_chat_reactions for select to authenticated
  using (
    exists (
      select 1 from public.chess_rooms as room
      where room.id = chess_chat_reactions.room_id
        and (room.host_id = auth.uid() or room.guest_id = auth.uid())
        and room.status in ('waiting', 'active')
        and (room.expires_at is null or room.expires_at > now())
    )
  );

drop policy if exists "Room players can add own chess chat reactions" on public.chess_chat_reactions;
create policy "Room players can add own chess chat reactions"
  on public.chess_chat_reactions for insert to authenticated
  with check (
    user_id = auth.uid()
    and exists (
      select 1 from public.chess_rooms as room
      where room.id = chess_chat_reactions.room_id
        and (room.host_id = auth.uid() or room.guest_id = auth.uid())
        and room.status in ('waiting', 'active')
        and (room.expires_at is null or room.expires_at > now())
    )
  );

drop policy if exists "Players can remove own chess chat reactions" on public.chess_chat_reactions;
create policy "Players can remove own chess chat reactions"
  on public.chess_chat_reactions for delete to authenticated
  using (
    user_id = auth.uid()
    and exists (
      select 1 from public.chess_rooms as room
      where room.id = chess_chat_reactions.room_id
        and (room.host_id = auth.uid() or room.guest_id = auth.uid())
        and room.status in ('waiting', 'active')
        and (room.expires_at is null or room.expires_at > now())
    )
  );

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'chess_chat_messages'
  ) then
    alter publication supabase_realtime add table public.chess_chat_messages;
  end if;

  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'chess_chat_reactions'
  ) then
    alter publication supabase_realtime add table public.chess_chat_reactions;
  end if;
end;
$$;

notify pgrst, 'reload schema';
