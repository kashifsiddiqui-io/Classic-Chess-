package com.mystore.classicchess;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
