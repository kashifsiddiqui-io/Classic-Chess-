import { router, useLocalSearchParams } from 'expo-router';
import { GlassView } from 'expo-glass-effect';
import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BOARD_COLORS, FINISHES, LEVELS, type BoardDesign, type GameMode, type PieceTone, type PlayerColor } from '@/constants/chess';
import { ChessPiece } from '@/components/chess-piece';
import { ColorWheel } from '@/components/color-wheel';
import { RevealCard } from '@/components/reveal-card';
import { useGame, type GameSettings } from '@/context/game';

function BoardPreview({ design }: { design: BoardDesign }) {
  const colors = BOARD_COLORS[design];
  return <View style={styles.preview}>
    {Array.from({ length: 16 }, (_, index) => <View key={index} style={{ width: '25%', height: '25%', backgroundColor: (Math.floor(index / 4) + index % 4) % 2 ? colors.dark : colors.light }} />)}
  </View>;
}

function ColorEditor({ side, value, onChange }: { side: PlayerColor; value: PieceTone; onChange: (tone: PieceTone) => void }) {
  const [wheelOpen, setWheelOpen] = useState(false);
  const finishes = FINISHES[side];
  const title = side === 'w' ? 'White pieces' : 'Black pieces';
  return (
    <View style={styles.colorGroup}>
      <Text style={styles.sectionLabel}>{title}</Text>
      <View style={styles.finishRow}>
        {finishes.map((finish) => (
          <Pressable key={finish.id} onPress={() => onChange(finish.id)} style={({ pressed }) => [styles.finishOption, value === finish.id && styles.finishSelected, pressed && styles.optionPressed]} accessibilityRole="button" accessibilityState={{ selected: value === finish.id }}>
            <View style={[styles.finishDot, { backgroundColor: finish.color }]} />
            <Text style={[styles.finishName, value === finish.id && styles.selectedOptionText]}>{finish.title}</Text>
          </Pressable>
        ))}
        <Pressable onPress={() => setWheelOpen((open) => !open)} style={({ pressed }) => [styles.finishOption, typeof value === 'string' && value.startsWith('#') && styles.finishSelected, pressed && styles.optionPressed]} accessibilityRole="button" accessibilityLabel="Choose a custom piece color">
          <View style={[styles.finishDot, styles.customDot, { backgroundColor: typeof value === 'string' && value.startsWith('#') ? value : '#b2b2b2' }]} />
          <Text style={styles.finishName}>Custom</Text>
        </Pressable>
      </View>
      {wheelOpen && <View style={styles.wheelPanel}>
        <Text style={styles.wheelLabel}>Drag around the wheel to choose a color</Text>
        <ColorWheel value={typeof value === 'string' && value.startsWith('#') ? value : finishes[0].color} onChange={(hex) => onChange(hex as PieceTone)} />
      </View>}
    </View>
  );
}

export default function SetupScreen() {
  const params = useLocalSearchParams<{ mode?: string }>();
  const mode: GameMode = params.mode === 'computer' ? 'computer' : 'local';
  const { settings, setSettings, setMoves } = useGame();
  const [draft, setDraft] = useState<GameSettings>({ ...settings, mode });
  const [colorsOpen, setColorsOpen] = useState(false);

  function update<K extends keyof typeof draft>(key: K, value: (typeof draft)[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  function start() {
    setSettings(draft);
    setMoves([]);
    router.push('/game');
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.topBar}>
          <Pressable onPress={() => { if (router.canGoBack()) router.back(); else router.replace('/play'); }} hitSlop={12} style={styles.back}><Text style={styles.backText}>← Back</Text></Pressable>
          <Text style={styles.step}>MATCH SETUP</Text>
        </View>
        <Text style={styles.heading}>Make it yours</Text>
        <Text style={styles.intro}>Choose your side, colors, and board.</Text>

        <Text style={styles.sectionTitle}>{mode === 'computer' ? 'Your color' : 'Player 1 color'}</Text>
        <View style={styles.colorsRow}>
          {(['w', 'b'] as const).map((color) => (
            <RevealCard key={color} delay={color === 'w' ? 10 : 55} style={styles.choiceCard}>
              <Pressable onPress={() => update('playerColor', color)} style={({ pressed }) => [styles.colorChoice, draft.playerColor === color && styles.selectedColorChoice, pressed && styles.optionPressed]} accessibilityRole="button" accessibilityState={{ selected: draft.playerColor === color }}>
                <GlassView
                  pointerEvents="none"
                  glassEffectStyle="regular"
                  tintColor={draft.playerColor === color ? '#e6f0e9' : '#ffffff'}
                  isInteractive
                  style={[StyleSheet.absoluteFill, styles.glassSurface, draft.playerColor === color && styles.glassSurfaceSelected]}
                />
                <View pointerEvents="none" style={styles.glassHighlight} />
                <View style={styles.colorChoiceContent}>
                  <ChessPiece type="k" color={color} tone={color === 'w' ? draft.whiteTone : draft.blackTone} size={39} />
                  <Text style={[styles.colorChoiceLabel, draft.playerColor === color && styles.selectedOptionText]}>{color === 'w' ? 'White' : 'Black'}</Text>
                </View>
              </Pressable>
            </RevealCard>
          ))}
        </View>

        <Pressable onPress={() => setColorsOpen((open) => !open)} style={styles.disclosure} accessibilityRole="button">
          <View><Text style={styles.sectionTitle}>Piece colors</Text><Text style={styles.disclosureHint}>Customize the two sides independently</Text></View>
          <Text style={styles.disclosureMark}>{colorsOpen ? '−' : '+'}</Text>
        </Pressable>
        {colorsOpen && <RevealCard style={styles.editorCard}>
          <ColorEditor side="w" value={draft.whiteTone} onChange={(tone) => update('whiteTone', tone)} />
          <View style={styles.divider} />
          <ColorEditor side="b" value={draft.blackTone} onChange={(tone) => update('blackTone', tone)} />
        </RevealCard>}

        <Text style={styles.sectionTitle}>Board design</Text>
        <View style={styles.boardRow}>
          {(Object.keys(BOARD_COLORS) as BoardDesign[]).map((design, index) => (
            <RevealCard key={design} delay={75 + index * 45} style={styles.boardCard}>
              <Pressable onPress={() => update('board', design)} style={({ pressed }) => [styles.boardChoice, draft.board === design && styles.selectedChoice, pressed && styles.optionPressed]} accessibilityRole="button" accessibilityState={{ selected: draft.board === design }}>
                <BoardPreview design={design} />
                <Text numberOfLines={1} style={[styles.boardName, draft.board === design && styles.selectedOptionText]}>{BOARD_COLORS[design].title}</Text>
              </Pressable>
            </RevealCard>
          ))}
        </View>

        {mode === 'computer' && <>
          <Text style={styles.sectionTitle}>Computer style</Text>
          <View style={styles.levelGrid}>
            {LEVELS.map((level, index) => (
              <RevealCard key={level.id} delay={130 + index * 35} style={styles.levelCard}>
                <Pressable onPress={() => update('computerLevel', level.id)} style={({ pressed }) => [styles.levelChoice, draft.computerLevel === level.id && styles.selectedChoice, pressed && styles.optionPressed]} accessibilityRole="button" accessibilityState={{ selected: draft.computerLevel === level.id }}>
                  <Text style={[styles.levelTitle, draft.computerLevel === level.id && styles.selectedOptionText]}>{level.title}</Text><Text style={styles.levelDetail}>{level.subtitle}</Text>
                </Pressable>
              </RevealCard>
            ))}
          </View>
        </>}

        <Pressable onPress={start} style={({ pressed }) => [styles.start, pressed && styles.startPressed]} accessibilityRole="button">
          <Text style={styles.startText}>START MATCH</Text><Text style={styles.startArrow}>▶</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f7f7f4' },
  content: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 36, backgroundColor: '#f7f7f4', minHeight: '100%' },
  topBar: { height: 40, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  back: { minHeight: 34, paddingHorizontal: 13, borderRadius: 17, borderWidth: 1, borderColor: '#e2e8e3', backgroundColor: '#fff', justifyContent: 'center' },
  backText: { color: '#34483d', fontSize: 12, fontWeight: '700' },
  step: { color: '#738077', fontSize: 9, letterSpacing: 1.8, fontWeight: '800' },
  heading: { color: '#1f2c26', fontSize: 29, fontWeight: '800', letterSpacing: -0.8, marginTop: 9 },
  intro: { color: '#748078', fontSize: 13, marginTop: 5, marginBottom: 17 },
  sectionTitle: { color: '#26372e', fontSize: 14, fontWeight: '800', letterSpacing: -0.1, marginTop: 19, marginBottom: 10 },
  colorsRow: { flexDirection: 'row', gap: 11 },
  choiceCard: { flex: 1, backgroundColor: '#fff', borderColor: '#e4e9e5', borderWidth: 1, borderRadius: 20, elevation: 2, shadowColor: '#455c4e', shadowOpacity: 0.07, shadowRadius: 10, shadowOffset: { width: 0, height: 4 } },
  colorChoice: { minHeight: 78, paddingHorizontal: 13, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 13, borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: 'transparent', backgroundColor: '#fff' },
  glassSurface: { borderRadius: 20, backgroundColor: 'rgba(255,255,255,.02)' },
  glassSurfaceSelected: { backgroundColor: 'rgba(230,241,234,.2)' },
  glassHighlight: { position: 'absolute', top: 1, left: 5, right: 5, height: 26, borderTopLeftRadius: 18, borderTopRightRadius: 18, backgroundColor: 'rgba(255,255,255,.3)' },
  colorChoiceContent: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 13 },
  colorChoiceLabel: { color: '#26372e', fontSize: 14, fontWeight: '700' },
  selectedColorChoice: { borderColor: '#4e7c6e', borderWidth: 1.5, backgroundColor: '#edf4ef', shadowColor: '#4e7c6e', shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
  selectedChoice: { borderColor: '#4e7c6e', borderWidth: 1.5, backgroundColor: '#edf4ef', shadowColor: '#4e7c6e', shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
  optionPressed: { borderColor: '#4e7c6e', shadowColor: '#4e7c6e', shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: 5 },
  selectedOptionText: { color: '#315f50', textShadowColor: 'rgba(78,124,110,.34)', textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 5 },
  disclosure: { marginTop: 21, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  disclosureHint: { color: '#7b877f', fontSize: 11, marginTop: 3 },
  disclosureMark: { color: '#4e7c6e', fontSize: 24, fontWeight: '500', paddingHorizontal: 5 },
  editorCard: { padding: 15, marginTop: 10, backgroundColor: '#fff', borderColor: '#e2e8e3', borderRadius: 20 },
  colorGroup: { paddingVertical: 5 },
  sectionLabel: { color: '#34483d', fontSize: 12, fontWeight: '800', marginBottom: 10 },
  finishRow: { flexDirection: 'row', gap: 7 },
  finishOption: { flex: 1, minHeight: 61, borderRadius: 13, borderWidth: 1, borderColor: '#e2e8e3', backgroundColor: '#fafbf9', alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 2 },
  finishSelected: { borderColor: '#4e7c6e', borderWidth: 1.5, backgroundColor: '#edf4ef', shadowColor: '#4e7c6e', shadowOpacity: 0.19, shadowRadius: 7, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
  finishDot: { width: 17, height: 17, borderRadius: 9, borderWidth: 1, borderColor: 'rgba(38,55,46,.12)' },
  customDot: { borderWidth: 1.5, borderColor: '#77877d', borderStyle: 'dashed' },
  finishName: { color: '#4c5b52', fontSize: 9, fontWeight: '700' },
  wheelPanel: { alignItems: 'center', paddingTop: 14, paddingBottom: 4 },
  wheelLabel: { color: '#7b877f', fontSize: 11, marginBottom: 8 },
  divider: { height: 1, backgroundColor: '#edf0ed', marginVertical: 9 },
  boardRow: { flexDirection: 'row', gap: 10 },
  boardCard: { flex: 1, backgroundColor: '#fff', borderColor: '#e2e8e3', borderRadius: 18, elevation: 1, shadowColor: '#455c4e', shadowOpacity: 0.05, shadowRadius: 7, shadowOffset: { width: 0, height: 3 } },
  boardChoice: { minHeight: 104, alignItems: 'center', justifyContent: 'center', padding: 9, gap: 9 },
  preview: { width: 54, height: 54, overflow: 'hidden', borderRadius: 9, flexDirection: 'row', flexWrap: 'wrap', borderWidth: 2, borderColor: '#fff', elevation: 3, shadowColor: '#35443b', shadowOpacity: 0.18, shadowRadius: 6, shadowOffset: { width: 0, height: 3 }, transform: [{ perspective: 420 }, { rotateX: '7deg' }] },
  boardName: { color: '#4c5b52', fontSize: 10, fontWeight: '700' },
  levelGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  levelCard: { width: '48%', flexGrow: 1, backgroundColor: '#fff', borderColor: '#e2e8e3', borderRadius: 17 },
  levelChoice: { minHeight: 66, paddingHorizontal: 12, justifyContent: 'center', gap: 4 },
  levelTitle: { color: '#26372e', fontSize: 12, fontWeight: '800' },
  levelDetail: { color: '#77847c', fontSize: 10, fontWeight: '500' },
  start: { height: 58, borderRadius: 18, backgroundColor: '#4e7c6e', marginTop: 23, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, shadowColor: '#426b5d', shadowOpacity: 0.17, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  startPressed: { borderWidth: 1.5, borderColor: '#b7dcc8', shadowColor: '#98d1b1', shadowOpacity: 0.48, shadowRadius: 16, shadowOffset: { width: 0, height: 0 }, elevation: 7, transform: [{ scale: 0.99 }] },
  startText: { color: '#fff', fontSize: 13, fontWeight: '900', letterSpacing: 1.6, textShadowColor: 'rgba(226,255,238,.62)', textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 8 },
  startArrow: { color: '#fff', fontSize: 11 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
});
