import type { ScribbleStroke } from '@/lib/scribble-config';

export type ScribbleRoom = {
  id: string;
  invite_code: string;
  host_id: string;
  status: 'waiting' | 'active' | 'results' | 'closed';
  phase: 'waiting' | 'choosing' | 'drawing' | 'reveal' | 'results';
  max_players: number;
  cycles: number;
  state_version: number;
  turn_number: number;
  cycle_number: number;
  current_drawer_id: string | null;
  current_turn_id: string | null;
  phase_deadline: string | null;
  canvas_revision: number;
  public_state: Record<string, unknown>;
  created_at: string;
  invite_expires_at: string | null;
};

export type ScribbleMember = {
  user_id: string;
  display_name: string;
  seat: number | null;
  status: 'active' | 'waiting' | 'left';
  is_host: boolean;
  score: number;
  last_seen_at: string;
  online: boolean;
};

export type ScribbleSnapshot = {
  room: ScribbleRoom;
  members: ScribbleMember[];
  turn: { number: number; cycle: number; drawerId: string | null; phase: string; deadline: string | null; revision: number } | null;
  privateTurn: { choices?: string[]; answer?: string } | null;
  strokes: { revision: number; sequence: number; strokes: ScribbleStroke[] }[];
  events: { id: number; actor_id: string | null; event_type: string; body: Record<string, unknown>; created_at: string }[];
  serverNow: string;
};

export type ScribbleAction =
  | { action: 'create'; name: string }
  | { action: 'join'; code: string; name: string }
  | { action: 'start'; roomId: string; cycles: number }
  | { action: 'choose'; roomId: string; word: string }
  | { action: 'guess'; roomId: string; guess: string }
  | { action: 'strokes'; roomId: string; turnId: string; revision: number; strokes: ScribbleStroke[] }
  | { action: 'clear'; roomId: string; turnId: string; revision: number }
  | { action: 'ping'; roomId: string }
  | { action: 'leave'; roomId: string }
  | { action: 'rematch'; roomId: string }
  | { action: 'sync'; roomId: string; code?: string };

export async function callScribbleRoom(supabase: import('@supabase/supabase-js').SupabaseClient, body: ScribbleAction) {
  const { data, error } = await supabase.functions.invoke('scribble-room', { body });
  if (error) {
    const context = error.context;
    if (context instanceof Response) {
      try {
        const payload = await context.clone().json() as { error?: string };
        if (payload.error) throw new Error(payload.error);
      } catch (cause) {
        if (cause instanceof Error && cause.message !== 'Unexpected end of JSON input') throw cause;
      }
    }
    throw new Error(error.message || 'The Scribble room request failed.');
  }
  return data as { room?: ScribbleRoom; code?: string; snapshot?: ScribbleSnapshot; correct?: boolean; points?: number; revision?: number; sequence?: number };
}
