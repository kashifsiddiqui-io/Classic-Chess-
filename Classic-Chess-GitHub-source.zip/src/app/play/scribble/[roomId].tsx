import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Keyboard, Modal, Platform, Pressable, ScrollView, Share, StyleSheet, Text, TextInput, useWindowDimensions, View, type GestureResponderEvent, type ViewStyle } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useGame } from '@/context/game';
import { useAuth } from '@/context/auth';
import { SCRIBBLE_MAX_POINTS_PER_STROKE, type ScribblePoint, type ScribbleStroke } from '@/lib/scribble-config';
import { callScribbleRoom, type ScribbleSnapshot } from '@/lib/scribble-room';
import { loadPlayerActivity, recordCompletedGame } from '@/lib/player-activity';
import { ensureAuthenticatedSession, getSupabase } from '@/lib/supabase';

const ink = '#24312b';
const green = '#4e7c6e';
const palette = ['#26332d', '#dc5b4d', '#e5a63b', '#4e9c72', '#3e78c7', '#9b62b4'];

function pathFor(stroke: ScribbleStroke, width: number, height: number) {
  if (!stroke.points.length) return '';
  return stroke.points.map((point, index) => `${index ? 'L' : 'M'} ${point.x * width} ${point.y * height}`).join(' ');
}

function DrawingCanvas({ strokes, liveStroke, disabled, canvasWidth, canvasHeight, onStart, onMove, onEnd, onLayout }: {
  strokes: ScribbleStroke[]; liveStroke: ScribbleStroke | null; disabled: boolean; canvasWidth: number; canvasHeight: number;
  onStart: (event: GestureResponderEvent) => void; onMove: (event: GestureResponderEvent) => void; onEnd: () => void; onLayout: (width: number, height: number) => void;
}) {
  const all = liveStroke ? [...strokes, liveStroke] : strokes;
  const canvasStyle = Platform.OS === 'web' ? [{ touchAction: 'none' } as unknown as ViewStyle] : undefined;
  return <View style={[styles.canvasFrame, canvasStyle]} onLayout={(event) => {
    const { width: nextWidth, height: nextHeight } = event.nativeEvent.layout;
    onLayout(nextWidth, nextHeight);
  }} onStartShouldSetResponder={() => !disabled} onMoveShouldSetResponder={() => !disabled} onResponderGrant={onStart} onResponderMove={onMove} onResponderRelease={onEnd} onResponderTerminate={onEnd}>
    <Svg width="100%" height="100%" viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}>
      {all.map((stroke, index) => <Path key={`${stroke.id}-${index}`} d={pathFor(stroke, canvasWidth, canvasHeight)} fill="none" stroke={stroke.tool === 'eraser' ? '#ffffff' : stroke.color} strokeWidth={stroke.width} strokeLinecap="round" strokeLinejoin="round" />)}
    </Svg>
    {disabled && <View pointerEvents="none" style={styles.canvasOverlay}><Text style={styles.canvasOverlayText}>The drawer is drawing</Text></View>}
  </View>;
}

export default function ScribbleRoomScreen() {
  const params = useLocalSearchParams<{ roomId?: string | string[]; code?: string | string[] }>();
  const roomId = Array.isArray(params.roomId) ? params.roomId[0] : params.roomId;
  const code = Array.isArray(params.code) ? params.code[0] : params.code;
  const { width: screenWidth } = useWindowDimensions();
  const { onlineProfile } = useGame();
  const { user } = useAuth();
  const [snapshot, setSnapshot] = useState<ScribbleSnapshot | null>(null);
  const [userId, setUserId] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [guess, setGuess] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [penColor, setPenColor] = useState(palette[0]);
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [confirmClear, setConfirmClear] = useState(false);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [liveStroke, setLiveStroke] = useState<ScribbleStroke | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [canvasSize, setCanvasSize] = useState({ width: 1, height: 1 });
  const lastVersion = useRef(-1);
  const strokeRef = useRef<ScribbleStroke | null>(null);
  const supabase = getSupabase();
  const me = snapshot?.members.find((player) => player.user_id === userId);
  const isDrawer = snapshot?.room.current_drawer_id === userId;
  const members = snapshot?.members.filter((player) => player.status !== 'left') ?? [];
  const rankedMembers = roomStatusIsResults(snapshot?.room.status) ? [...members].sort((left, right) => right.score - left.score || left.seat! - right.seat!) : members;
  const winner = rankedMembers.length > 0 && (rankedMembers.length === 1 || rankedMembers[0].score > rankedMembers[1].score) ? rankedMembers[0] : null;
  const inviteUrl = useMemo(() => {
    if (!roomId || !code) return '';
    if (typeof window !== 'undefined') return `${window.location.origin}/play/scribble/${roomId}?code=${code}`;
    return Linking.createURL(`/play/scribble/${roomId}`, { queryParams: { code } });
  }, [roomId, code]);
  const persistedStrokes = useMemo(() => snapshot?.strokes.flatMap((batch) => batch.strokes) ?? [], [snapshot?.strokes]);
  const canvasDisabled = !isDrawer || snapshot?.room.phase !== 'drawing' || busy;

  const sync = useCallback(async (silent = false) => {
    if (!supabase || !roomId) return;
    try {
      const result = await callScribbleRoom(supabase, { action: 'sync', roomId, ...(code ? { code } : {}) });
      if (!result.snapshot) throw new Error('The room did not return its current game state.');
      setSnapshot((previous) => {
        if (previous && result.snapshot!.room.state_version < previous.room.state_version) return previous;
        lastVersion.current = result.snapshot!.room.state_version;
        return result.snapshot!;
      });
      setError('');
    } catch (cause) {
      if (!silent) setError(cause instanceof Error ? cause.message : 'Could not refresh this room.');
    } finally {
      setLoading(false);
    }
  }, [supabase, roomId, code]);

  useEffect(() => {
    if (!supabase || !roomId) return;
    let active = true;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    void ensureAuthenticatedSession(supabase).then(async (session) => {
      if (!active) return;
      setUserId(session.user.id);
      if (code) {
        const activity = await loadPlayerActivity(session.user.id);
        const displayName = activity.name || (onlineProfile.name !== 'Player' ? onlineProfile.name : '');
        if (!displayName) {
          router.replace({ pathname: '/scribble', params: { code } });
          return;
        }
        await callScribbleRoom(supabase, { action: 'join', code, name: displayName });
      }
      if (!active) return;
      channel = supabase.channel(`scribble-${roomId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'scribble_rooms', filter: `id=eq.${roomId}` }, () => { void sync(true); })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'scribble_members', filter: `room_id=eq.${roomId}` }, () => { void sync(true); })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'scribble_drawing_batches', filter: `room_id=eq.${roomId}` }, () => { void sync(true); })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'scribble_events', filter: `room_id=eq.${roomId}` }, () => { void sync(true); })
        .subscribe();
      await sync();
    }).catch((cause) => {
      if (active) { setError(cause instanceof Error ? cause.message : 'Could not join this Scribble room.'); setLoading(false); }
    });
    const poll = setInterval(() => { void sync(true); }, 4000);
    const presence = setInterval(() => {
      if (supabase && roomId) void callScribbleRoom(supabase, { action: 'ping', roomId }).catch(() => {});
    }, 6000);
    return () => {
      active = false;
      clearInterval(poll);
      clearInterval(presence);
      if (channel) void supabase.removeChannel(channel);
    };
  }, [supabase, roomId, code, onlineProfile.name, sync]);

  useEffect(() => {
    if (!snapshot) return;
    const updateCountdown = () => {
      const deadline = snapshot.room.phase_deadline ? Date.parse(snapshot.room.phase_deadline) : 0;
      const offset = Date.parse(snapshot.serverNow) - Date.now();
      setSecondsLeft(Math.max(0, Math.ceil((deadline - (Date.now() + offset)) / 1000)));
    };
    updateCountdown();
    const timer = setInterval(updateCountdown, 250);
    return () => clearInterval(timer);
  }, [snapshot]);

  const isActivePlayer = Boolean(me && me.status === 'active');
  useEffect(() => {
    if (snapshot?.room.status !== 'results' || !isActivePlayer) return;
    void recordCompletedGame(new Date(), user?.id);
  }, [snapshot?.room.status, isActivePlayer, user?.id]);

  const action = useCallback(async (body: Parameters<typeof callScribbleRoom>[1]) => {
    if (!supabase) throw new Error('Supabase is not configured.');
    return callScribbleRoom(supabase, body);
  }, [supabase]);

  async function runAction(body: Parameters<typeof callScribbleRoom>[1], success?: (result: Awaited<ReturnType<typeof callScribbleRoom>>) => void) {
    setBusy(true); setError('');
    try { const result = await action(body); success?.(result); await sync(true); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'That action could not be completed.'); }
    finally { setBusy(false); }
  }

  async function shareRoom() {
    if (!inviteUrl) return;
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(inviteUrl);
        setNotice('Invite link copied. Send it to your friends.');
      } else await Share.share({ message: `Join my Scribble room (${code}): ${inviteUrl}`, url: inviteUrl });
    } catch { setError('Could not share the room link. Copy the room code instead.'); }
  }

  function pointFrom(event: GestureResponderEvent): ScribblePoint {
    return { x: Math.min(1, Math.max(0, event.nativeEvent.locationX / canvasSize.width)), y: Math.min(1, Math.max(0, event.nativeEvent.locationY / canvasSize.height)) };
  }
  function startStroke(event: GestureResponderEvent) {
    const point = pointFrom(event);
    const visualWidth = tool === 'eraser' ? 15 : strokeWidth;
    const stroke: ScribbleStroke = { id: `${userId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, tool, color: penColor, width: Math.max(1, visualWidth / canvasSize.width * 1000), points: [point] };
    strokeRef.current = stroke;
    setLiveStroke(stroke);
  }
  function moveStroke(event: GestureResponderEvent) {
    const current = strokeRef.current;
    if (!current) return;
    const next = [...current.points, pointFrom(event)];
    const updated = { ...current, points: next };
    strokeRef.current = updated;
    setLiveStroke(updated);
  }
  async function endStroke() {
    const current = strokeRef.current;
    if (!current || !roomId) return;
    strokeRef.current = null;
    setLiveStroke(null);
    const chunks: ScribbleStroke[] = [];
    for (let index = 0; index < current.points.length; index += SCRIBBLE_MAX_POINTS_PER_STROKE) {
      chunks.push({ ...current, id: `${current.id}-${index}`, points: current.points.slice(index, index + SCRIBBLE_MAX_POINTS_PER_STROKE) });
    }
    const revision = snapshot?.room.canvas_revision ?? 0;
    const turnId = snapshot?.room.current_turn_id;
    if (!turnId) return;
    for (let index = 0; index < chunks.length; index += 8) {
      await runAction({ action: 'strokes', roomId, turnId, revision, strokes: chunks.slice(index, index + 8) });
    }
  }

  async function submitGuess() {
    if (!roomId || !guess.trim()) return;
    const text = guess.trim(); setGuess(''); Keyboard.dismiss();
    await runAction({ action: 'guess', roomId, guess: text });
  }

  async function leaveRoom() {
    if (roomId) await runAction({ action: 'leave', roomId });
    router.replace('/play');
  }

  if (!roomId || !supabase) return <SafeAreaView style={styles.safe}><View style={styles.content}><Text style={styles.title}>Scribble isn’t connected</Text><Text style={styles.body}>{!roomId ? 'This room link is incomplete.' : 'Supabase is not configured. Add the project URL and publishable key.'}</Text></View></SafeAreaView>;
  if (loading) return <SafeAreaView style={styles.safe}><View style={styles.center}><Text style={styles.title}>Opening Scribble…</Text></View></SafeAreaView>;
  if (!snapshot) return <SafeAreaView style={styles.safe}><View style={styles.content}><Pressable onPress={() => router.back()}><Text style={styles.back}>← Back</Text></Pressable><Text style={styles.title}>Couldn’t open room</Text><Text style={styles.body}>{error || 'This room is unavailable.'}</Text><Pressable style={styles.primary} onPress={() => void sync()}><Text style={styles.primaryText}>TRY AGAIN</Text></Pressable></View></SafeAreaView>;

  const room = snapshot.room;
  const myTurn = isDrawer;
  const publicMasked = typeof room.public_state.masked === 'string' ? room.public_state.masked : '';
  const events = snapshot.events.slice(-12).reverse();
  const boardWidth = Math.min(screenWidth - 40, 520);
  const phaseLabel = room.phase === 'choosing' ? 'CHOOSE A WORD' : room.phase === 'drawing' ? (myTurn ? 'YOUR DRAWING TURN' : 'GUESS THE WORD') : room.phase === 'reveal' ? 'WORD REVEALED' : room.phase === 'results' ? 'FINAL SCORES' : 'PRIVATE LOBBY';

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <View style={styles.topline}><Pressable onPress={() => void leaveRoom()}><Text style={styles.back}>← Leave</Text></Pressable><Text style={styles.kicker}>SCRIBBLE · {phaseLabel}</Text></View>
      <Text style={styles.title}>{room.phase === 'waiting' ? 'Room lobby' : room.phase === 'results' ? 'Well played' : `Round ${room.turn_number}`}</Text>
      {room.status === 'waiting' && <View style={styles.card}>
        <Text style={styles.label}>ROOM CODE</Text><Text style={styles.roomCode}>{room.invite_code}</Text>
        <Text style={styles.body}>Invite 1–7 friends. You can start once at least two players are here.</Text>
        <Pressable onPress={() => void shareRoom()} style={styles.primary}><Text style={styles.primaryText}>SHARE INVITE LINK</Text></Pressable>
        {room.host_id === userId && <View style={styles.hostControls}><Text style={styles.label}>DRAWING CYCLES</Text><View style={styles.cycleRow}>{[1, 2, 3, 4, 5].map((cycles) => <Pressable key={cycles} onPress={() => setSnapshot((old) => old ? { ...old, room: { ...old.room, cycles } } : old)} style={[styles.cycleButton, room.cycles === cycles && styles.cycleSelected]}><Text style={[styles.cycleText, room.cycles === cycles && styles.cycleTextSelected]}>{cycles}</Text></Pressable>)}</View><Pressable disabled={members.length < 2 || busy} onPress={() => { if (roomId) void runAction({ action: 'start', roomId, cycles: room.cycles }); }} style={[styles.primary, members.length < 2 && styles.dim]}><Text style={styles.primaryText}>START GAME</Text></Pressable></View>}
      </View>}

      <View style={styles.card}>
        <View style={styles.rosterHeader}><Text style={styles.label}>PLAYERS · {members.length}/{room.max_players}</Text><Text style={styles.label}>SCORE</Text></View>
        {rankedMembers.map((player) => <View key={player.user_id} style={styles.playerRow}><View style={[styles.onlineDot, !player.online && styles.offlineDot]} /><View style={styles.playerCopy}><Text style={styles.playerName}>{player.display_name}{player.user_id === userId ? ' · YOU' : ''}</Text><Text style={styles.playerMeta}>{player.is_host ? 'HOST' : player.status === 'waiting' ? 'NEXT ROUND' : player.online ? 'ONLINE' : 'RECONNECTING'}</Text></View><Text style={styles.score}>{player.score}</Text></View>)}
      </View>

      {room.status === 'active' && <View style={styles.card}>
        <View style={styles.turnHeader}><View><Text style={styles.label}>{phaseLabel}</Text><Text style={styles.turnTitle}>{room.phase === 'choosing' && myTurn ? 'Pick one of three words' : room.phase === 'choosing' ? `${members.find((p) => p.user_id === room.current_drawer_id)?.display_name ?? 'Player'} is choosing` : room.phase === 'drawing' && myTurn ? `Draw: ${snapshot.privateTurn?.answer ?? ''}` : room.phase === 'drawing' ? `Word: ${publicMasked || '••••••'}` : room.phase === 'reveal' ? `The word was “${String(room.public_state.answer ?? '')}”` : `Cycle ${room.cycle_number} of ${room.cycles}`}</Text></View><Text style={styles.timer}>{secondsLeft}s</Text></View>
        {room.phase === 'choosing' && myTurn && <View style={styles.choiceColumn}>{(snapshot.privateTurn?.choices ?? []).map((word) => <Pressable key={word} disabled={busy} onPress={() => roomId && void runAction({ action: 'choose', roomId, word })} style={styles.choice}><Text style={styles.choiceText}>{word}</Text></Pressable>)}</View>}
        {['drawing', 'reveal'].includes(room.phase) && <View style={[styles.canvasWrap, { width: boardWidth }]}>
          <DrawingCanvas strokes={persistedStrokes} liveStroke={liveStroke} disabled={canvasDisabled} canvasWidth={canvasSize.width} canvasHeight={canvasSize.height} onStart={startStroke} onMove={moveStroke} onEnd={() => { void endStroke(); }} onLayout={(w, h) => setCanvasSize({ width: w || 1, height: h || 1 })} />
        </View>}
        {room.phase === 'drawing' && myTurn && <View style={styles.tools}>
          {palette.map((color) => <Pressable key={color} onPress={() => { setPenColor(color); setTool('pen'); }} style={[styles.colorDot, { backgroundColor: color }, penColor === color && tool === 'pen' && styles.colorSelected]} accessibilityLabel={`Pen color ${color}`} />)}
          {[3, 6, 10].map((size) => <Pressable key={size} onPress={() => { setStrokeWidth(size); setTool('pen'); }} style={[styles.widthButton, strokeWidth === size && tool === 'pen' && styles.widthSelected]} accessibilityLabel={`${size} pen width`}><View style={{ width: size + 4, height: size + 4, borderRadius: 8, backgroundColor: ink }} /></Pressable>)}
          <Pressable onPress={() => setTool(tool === 'eraser' ? 'pen' : 'eraser')} style={[styles.toolButton, tool === 'eraser' && styles.toolSelected]}><Text style={styles.toolText}>ERASER</Text></Pressable>
          <Pressable disabled={busy} onPress={() => setConfirmClear(true)} style={styles.toolButton}><Text style={styles.toolText}>CLEAR</Text></Pressable>
        </View>}
        {room.phase === 'drawing' && !myTurn && <View style={styles.guessRow}><TextInput value={guess} onChangeText={setGuess} onSubmitEditing={() => void submitGuess()} placeholder="Type your guess…" placeholderTextColor="#89928d" maxLength={80} returnKeyType="send" style={styles.guessInput} accessibilityLabel="Your word guess" /><Pressable disabled={!guess.trim() || busy} onPress={() => void submitGuess()} style={styles.sendButton}><Text style={styles.sendText}>GUESS</Text></Pressable></View>}
        <View style={styles.eventFeed}>{events.map((event) => <Text key={event.id} style={event.event_type === 'correct' ? styles.correctEvent : styles.eventText}>{String(event.body.text ?? '')}</Text>)}</View>
      </View>}

      {room.status === 'results' && <View style={styles.card}><Text style={styles.turnTitle}>{winner ? `${winner.display_name} wins!` : 'It’s a tie!'}</Text><Text style={styles.body}>Thanks for playing. Start a rematch with the same group.</Text>{room.host_id === userId && <Pressable onPress={() => roomId && void runAction({ action: 'rematch', roomId })} style={styles.primary}><Text style={styles.primaryText}>PLAY AGAIN</Text></Pressable>}</View>}
      {notice ? <Text style={styles.notice} accessibilityRole="status">{notice}</Text> : null}
      {error ? <Text style={styles.error} accessibilityRole="alert">{error}</Text> : null}
    </ScrollView>
    <Modal visible={confirmClear} transparent animationType="fade" onRequestClose={() => setConfirmClear(false)}>
      <View style={styles.modalBackdrop}><View style={styles.confirmCard}><Text style={styles.turnTitle}>Clear this drawing?</Text><Text style={styles.body}>The current canvas will be cleared for everyone in the room.</Text><View style={styles.confirmActions}><Pressable onPress={() => setConfirmClear(false)} style={styles.cancelButton}><Text style={styles.cancelText}>CANCEL</Text></Pressable><Pressable onPress={() => { setConfirmClear(false); if (roomId && room.current_turn_id) void runAction({ action: 'clear', roomId, turnId: room.current_turn_id, revision: room.canvas_revision }); }} style={styles.primary}><Text style={styles.primaryText}>CLEAR CANVAS</Text></Pressable></View></View></View>
    </Modal>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f7f7f4' }, content: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 30, gap: 14 }, center: { flex: 1, alignItems: 'center', justifyContent: 'center' }, topline: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 34 }, back: { color: ink, fontSize: 12, fontWeight: '800' }, kicker: { color: green, fontSize: 9, fontWeight: '900', letterSpacing: 1.5 }, title: { color: ink, fontSize: 28, lineHeight: 34, letterSpacing: -0.6, fontWeight: '900', marginBottom: 1 }, card: { padding: 15, borderRadius: 20, borderWidth: 1, borderColor: '#dce4dd', backgroundColor: '#fff', gap: 12 }, label: { color: '#718077', fontSize: 9, letterSpacing: 1.3, fontWeight: '900' }, roomCode: { color: green, fontSize: 29, letterSpacing: 5, fontWeight: '900' }, body: { color: '#69756f', fontSize: 12, lineHeight: 18 }, primary: { minHeight: 46, borderRadius: 14, backgroundColor: green, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 15 }, primaryText: { color: '#fff', fontSize: 10, letterSpacing: 1.3, fontWeight: '900' }, hostControls: { borderTopWidth: 1, borderColor: '#edf0ed', paddingTop: 11, gap: 10 }, cycleRow: { flexDirection: 'row', gap: 8 }, cycleButton: { width: 38, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 11, backgroundColor: '#f2f5f2' }, cycleSelected: { backgroundColor: green }, cycleText: { color: ink, fontWeight: '800' }, cycleTextSelected: { color: '#fff' }, dim: { opacity: 0.45 }, rosterHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, playerRow: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderColor: '#f0f2f0', paddingTop: 8 }, onlineDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: '#55a77b' }, offlineDot: { backgroundColor: '#c7cdc8' }, playerCopy: { flex: 1 }, playerName: { color: ink, fontSize: 13, fontWeight: '800' }, playerMeta: { color: '#87918a', fontSize: 8, letterSpacing: 1, marginTop: 3, fontWeight: '700' }, score: { color: green, fontSize: 16, fontWeight: '900' }, turnHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, turnTitle: { color: ink, fontSize: 15, fontWeight: '800', marginTop: 5 }, timer: { color: green, fontSize: 22, fontWeight: '900' }, choiceColumn: { gap: 8 }, choice: { borderRadius: 13, backgroundColor: '#edf4ef', borderWidth: 1, borderColor: '#d6e7da', padding: 12, alignItems: 'center' }, choiceText: { color: ink, fontSize: 13, fontWeight: '800', textTransform: 'capitalize' }, canvasWrap: { alignSelf: 'center' }, canvasFrame: { width: '100%', height: 300, overflow: 'hidden', borderRadius: 15, borderWidth: 1, borderColor: '#dce2dc', backgroundColor: '#fff' }, canvasOverlay: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(247,247,244,0.28)' }, canvasOverlayText: { color: '#606c64', fontSize: 11, fontWeight: '700' }, tools: { flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' }, colorDot: { width: 25, height: 25, borderRadius: 13, borderWidth: 2, borderColor: '#fff' }, colorSelected: { borderColor: '#9ab9a2', transform: [{ scale: 1.12 }] }, widthButton: { width: 33, height: 33, borderRadius: 11, backgroundColor: '#f0f3f0', alignItems: 'center', justifyContent: 'center' }, widthSelected: { borderColor: green, borderWidth: 1.5 }, toolButton: { minHeight: 32, paddingHorizontal: 10, borderRadius: 10, backgroundColor: '#f0f3f0', justifyContent: 'center' }, toolSelected: { backgroundColor: '#e5ece6' }, toolText: { color: ink, fontSize: 8, letterSpacing: 1, fontWeight: '900' }, guessRow: { flexDirection: 'row', gap: 8 }, guessInput: { flex: 1, minHeight: 45, borderWidth: 1, borderColor: '#dce4dd', borderRadius: 13, backgroundColor: '#fbfcfb', paddingHorizontal: 12, color: ink, fontSize: 13 }, sendButton: { paddingHorizontal: 14, borderRadius: 13, backgroundColor: green, alignItems: 'center', justifyContent: 'center' }, sendText: { color: '#fff', fontSize: 9, letterSpacing: 1, fontWeight: '900' }, eventFeed: { gap: 5, maxHeight: 120 }, eventText: { color: '#79837d', fontSize: 11, lineHeight: 16 }, correctEvent: { color: green, fontSize: 11, lineHeight: 16, fontWeight: '800' }, notice: { borderRadius: 12, backgroundColor: '#e8f2ea', color: '#416c4e', padding: 11, fontSize: 11, lineHeight: 16 }, error: { borderRadius: 12, backgroundColor: '#fdeae7', color: '#9e3c34', padding: 11, fontSize: 11, lineHeight: 16 }, modalBackdrop: { flex: 1, padding: 24, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(22,31,26,0.48)' }, confirmCard: { width: '100%', maxWidth: 380, padding: 20, gap: 12, borderRadius: 22, backgroundColor: '#fff' }, confirmActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 9, marginTop: 5 }, cancelButton: { minHeight: 44, paddingHorizontal: 14, borderRadius: 13, backgroundColor: '#f0f3f0', justifyContent: 'center' }, cancelText: { color: ink, fontSize: 9, letterSpacing: 1, fontWeight: '900' },
});

function roomStatusIsResults(status: string | undefined) {
  return status === 'results';
}
