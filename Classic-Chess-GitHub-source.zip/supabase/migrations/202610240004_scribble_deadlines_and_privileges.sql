create or replace function public.scribble_advance_due_rooms(p_room_id uuid default null)
returns integer language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; player record;
  active_ids uuid[]; next_drawer uuid; next_turn uuid; next_number integer; processed integer := 0;
begin
  for room in select * from public.scribble_rooms
    where status = 'active' and (p_room_id is null or id = p_room_id) and (
      phase_deadline <= clock_timestamp()
      or (phase = 'drawing' and drawer_grace_deadline is not null and drawer_grace_deadline <= clock_timestamp())
      or (phase = 'drawing' and drawer_grace_deadline is null and phase_deadline > clock_timestamp()
        and exists (select 1 from public.scribble_members m where m.room_id = public.scribble_rooms.id
          and m.user_id = public.scribble_rooms.current_drawer_id and m.status = 'active'
          and m.last_seen_at < clock_timestamp() - interval '18 seconds'))
    )
    order by phase_deadline for update skip locked
  loop
    select * into turn from public.scribble_turns where id = room.current_turn_id for update;
    if room.phase = 'drawing' and room.phase_deadline > clock_timestamp() and exists (
      select 1 from public.scribble_members m where m.room_id = room.id and m.user_id = room.current_drawer_id
        and m.status = 'active' and m.last_seen_at < clock_timestamp() - interval '18 seconds'
    ) then
      if room.drawer_grace_deadline is null then
        update public.scribble_rooms set drawer_grace_deadline = clock_timestamp() + interval '15 seconds',
          state_version = state_version + 1, updated_at = now() where id = room.id;
        continue;
      elsif room.drawer_grace_deadline > clock_timestamp() then
        continue;
      else
        update public.scribble_turns set ended_at = now() where id = turn.id;
        update public.scribble_rooms set phase = 'reveal', phase_deadline = clock_timestamp() + make_interval(secs => room.reveal_seconds),
          drawer_grace_deadline = null, public_state = jsonb_build_object('answer', turn.answer, 'reason', 'drawer_disconnected'),
          state_version = state_version + 1, updated_at = now() where id = room.id;
        insert into public.scribble_events (room_id, turn_id, event_type, body) values
          (room.id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'The drawer did not reconnect in time.'));
        processed := processed + 1;
        continue;
      end if;
    end if;
    if room.phase = 'choosing' then
      update public.scribble_turns set answer = choices[1] where id = turn.id;
      update public.scribble_rooms set phase = 'drawing', phase_deadline = clock_timestamp() + make_interval(secs => room.draw_seconds),
        public_state = jsonb_build_object('masked', regexp_replace(btrim(turn.choices[1]), '[A-Za-z]', '_', 'g')),
        state_version = state_version + 1, updated_at = now() where id = room.id;
    elsif room.phase = 'drawing' then
      update public.scribble_turns set ended_at = now() where id = turn.id;
      update public.scribble_rooms set phase = 'reveal', phase_deadline = clock_timestamp() + make_interval(secs => room.reveal_seconds),
        public_state = jsonb_build_object('answer', turn.answer, 'reason', 'time'), state_version = state_version + 1, updated_at = now()
        where id = room.id;
      insert into public.scribble_events (room_id, turn_id, event_type, body) values
        (room.id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'Time is up.'));
    elsif room.phase = 'reveal' then
      room.drawn_this_cycle := array_append(room.drawn_this_cycle, room.current_drawer_id);
      for player in select user_id from public.scribble_members where room_id = room.id and status = 'waiting' order by joined_at for update loop
        update public.scribble_members set status = 'active',
          seat = (select coalesce(max(seat), 0) + 1 from public.scribble_members where room_id = room.id and status = 'active'),
          last_seen_at = now() where room_id = room.id and user_id = player.user_id;
        room.turn_order := array_append(room.turn_order, player.user_id);
      end loop;

      select array_agg(user_id order by seat) into active_ids
        from public.scribble_members where room_id = room.id and status = 'active';
      if coalesce(cardinality(active_ids), 0) < 2 then
        update public.scribble_rooms set status = 'results', phase = 'results', phase_deadline = null, finished_at = now(),
          public_state = jsonb_build_object('answer', turn.answer, 'reason', 'players_left'), state_version = state_version + 1, updated_at = now()
          where id = room.id;
      else
        if active_ids <@ room.drawn_this_cycle then
          if room.cycle_number >= room.cycles then
            update public.scribble_rooms set status = 'results', phase = 'results', phase_deadline = null, finished_at = now(),
              public_state = jsonb_build_object('answer', turn.answer, 'reason', 'complete'), state_version = state_version + 1, updated_at = now()
              where id = room.id;
          else
            room.cycle_number := room.cycle_number + 1;
            room.drawn_this_cycle := '{}';
          end if;
        end if;

        if room.cycle_number > 0 and not exists (
          select 1 from public.scribble_rooms r where r.id = room.id and r.status = 'results'
        ) then
          select roster.user_id into next_drawer
            from unnest(room.turn_order) with ordinality as roster(user_id, position)
            where roster.user_id = any(active_ids) and not (roster.user_id = any(room.drawn_this_cycle))
            order by roster.position limit 1;
          if next_drawer is null then
            next_drawer := active_ids[1];
            room.cycle_number := least(room.cycles, room.cycle_number + 1);
            room.drawn_this_cycle := '{}';
          end if;
          next_number := room.turn_number + 1;
          next_turn := public.scribble_make_turn(room.id, next_number, room.cycle_number, next_drawer);
          update public.scribble_rooms set phase = 'choosing', turn_number = next_number, cycle_number = room.cycle_number,
            turn_order = room.turn_order, drawn_this_cycle = room.drawn_this_cycle, current_drawer_id = next_drawer,
            current_turn_id = next_turn, phase_deadline = clock_timestamp() + make_interval(secs => room.choose_seconds),
            drawer_grace_deadline = null, canvas_revision = 0, public_state = '{}'::jsonb, state_version = state_version + 1, updated_at = now()
            where id = room.id;
        end if;
      end if;
    end if;
    processed := processed + 1;
  end loop;
  return processed;
end $$;

-- Cron is the authoritative fallback for deadlines when every player is offline.
do $$
declare job_id bigint;
begin
  for job_id in select jobid from cron.job where jobname in ('scribble-advance-deadlines', 'scribble-cleanup-expired-invites') loop
    perform cron.unschedule(job_id);
  end loop;
  perform cron.schedule('scribble-advance-deadlines', '* * * * *', 'select public.scribble_advance_due_rooms();');
  perform cron.schedule('scribble-cleanup-expired-invites', '* * * * *', $cleanup$
    delete from public.scribble_rooms where status = 'waiting' and invite_expires_at <= now();
    delete from public.scribble_rooms where status in ('results', 'closed') and updated_at < now() - interval '30 days';
  $cleanup$);
end $$;

revoke all on function public.scribble_create_room(uuid, text, text), public.scribble_join_room(text, uuid, text),
  public.scribble_start_room(uuid, uuid, smallint), public.scribble_choose_word(uuid, uuid, text),
  public.scribble_guess(uuid, uuid, text), public.scribble_append_strokes(uuid, uuid, uuid, integer, jsonb),
  public.scribble_clear_canvas(uuid, uuid, uuid, integer), public.scribble_ping(uuid, uuid),
  public.scribble_leave_room(uuid, uuid), public.scribble_rematch(uuid, uuid), public.scribble_advance_due_rooms(uuid),
  public.scribble_make_turn(uuid, integer, smallint, uuid)
from public, anon, authenticated;
grant execute on function public.scribble_create_room(uuid, text, text), public.scribble_join_room(text, uuid, text),
  public.scribble_start_room(uuid, uuid, smallint), public.scribble_choose_word(uuid, uuid, text),
  public.scribble_guess(uuid, uuid, text), public.scribble_append_strokes(uuid, uuid, uuid, integer, jsonb),
  public.scribble_clear_canvas(uuid, uuid, uuid, integer), public.scribble_ping(uuid, uuid),
  public.scribble_leave_room(uuid, uuid), public.scribble_rematch(uuid, uuid), public.scribble_advance_due_rooms(uuid),
  public.scribble_make_turn(uuid, integer, smallint, uuid)
to service_role;
grant execute on function public.scribble_advance_due_rooms(uuid) to postgres;
