import { useId } from 'react';
import Svg, { Defs, Ellipse, G, LinearGradient, Path, RadialGradient, Stop } from 'react-native-svg';

import { CHESS_PIECE_PATHS } from '@/components/chess-piece-paths';
import type { PieceTone, PlayerColor } from '@/constants/chess';

function channels(hex: string) {
  return hex.slice(1).match(/.{2}/g)?.map((value) => Number.parseInt(value, 16)) ?? [130, 130, 130];
}

function tint(hex: string, amount: number) {
  const rgb = channels(hex);
  return `#${rgb.map((channel) => Math.round(channel + ((amount > 0 ? 255 : 0) - channel) * Math.abs(amount)).toString(16).padStart(2, '0')).join('')}`;
}

const toneHex: Record<string, string> = {
  pearl: '#eee0c6', silver: '#d7dce4', gold: '#d9a849',
  onyx: '#292d33', emerald: '#306a55', sapphire: '#31588b',
};

const pieceNames: Record<string, string> = {
  p: 'pawn', r: 'rook', n: 'knight', b: 'bishop', q: 'queen', k: 'king',
};

export function ChessPiece({ type, color, tone, size = 44 }: { type: string; color: PlayerColor; tone: PieceTone; size?: number }) {
  const id = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const pieceType = type.toLowerCase();
  const paths = CHESS_PIECE_PATHS[pieceType as keyof typeof CHESS_PIECE_PATHS] ?? CHESS_PIECE_PATHS.k;
  const base = /^#[\da-f]{6}$/i.test(tone) ? tone : toneHex[tone] ?? '#888888';
  const sideBase = color === 'w' ? tint(base, 0.08) : tint(base, -0.04);
  const edge = tint(sideBase, color === 'w' ? -0.48 : -0.58);
  const accent = color === 'w' ? tint(sideBase, -0.36) : tint(sideBase, 0.62);

  return (
    <Svg width={size} height={size * 1.12} viewBox="0 0 4096 4096" accessibilityLabel={`${color === 'w' ? 'White' : 'Black'} ${pieceNames[pieceType] ?? 'chess piece'}`}>
      <Defs>
        <LinearGradient id={`${id}-metal`} x1="8%" y1="5%" x2="94%" y2="76%">
          <Stop offset="0%" stopColor={tint(sideBase, -0.68)} />
          <Stop offset="12%" stopColor={tint(sideBase, 0.16)} />
          <Stop offset="25%" stopColor={tint(sideBase, 0.9)} />
          <Stop offset="34%" stopColor={tint(sideBase, 0.38)} />
          <Stop offset="48%" stopColor={sideBase} />
          <Stop offset="61%" stopColor={tint(sideBase, -0.22)} />
          <Stop offset="73%" stopColor={tint(sideBase, 0.32)} />
          <Stop offset="86%" stopColor={tint(sideBase, -0.5)} />
          <Stop offset="100%" stopColor={tint(sideBase, -0.76)} />
        </LinearGradient>
        <RadialGradient id={`${id}-gloss`} cx="28%" cy="18%" r="82%">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.78" />
          <Stop offset="24%" stopColor="#ffffff" stopOpacity="0.34" />
          <Stop offset="58%" stopColor="#ffffff" stopOpacity="0.06" />
          <Stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </RadialGradient>
        <RadialGradient id={`${id}-shadow`} cx="50%" cy="50%" r="50%">
          <Stop offset="0%" stopColor="#15120d" stopOpacity="0.28" />
          <Stop offset="62%" stopColor="#15120d" stopOpacity="0.12" />
          <Stop offset="100%" stopColor="#15120d" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      <Ellipse cx="2048" cy="3835" rx="1260" ry="154" fill={`url(#${id}-shadow)`} opacity={color === 'w' ? 0.84 : 1} />
      <G transform="translate(0 54)" fill={tint(sideBase, -0.82)} opacity={0.52}>
        {paths.filter((path) => !path.detail).map((path, index) => <Path key={`shadow-${index}`} d={path.d} />)}
      </G>
      {paths.map((path, index) => (
        <Path
          key={index}
          d={path.d}
          fill={path.detail ? accent : `url(#${id}-metal)`}
          opacity={path.detail ? 0.86 : 1}
          stroke={path.detail ? 'none' : edge}
          strokeWidth={path.detail ? 0 : 28}
          strokeOpacity={path.detail ? 0 : 0.72}
          strokeLinejoin="round"
        />
      ))}
      <G fill={`url(#${id}-gloss)`} opacity={color === 'w' ? 0.38 : 0.27}>
        {paths.filter((path) => !path.detail).map((path, index) => <Path key={`gloss-${index}`} d={path.d} />)}
      </G>
    </Svg>
  );
}
