-- Add the displayed +50 silver gift to the existing 200 silver AI win award.
create or replace function public.settle_trophy_ai_match(p_match_id uuid, p_result text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  match_row public.trophy_ai_matches%rowtype;
  wallet public.trophy_wallets%rowtype;
  award integer := 0;
begin
  if p_result not in ('win', 'loss', 'draw') then raise exception 'Invalid match result.' using errcode = '22023'; end if;
  select * into match_row from public.trophy_ai_matches where id = p_match_id for update;
  if not found then raise exception 'Trophy match was not found.' using errcode = 'P0002'; end if;
  if match_row.status = 'settled' then
    select * into wallet from public.trophy_wallets where user_id = match_row.user_id;
    return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'alreadySettled', true);
  end if;
  if match_row.started_at < now() - interval '12 hours' then raise exception 'This trophy match has expired.' using errcode = 'P0001'; end if;

  insert into public.trophy_wallets (user_id) values (match_row.user_id) on conflict (user_id) do nothing;
  select * into wallet from public.trophy_wallets where user_id = match_row.user_id for update;
  if p_result = 'win' then award := 250;
  elsif p_result = 'loss' and wallet.silver >= 200 then award := -20;
  end if;

  update public.trophy_wallets
    set silver = silver + award, updated_at = now()
    where user_id = match_row.user_id returning * into wallet;
  update public.trophy_ai_matches set status = 'settled', result = p_result, settled_at = now() where id = p_match_id;
  if award <> 0 then
    insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
      values (match_row.user_id, 'silver', award, 'computer_chess', p_match_id);
  end if;
  return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'awardedSilver', award, 'alreadySettled', false);
end $$;
