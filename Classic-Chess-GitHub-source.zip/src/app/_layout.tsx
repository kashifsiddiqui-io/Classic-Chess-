import { Stack } from 'expo-router';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef } from 'react';
import { View } from 'react-native';
import { App as CapacitorApp } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';

import { GameProvider } from '@/context/game';
import { AuthProvider } from '@/context/auth';
import { AuthGate } from '@/components/auth-gate';
import { RouteTransitionLoader } from '@/components/route-transition-loader';
import { APP_DEEP_LINK_SCHEME } from '@/lib/auth-profile';

function NativeAuthDeepLinkListener() {
  const handledUrl = useRef('');

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    let active = true;
    let removeListener: (() => void) | undefined;

    const routeAuthCallback = (rawUrl: string) => {
      if (!active || rawUrl === handledUrl.current) return;
      let callback: URL;
      try {
        callback = new URL(rawUrl);
      } catch {
        return;
      }
      if (callback.protocol !== `${APP_DEEP_LINK_SCHEME}:` || callback.hostname !== 'auth' || callback.pathname !== '/callback') return;

      handledUrl.current = rawUrl;
      const params = Object.fromEntries(callback.searchParams.entries());
      router.replace({ pathname: '/auth/callback', params } as never);
      void Browser.close().catch(() => {});
    };

    void CapacitorApp.addListener('appUrlOpen', ({ url }) => routeAuthCallback(url)).then((listener) => {
      if (active) removeListener = () => { void listener.remove(); };
      else void listener.remove();
    });
    void CapacitorApp.getLaunchUrl().then((launch) => {
      if (launch?.url) routeAuthCallback(launch.url);
    }).catch(() => {});

    return () => {
      active = false;
      removeListener?.();
    };
  }, []);

  return null;
}

export default function RootLayout() {
  return (
    <AuthProvider>
      <GameProvider>
        <NativeAuthDeepLinkListener />
        <StatusBar style="light" />
        <AuthGate>
          <View style={{ flex: 1 }}>
            <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: '#080c0b' }, animation: 'fade' }}>
              <Stack.Screen name="index" />
              <Stack.Screen name="auth/index" />
              <Stack.Screen name="auth/callback" />
              <Stack.Screen name="play" />
              <Stack.Screen name="setup" />
              <Stack.Screen name="online" />
              <Stack.Screen name="game" />
              <Stack.Screen name="trophy" />
              <Stack.Screen name="leaderboard" />
              <Stack.Screen name="profile" />
            </Stack>
            <RouteTransitionLoader />
          </View>
        </AuthGate>
      </GameProvider>
    </AuthProvider>
  );
}
