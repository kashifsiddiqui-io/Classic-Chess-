import { useCallback, useEffect, useRef, useState } from 'react';

type WebAudio = {
  currentTime: number;
  volume: number;
  preload: string;
  play: () => Promise<void>;
  pause: () => void;
};

export function useChessMoveSound() {
  const audio = useRef<WebAudio | null>(null);
  const [unavailable, setUnavailable] = useState(false);

  useEffect(() => {
    const AudioConstructor = (globalThis as typeof globalThis & { Audio?: new (source?: string) => WebAudio }).Audio;
    if (!AudioConstructor) return;
    const player = new AudioConstructor('/sounds/chess-move.mp3');
    player.preload = 'auto';
    player.volume = 0.72;
    audio.current = player;
    return () => {
      player.pause();
      audio.current = null;
    };
  }, []);

  const play = useCallback(() => {
    if (!audio.current) return;
    audio.current.currentTime = 0;
    void audio.current.play().catch(() => setUnavailable(true));
  }, []);

  return { play, unavailable };
}
