drop function if exists public.get_trophy_leaderboard();

create function public.get_trophy_leaderboard()
returns table(rank_position bigint, user_id uuid, player_name text, silver integer, gold integer)
language sql stable security definer set search_path = '' as $$
  with ranked_players as (
    select wallet.user_id,
           case
             when nullif(btrim(profile.display_name), '') is not null
                  and position('@' in profile.display_name) = 0
               then btrim(profile.display_name)
             else profile.username
           end as player_name,
           wallet.silver,
           wallet.gold
    from public.trophy_wallets as wallet
    join public.player_profiles as profile on profile.user_id = wallet.user_id
    where profile.username ~ '^[a-z0-9._-]{3,20}$'
  )
  select row_number() over (order by ranked_players.gold desc, ranked_players.silver desc, lower(ranked_players.player_name) asc),
         ranked_players.user_id,
         ranked_players.player_name,
         ranked_players.silver,
         ranked_players.gold
  from ranked_players
  order by ranked_players.gold desc, ranked_players.silver desc, lower(ranked_players.player_name) asc
  limit 100;
$$;

revoke all on function public.get_trophy_leaderboard() from public, anon;
grant execute on function public.get_trophy_leaderboard() to authenticated;

notify pgrst, 'reload schema';
