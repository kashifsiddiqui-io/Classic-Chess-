import { router, useFocusEffect } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useAuth } from '@/context/auth';
import { loadTrophyLeaderboard, type TrophyLeader } from '@/lib/trophies';
import { getSupabase } from '@/lib/supabase';

const green = '#4e7c6e';
const ink = '#1f2c26';

function LeaderboardIcon() {
  return <Svg width={30} height={30} viewBox="0 0 24 24" accessibilityLabel="Leaderboard">
    <Path d="M15 21H9V12.6c0-.33.27-.6.6-.6h4.8c.33 0 .6.27.6.6V21ZM20.4 21H15v-2.9c0-.33.27-.6.6-.6h4.8c.33 0 .6.27.6.6v2.3c0 .33-.27.6-.6.6ZM9 21v-4.9c0-.33-.27-.6-.6-.6H3.6c-.33 0-.6.27-.6.6v4.3c0 .33.27.6.6.6H9ZM10.81 5.11l.9-1.92c.12-.25.46-.25.58 0l.9 1.92 2.04.31c.26.04.37.38.18.57l-1.48 1.5.35 2.12c.05.27-.23.48-.46.35L12 8.96l-1.82 1c-.23.13-.51-.08-.46-.35l.35-2.12-1.48-1.5c-.19-.19-.08-.53.18-.57l2.04-.31Z" fill="none" stroke={green} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>;
}

export default function LeaderboardScreen() {
  const { user } = useAuth();
  const [players, setPlayers] = useState<TrophyLeader[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useFocusEffect(useCallback(() => {
    let active = true;
    const supabase = getSupabase();
    if (!supabase || !user?.id) {
      setError('Sign in to see the leaderboard.');
      setLoading(false);
      return () => { active = false; };
    }
    setLoading(true);
    void loadTrophyLeaderboard(supabase).then((rows) => {
      if (active) { setPlayers(rows); setError(''); }
    }).catch((cause: unknown) => {
      if (active) setError(cause instanceof Error ? cause.message : 'Could not load the leaderboard.');
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [user]));

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <StatusBar style="dark" animated />
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Pressable onPress={() => router.back()} style={styles.back} accessibilityRole="button"><Text style={styles.backText}>← Back</Text></Pressable>
      <View style={styles.titleRow}><View style={styles.iconTile}><LeaderboardIcon /></View><View style={styles.titleCopy}><Text style={styles.eyebrow}>PLAYERS WORLDWIDE</Text><Text style={styles.title}>Leaderboard</Text></View></View>
      <Text style={styles.subtitle}>Ranked by gold trophies. Silver breaks ties.</Text>
      <View style={styles.listHeader}><Text style={styles.listHeaderPlayer}>PLAYER</Text><Text style={styles.listHeaderText}>SILVER</Text><Text style={styles.listHeaderText}>GOLD</Text></View>
      {players.map((player) => <View key={player.user_id} style={[styles.playerRow, player.user_id === user?.id && styles.ownRow]}>
        <Text style={[styles.rank, player.position <= 3 && styles.topRank]}>{String(player.position).padStart(2, '0')}</Text>
        <View style={styles.playerName}><Text numberOfLines={1} style={styles.playerLabel}>{player.player_name}</Text></View>
        <Text style={styles.silver}>{player.silver}</Text>
        <Text style={styles.gold}>{player.gold}</Text>
      </View>)}
      {loading && <View style={styles.loading}><ActivityIndicator color={green} /><Text style={styles.emptyText}>Loading players…</Text></View>}
      {!loading && !error && players.length === 0 && <Text style={styles.emptyText}>No trophy players yet. Finish a chess match to be first.</Text>}
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <Pressable onPress={() => router.push('/trophy')} style={styles.walletLink} accessibilityRole="button"><Text style={styles.walletLinkText}>OPEN TROPHY WALLET  ↗</Text></Pressable>
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f7f7f4' },
  content: { width: '100%', maxWidth: 680, alignSelf: 'center', paddingHorizontal: 20, paddingTop: 17, paddingBottom: 36 },
  back: { alignSelf: 'flex-start', paddingVertical: 8, paddingRight: 14, marginBottom: 23 },
  backText: { color: green, fontSize: 12, fontWeight: '800' },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconTile: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e8f0ea' },
  titleCopy: { flex: 1 },
  eyebrow: { color: green, fontSize: 9, fontWeight: '900', letterSpacing: 1.8 },
  title: { color: ink, fontSize: 27, fontWeight: '900', letterSpacing: -0.8, marginTop: 2 },
  subtitle: { color: '#78837c', fontSize: 12, marginTop: 10, marginBottom: 18 },
  listHeader: { minHeight: 38, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, marginBottom: 7 },
  listHeaderPlayer: { flex: 1, color: '#89948d', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 },
  listHeaderText: { color: '#89948d', fontSize: 8, fontWeight: '900', letterSpacing: 1.1, textAlign: 'right', width: 53 },
  playerRow: { minHeight: 72, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, marginBottom: 9, borderWidth: 1, borderColor: '#e2e9e3', borderRadius: 20, backgroundColor: '#fff', shadowColor: '#263a30', shadowOpacity: 0.045, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 1 },
  ownRow: { backgroundColor: '#eef5f0', borderColor: '#cfdfd3' },
  rank: { width: 35, color: '#919a94', fontSize: 12, fontWeight: '900' },
  topRank: { color: green },
  playerName: { flex: 1, minWidth: 0, paddingRight: 6 },
  playerLabel: { color: ink, fontSize: 15, fontWeight: '900', letterSpacing: -0.15 },
  silver: { width: 53, color: '#75818a', fontSize: 12, fontWeight: '800', textAlign: 'right' },
  gold: { width: 53, color: '#a98232', fontSize: 13, fontWeight: '900', textAlign: 'right' },
  loading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, padding: 24 },
  emptyText: { color: '#78837c', fontSize: 11, textAlign: 'center', padding: 24 },
  error: { color: '#a33b32', fontSize: 11, marginTop: 14 },
  walletLink: { minHeight: 50, alignItems: 'center', justifyContent: 'center', marginTop: 16, borderRadius: 17, backgroundColor: '#202923' },
  walletLinkText: { color: '#fff', fontSize: 11, fontWeight: '900', letterSpacing: 1.1 },
});
