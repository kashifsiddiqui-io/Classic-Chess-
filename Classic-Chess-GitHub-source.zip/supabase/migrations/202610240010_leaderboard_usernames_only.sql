drop function if exists public.get_trophy_leaderboard();

create function public.get_trophy_leaderboard()
returns table(rank_position bigint, user_id uuid, username text, silver integer, gold integer)
language sql stable security definer set search_path = '' as $$
  select row_number() over (order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc),
         wallet.user_id, profile.username, wallet.silver, wallet.gold
  from public.trophy_wallets as wallet
  join public.player_profiles as profile on profile.user_id = wallet.user_id
  where profile.username ~ '^[a-z0-9._-]{3,20}$'
  order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc
  limit 100;
$$;

revoke all on function public.get_trophy_leaderboard() from public, anon;
grant execute on function public.get_trophy_leaderboard() to authenticated;
