import { router, useFocusEffect } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { createElement, useCallback, useEffect, useRef, useState } from 'react';
import { Image, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ChessPiece } from '@/components/chess-piece';
import { RevealCard } from '@/components/reveal-card';
import { TrophyIcon } from '@/components/trophy-icon';
import { markScribbleTransition } from '@/components/route-transition-loader';
import { useGame } from '@/context/game';
import { useAuth } from '@/context/auth';
import { getSupabase } from '@/lib/supabase';
import { getNextDailyReset, getTrackingDayKey, loadPlayerActivity, savePlayerName, type ActivitySummary } from '@/lib/player-activity';
import { emptyTrophyWallet, loadTrophyWallet, type TrophyWallet } from '@/lib/trophies';

import '../components/streak-typewriter.css';

const green = '#4e7c6e';
const canvas = '#f7f7f4';
const dark = '#1f2c26';
const blankSummary: ActivitySummary = { streakDays: 0, completedToday: false, lastSevenDays: [] };

function FlameIcon({ size = 25 }: { size?: number }) {
  return <Svg width={size} height={size} viewBox="0 0 24 28" accessibilityLabel="Fire">
    <Path d="M13.4 1.5c.6 5.2-3.7 6.8-3.3 11.1-1.4-1-2-2.5-1.9-4.3C4.3 11.4 2.5 15 3.2 19c.8 4.4 4.4 7.4 8.9 7.4s8.7-3.2 8.7-8.4c0-4.2-2.6-7.3-7.4-11.2.2 2.2-.5 3.5-1.5 4.1 1.1-3.3 1-6.2 1.5-9.4Z" fill="#e97945" />
    <Path d="M12.4 15c.1 2.1-2.5 3-2.5 5.4 0 1.7 1 2.8 2.4 2.8s2.7-1.2 2.7-3c0-1.8-1.2-3.5-2.6-5.2Z" fill="#ffd18c" />
  </Svg>;
}

function HomeIcon({ active }: { active: boolean }) {
  return <Svg width={21} height={21} viewBox="0 0 24 24" accessibilityLabel="Home">
    <Path d="m3.5 10.7 8.5-7 8.5 7M5.5 9.3v10h13v-10M9.5 19.3v-6h5v6" fill="none" stroke={active ? '#fff' : '#637168'} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>;
}

function LeaderboardIcon({ active }: { active: boolean }) {
  const color = active ? '#fff' : '#637168';
  return <Svg width={21} height={21} viewBox="0 0 24 24" accessibilityLabel="Leaderboard">
    <Path d="M15 21H9V12.6c0-.33.27-.6.6-.6h4.8c.33 0 .6.27.6.6V21ZM20.4 21H15v-2.9c0-.33.27-.6.6-.6h4.8c.33 0 .6.27.6.6v2.3c0 .33-.27.6-.6.6ZM9 21v-4.9c0-.33-.27-.6-.6-.6H3.6c-.33 0-.6.27-.6.6v4.3c0 .33.27.6.6.6H9ZM10.81 5.11l.9-1.92c.12-.25.46-.25.58 0l.9 1.92 2.04.31c.26.04.37.38.18.57l-1.48 1.5.35 2.12c.05.27-.23.48-.46.35L12 8.96l-1.82 1c-.23.13-.51-.08-.46-.35l.35-2.12-1.48-1.5c-.19-.19-.08-.53.18-.57l2.04-.31Z" fill="none" stroke={color} strokeWidth={1.45} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>;
}

function ProfileIcon({ active }: { active: boolean }) {
  const color = active ? '#fff' : '#637168';
  return <Svg width={21} height={21} viewBox="0 0 24 24" accessibilityLabel="Profile">
    <Circle cx="12" cy="8" r="3.4" fill="none" stroke={color} strokeWidth={1.7} />
    <Path d="M5.2 20c.4-3.2 3.1-5.3 6.8-5.3s6.4 2.1 6.8 5.3" fill="none" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
  </Svg>;
}

function DoodleArtwork() {
  return <View style={styles.doodleTile}>
    <Svg width={57} height={57} viewBox="0 0 64 64" accessibilityLabel="Blue drawing and pencil">
      <Path d="M10 38c6-14 9 12 16-1s10-12 14-2 8 2 14-8" fill="none" stroke="#4d78bd" strokeWidth={3.5} strokeLinecap="round" strokeLinejoin="round" />
      <Path d="m39 48 4-13L55 23a4 4 0 0 1 6 6L49 42l-10 6Z" fill="#74a3ed" stroke="#315f9e" strokeWidth={2} strokeLinejoin="round" />
      <Path d="m43 35 6 7M39 48l3-9" fill="none" stroke="#fff" strokeWidth={2} strokeLinecap="round" />
    </Svg>
  </View>;
}

const chessSet = [
  { type: 'k', name: 'King', color: 'w', tone: 'pearl', finish: 'Pearl finish' },
  { type: 'q', name: 'Queen', color: 'b', tone: 'onyx', finish: 'Onyx finish' },
  { type: 'r', name: 'Rook', color: 'w', tone: 'pearl', finish: 'Pearl finish' },
  { type: 'b', name: 'Bishop', color: 'b', tone: 'onyx', finish: 'Onyx finish' },
  { type: 'n', name: 'Knight', color: 'w', tone: 'pearl', finish: 'Pearl finish' },
  { type: 'p', name: 'Pawn', color: 'b', tone: 'onyx', finish: 'Onyx finish' },
] as const;

function ChessSetCarousel() {
  return <View style={styles.chessSetSection}>
    <View style={styles.chessSetHeading}>
      <View style={styles.chessSetHeadingCopy}>
        <Text style={styles.chessSetEyebrow}>THE CLASSIC SIX</Text>
        <Text style={styles.chessSetTitle}>Meet the pieces</Text>
      </View>
      <View style={styles.chessSetCount}><Text style={styles.chessSetCountText}>06 PIECES</Text></View>
    </View>
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.chessSetCarousel}
      decelerationRate="fast"
      snapToInterval={166}
      snapToAlignment="start"
      accessibilityLabel="Swipe through the six chess pieces"
    >
      {chessSet.map((piece, index) => <View key={piece.type} style={styles.chessSetCard}>
        <View style={styles.chessSetCardTop}>
          <Text style={styles.chessSetCardLabel}>CHESS PIECE</Text>
          <Text style={styles.chessSetIndex}>{String(index + 1).padStart(2, '0')}</Text>
        </View>
        <View style={styles.chessSetPieceStage}>
          <View style={styles.chessSetAura} />
          <View style={styles.chessSetPieceShadow} />
          <View style={styles.chessSetPieceArtwork}>
            <ChessPiece type={piece.type} color={piece.color} tone={piece.tone} size={88} />
          </View>
        </View>
        <View style={styles.chessSetCardFooter}>
          <Text style={styles.chessSetPieceName}>{piece.name}</Text>
          <Text style={styles.chessSetFinish}>{piece.finish}</Text>
        </View>
      </View>)}
    </ScrollView>
  </View>;
}

function formatCountdown(now: Date) {
  const seconds = Math.max(0, Math.floor((getNextDailyReset(now) - now.getTime()) / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

function StreakDashboard({ summary, now }: { summary: ActivitySummary; now: Date }) {
  return <View style={styles.streakCard}>
    <View style={styles.streakTop}>
      <View style={styles.streakFire}><FlameIcon /></View>
      <View style={styles.streakCopy}>
        <Text style={styles.streakTitle}>{summary.streakDays}-Day Streak</Text>
        <Text style={styles.streakSubtitle}>Keep the momentum going</Text>
      </View>
      <View style={styles.streakCount}><Text style={styles.streakCountText}>{summary.streakDays}</Text></View>
    </View>
    <View style={styles.weekRow} accessibilityLabel="Seven day streak progress">
      {summary.lastSevenDays.map((day) => <View key={day.key} style={styles.dayColumn}>
        <Text style={[styles.dayLabel, day.isToday && styles.todayLabel]}>{day.label}</Text>
        <View style={[styles.dayMark, day.completed && styles.dayMarkComplete, day.isToday && !day.completed && styles.dayMarkToday]}>
          <Text style={[styles.dayMarkText, day.completed && styles.dayMarkTextComplete]}>{day.completed ? '✓' : day.isToday ? '·' : ''}</Text>
        </View>
      </View>)}
    </View>
    <View style={styles.streakBottom}>
      <View style={styles.todayState}>
        {Platform.OS === 'web' ? createElement(
          'div',
          { className: 'streak-typewriter-frame', 'aria-hidden': true },
          createElement('div', { className: 'streak-typewriter-scale' },
            createElement('div', { className: 'typewriter' },
            createElement('div', { className: 'slide' }, createElement('i')),
            createElement('div', { className: 'paper' }),
            createElement('div', { className: 'keyboard' }),
            ),
          ),
        ) : <View style={summary.completedToday ? styles.statusDotComplete : styles.statusDot} accessibilityRole="progressbar" accessibilityLabel={summary.completedToday ? 'Completed today' : 'Not completed today'} />}
        <Text style={styles.todayText}>{summary.completedToday ? 'Completed today' : 'Finish one game today'}</Text>
      </View>
      <View style={styles.resetBox}>
        <Text style={styles.resetLabel}>NEXT DAILY RESET</Text>
        <Text style={styles.resetTime}>{formatCountdown(now)}</Text>
      </View>
    </View>
    <Text style={styles.resetNote}>Resets daily at 6:00 AM IST</Text>
  </View>;
}

function FloatingNav() {
  const [selected, setSelected] = useState<'home' | 'local' | 'computer' | 'leaderboard' | 'profile'>('home');

  return <View style={styles.navDock}>
    <View style={styles.navPill}>
      <Pressable onPress={() => { setSelected('home'); router.replace('/'); }} style={({ pressed }) => [styles.navItem, selected === 'home' && styles.navItemSelected, pressed && styles.navPressed]} accessibilityRole="button" accessibilityLabel="Home" accessibilityState={{ selected: selected === 'home' }}>
        <HomeIcon active={selected === 'home'} />
        <Text style={[styles.navLabel, selected === 'home' && styles.navLabelSelected]}>Home</Text>
      </Pressable>
      <Pressable onPress={() => { setSelected('local'); router.push({ pathname: '/setup', params: { mode: 'local' } }); }} style={({ pressed }) => [styles.navItem, selected === 'local' && styles.navItemSelected, pressed && styles.navPressed]} accessibilityRole="button" accessibilityLabel="1 vs 1, same device" accessibilityState={{ selected: selected === 'local' }}>
        <ChessPiece type="n" color={selected === 'local' ? 'w' : 'b'} tone={selected === 'local' ? 'pearl' : 'onyx'} size={22} />
        <Text style={[styles.navLabel, selected === 'local' && styles.navLabelSelected]}>1 vs 1</Text>
      </Pressable>
      <Pressable onPress={() => { setSelected('computer'); router.push({ pathname: '/setup', params: { mode: 'computer' } }); }} style={({ pressed }) => [styles.navItem, selected === 'computer' && styles.navItemSelected, pressed && styles.navPressed]} accessibilityRole="button" accessibilityLabel="You vs Computer" accessibilityState={{ selected: selected === 'computer' }}>
        <ChessPiece type="b" color={selected === 'computer' ? 'w' : 'b'} tone={selected === 'computer' ? 'pearl' : 'onyx'} size={22} />
        <Text style={[styles.navLabel, selected === 'computer' && styles.navLabelSelected]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.82}>You vs Computer</Text>
      </Pressable>
      <Pressable onPress={() => { setSelected('leaderboard'); router.push('/leaderboard'); }} style={({ pressed }) => [styles.navItem, selected === 'leaderboard' && styles.navItemSelected, pressed && styles.navPressed]} accessibilityRole="button" accessibilityLabel="Leaderboard" accessibilityState={{ selected: selected === 'leaderboard' }}>
        <LeaderboardIcon active={selected === 'leaderboard'} />
        <Text style={[styles.navLabel, selected === 'leaderboard' && styles.navLabelSelected]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.78}>Leaderboard</Text>
      </Pressable>
      <Pressable onPress={() => { setSelected('profile'); router.push('/profile'); }} style={({ pressed }) => [styles.navItem, selected === 'profile' && styles.navItemSelected, pressed && styles.navPressed]} accessibilityRole="button" accessibilityLabel="Profile" accessibilityState={{ selected: selected === 'profile' }}>
        <ProfileIcon active={selected === 'profile'} />
        <Text style={[styles.navLabel, selected === 'profile' && styles.navLabelSelected]}>Profile</Text>
      </Pressable>
    </View>
  </View>;
}

export default function PlayScreen() {
  const { setOnlineProfile } = useGame();
  const { user } = useAuth();
  const accountName = typeof user?.user_metadata?.display_name === 'string' ? user.user_metadata.display_name
    : typeof user?.user_metadata?.full_name === 'string' ? user.user_metadata.full_name
      : typeof user?.user_metadata?.name === 'string' ? user.user_metadata.name : '';
  const [brandReveal, setBrandReveal] = useState('');
  const [bookVaultRevealed, setBookVaultRevealed] = useState(false);
  const [summary, setSummary] = useState<ActivitySummary>(blankSummary);
  const [trophyWallet, setTrophyWallet] = useState<TrophyWallet>(emptyTrophyWallet);
  const [now, setNow] = useState(() => new Date());
  const [error, setError] = useState('');
  const trackingDay = useRef(getTrackingDayKey());

  useEffect(() => {
    const brand = 'Mystore Pvt';
    let index = 0;
    const timer = setInterval(() => {
      index += 1;
      setBrandReveal(brand.slice(0, index));
      if (index >= brand.length) clearInterval(timer);
    }, 32);
    return () => clearInterval(timer);
  }, []);

  const refreshActivity = useCallback(async () => {
    const activity = await loadPlayerActivity(user?.id);
    setSummary(activity.summary);
    const savedName = activity.name || accountName;
    if (savedName) {
      setOnlineProfile((profile) => ({ ...profile, name: savedName }));
      if (!activity.name && user?.id) await savePlayerName(savedName, user.id);
    }
  }, [accountName, setOnlineProfile, user]);

  useFocusEffect(useCallback(() => {
    let active = true;
    if (user?.id) {
      const supabase = getSupabase();
      if (supabase) void loadTrophyWallet(supabase, user.id).then((wallet) => {
        if (active) setTrophyWallet(wallet);
      }).catch(() => {
        if (active) setError('Could not load your trophy balances.');
      });
    }
    void loadPlayerActivity(user?.id).then(async (activity) => {
      if (!active) return;
      setSummary(activity.summary);
      const savedName = activity.name || accountName;
      if (savedName) {
        setOnlineProfile((profile) => ({ ...profile, name: savedName }));
        if (!activity.name && user?.id) await savePlayerName(savedName, user.id);
      }
      trackingDay.current = getTrackingDayKey();
    }).catch(() => {
      if (active) {
        setError('Could not load your saved profile.');
      }
    });
    return () => { active = false; };
  }, [accountName, setOnlineProfile, user]));

  useEffect(() => {
    const timer = setInterval(() => {
      const current = new Date();
      setNow(current);
      const currentTrackingDay = getTrackingDayKey(current);
      if (currentTrackingDay !== trackingDay.current) {
        trackingDay.current = currentTrackingDay;
        void refreshActivity().catch(() => setError('Could not refresh your daily streak.'));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [refreshActivity]);

  async function openBookVault() {
    try {
      await Linking.openURL('https://book-vault-pdf.netlify.app/');
    } catch {
      setError('Could not open Book Vault. Please try again.');
    }
  }

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <StatusBar style="dark" animated />
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View style={styles.avatar}><Image source={require('@/assets/images/classic-chess-knight.png')} style={styles.headerKnight} resizeMode="cover" accessibilityLabel="Classic Chess knight logo" /></View>
        <View style={styles.headerCopy}>
          <Text style={styles.brandReveal}>{brandReveal}</Text>
          <Text style={styles.greeting}>Classic Chess</Text>
        </View>
        <Pressable onPress={() => router.push('/trophy')} style={styles.trophyHeaderButton} accessibilityRole="button" accessibilityLabel={`Trophies: ${trophyWallet.silver} silver and ${trophyWallet.gold} gold`}>
          <TrophyIcon metal="gold" label="Trophy wallet" size={43} showBackdrop={false} idPrefix="play-header" />
          <View style={styles.trophyHeaderCounts}><Text style={styles.trophyHeaderSilver}>SILVER <Text style={styles.trophyHeaderValue}>{trophyWallet.silver}</Text></Text><Text style={styles.trophyHeaderGold}>GOLD <Text style={styles.trophyHeaderValue}>{trophyWallet.gold}</Text></Text></View>
        </Pressable>
      </View>

      {error ? <Text style={styles.inlineError}>{error}</Text> : null}
      <StreakDashboard summary={summary} now={now} />

      <RevealCard delay={0} style={styles.onlineSection}>
        <Text style={styles.sectionTitle}>Online Multiplayer</Text>
        <Text style={styles.sectionSubtitle}>Challenge a friend. Or draw something unexpected.</Text>
      </RevealCard>

      <View style={styles.gameCardsRow}>
        <RevealCard delay={45} style={styles.onlineCardWrap}>
          <Pressable onPress={() => router.push('/online')} style={({ pressed }) => [styles.inviteCard, pressed && styles.invitePressed]} accessibilityRole="button" accessibilityLabel="Online chess. Invite a friend by WhatsApp.">
            <View style={styles.gameCardTopRow}><View style={styles.gameCardArtwork}><ChessPiece type="n" color="b" tone="pearl" size={52} /></View><View style={styles.betaChess}><Text style={styles.betaChessText}>BETA V2</Text></View></View>
            <Text style={styles.inviteKicker}>ONLINE CHESS</Text>
            <Text style={styles.inviteTitle}>Invite a friend</Text>
            <Text style={styles.inviteSubtitle}>Play together with a private link.</Text>
            <View style={styles.inviteArrow}><Text style={styles.inviteArrowText}>Open chess  ↗</Text></View>
          </Pressable>
        </RevealCard>

        <RevealCard delay={80} style={styles.scribbleCard}>
          <Pressable onPress={() => { markScribbleTransition(); router.push('/scribble'); }} style={({ pressed }) => [styles.scribbleOpen, pressed && styles.invitePressed]} accessibilityRole="button" accessibilityLabel="Open Scribble">
            <View style={styles.gameCardTopRow}><View style={styles.scribbleArtwork}><DoodleArtwork /></View><View style={styles.betaScribble}><Text style={styles.betaScribbleText}>BETA V1</Text></View></View>
            <Text style={styles.scribbleKicker}>DRAW & GUESS</Text>
            <Text style={styles.scribbleTitle}>Scribble</Text>
            <Text style={styles.scribbleSubtitle}>Draw a word. Let friends guess.</Text>
            <View style={styles.scribbleOpenButton}><Text style={styles.scribbleOpenText}>Open Scribble  ↗</Text></View>
          </Pressable>
        </RevealCard>
      </View>
      <ChessSetCarousel />
      <RevealCard style={styles.bookVaultCard}>
        <Pressable
          onPress={() => setBookVaultRevealed((revealed) => !revealed)}
          style={({ pressed }) => [styles.bookVaultHeader, pressed && styles.invitePressed]}
          accessibilityRole="button"
          accessibilityLabel="Reveal The Book Vault card details"
          accessibilityState={{ expanded: bookVaultRevealed }}
        >
          <Image source={require('@/assets/images/book-vault-banner.jpg')} style={styles.bookVaultLogo} resizeMode="contain" accessibilityLabel="The Book Vault logo" />
          <View style={styles.bookVaultCopy}>
            <Text style={styles.bookVaultEyebrow}>STUDY SMARTER</Text>
            <Text style={styles.bookVaultTitle}>The Book Vault</Text>
            <Text style={styles.bookVaultRevealHint}>{bookVaultRevealed ? 'Tap to close' : 'Tap to reveal'}</Text>
          </View>
          <View style={styles.bookVaultToggle}><Text style={styles.bookVaultToggleText}>{bookVaultRevealed ? '−' : '+'}</Text></View>
        </Pressable>
        {bookVaultRevealed && <RevealCard style={styles.bookVaultDetails}>
          <Text style={styles.bookVaultSubtitle}>A library of learning resources, ready when you are.</Text>
          <Pressable onPress={() => void openBookVault()} style={({ pressed }) => [styles.bookVaultButton, pressed && styles.invitePressed]} accessibilityRole="link" accessibilityLabel="Visit The Book Vault website">
            <Text style={styles.bookVaultButtonText}>Visit site ↗</Text>
          </Pressable>
        </RevealCard>}
      </RevealCard>
      <View style={styles.remainingSpace} />
    </ScrollView>

    <FloatingNav />

  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: canvas },
  content: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 18, paddingBottom: 122 },
  header: { minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 19 },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#090a09', borderWidth: 1, borderColor: '#090a09', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  headerKnight: { width: '100%', height: '100%' },
  headerCopy: { flex: 1, minWidth: 0 },
  brandReveal: { minHeight: 12, color: '#748078', fontSize: 8, letterSpacing: 1.8, fontWeight: '900', textTransform: 'uppercase' },
  greeting: { color: dark, fontSize: 20, fontWeight: '900', letterSpacing: -0.7, marginTop: 4 },
  trophyHeaderButton: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 1 },
  trophyHeaderCounts: { alignItems: 'flex-start', gap: 3 },
  trophyHeaderSilver: { color: '#74818a', fontSize: 8, lineHeight: 11, fontWeight: '900', letterSpacing: 0.35 },
  trophyHeaderGold: { color: '#9a762d', fontSize: 8, lineHeight: 11, fontWeight: '900', letterSpacing: 0.35 },
  trophyHeaderValue: { color: dark, fontWeight: '900' },
  inlineError: { color: '#a33b32', fontSize: 12, marginBottom: 9 },
  streakCard: { borderRadius: 24, borderWidth: 1, borderColor: '#dce5de', backgroundColor: '#fff', paddingHorizontal: 17, paddingTop: 16, paddingBottom: 13, shadowColor: '#496354', shadowOpacity: 0.06, shadowRadius: 15, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  onlineSection: { backgroundColor: 'transparent', borderColor: 'transparent', borderWidth: 0, paddingHorizontal: 1, marginTop: 20, marginBottom: 11 },
  sectionTitle: { color: dark, fontSize: 19, fontWeight: '800', letterSpacing: -0.4 },
  sectionSubtitle: { color: '#79847d', fontSize: 11, marginTop: 4 },
  gameCardsRow: { flexDirection: 'row', alignItems: 'stretch', gap: 12 },
  gameCardTopRow: { width: '100%', flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  betaChess: { minHeight: 22, borderRadius: 12, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 9 },
  betaChessText: { color: green, fontSize: 8, fontWeight: '900', letterSpacing: 0.7 },
  betaScribble: { minHeight: 22, borderRadius: 12, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 9 },
  betaScribbleText: { color: '#4775b7', fontSize: 8, fontWeight: '900', letterSpacing: 0.7 },
  chessSetSection: { marginTop: 24 },
  chessSetHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 13, paddingHorizontal: 1 },
  chessSetHeadingCopy: { gap: 3 },
  chessSetEyebrow: { color: green, fontSize: 8, fontWeight: '900', letterSpacing: 1.8 },
  chessSetTitle: { color: dark, fontSize: 20, fontWeight: '800', letterSpacing: -0.6 },
  chessSetCount: { height: 27, borderRadius: 14, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: '#262b28' },
  chessSetCountText: { color: '#fff', fontSize: 8, fontWeight: '900', letterSpacing: 1 },
  chessSetCarousel: { gap: 10, paddingHorizontal: 1, paddingBottom: 6 },
  chessSetCard: { width: 156, height: 188, overflow: 'hidden', borderRadius: 25, borderWidth: 1, borderColor: '#e2e8e3', backgroundColor: '#fff', paddingHorizontal: 12, paddingTop: 11, paddingBottom: 12, shadowColor: '#344c3d', shadowOpacity: 0.07, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  chessSetCardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  chessSetCardLabel: { color: '#89958d', fontSize: 7, fontWeight: '900', letterSpacing: 1.1 },
  chessSetIndex: { color: green, fontSize: 9, fontWeight: '800', fontVariant: ['tabular-nums'] },
  chessSetPieceStage: { height: 112, alignItems: 'center', justifyContent: 'center', marginTop: 2, position: 'relative' },
  chessSetAura: { position: 'absolute', zIndex: 0, width: 94, height: 94, borderRadius: 47, backgroundColor: '#f0f4f0', borderWidth: 1, borderColor: '#e9eeea' },
  chessSetPieceShadow: { position: 'absolute', zIndex: 1, bottom: 8, width: 62, height: 13, borderRadius: 8, backgroundColor: 'rgba(42,54,46,.09)' },
  chessSetPieceArtwork: { zIndex: 2, alignItems: 'center', justifyContent: 'center' },
  chessSetCardFooter: { borderTopWidth: 1, borderTopColor: '#eef1ee', paddingTop: 8 },
  chessSetPieceName: { color: dark, fontSize: 13, fontWeight: '800', letterSpacing: -0.15 },
  chessSetFinish: { color: '#8a948d', fontSize: 9, fontWeight: '600', marginTop: 2 },
  onlineCardWrap: { flex: 1, minWidth: 0, borderWidth: 0, borderColor: 'transparent', backgroundColor: 'transparent', marginBottom: 0 },
  streakTop: { minHeight: 54, flexDirection: 'row', alignItems: 'center', gap: 11 },
  streakFire: { width: 46, height: 46, borderRadius: 16, backgroundColor: '#fff4ed', alignItems: 'center', justifyContent: 'center', shadowColor: '#e97945', shadowOpacity: 0.18, shadowRadius: 9, shadowOffset: { width: 0, height: 2 } },
  streakCopy: { flex: 1 },
  streakTitle: { color: dark, fontSize: 18, fontWeight: '800', letterSpacing: -0.35 },
  streakSubtitle: { color: '#7a857e', fontSize: 11, marginTop: 3 },
  streakCount: { minWidth: 42, height: 42, borderRadius: 15, backgroundColor: '#262b28', alignItems: 'center', justifyContent: 'center' },
  streakCountText: { color: '#fff', fontSize: 17, fontWeight: '800' },
  weekRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 16, marginBottom: 13 },
  dayColumn: { alignItems: 'center', gap: 6, width: 31 },
  dayLabel: { color: '#909a93', fontSize: 9, fontWeight: '700' },
  todayLabel: { color: green },
  dayMark: { width: 27, height: 27, borderRadius: 14, borderWidth: 1, borderColor: '#e3e9e4', backgroundColor: '#f8faf8', alignItems: 'center', justifyContent: 'center' },
  dayMarkComplete: { backgroundColor: '#262b28', borderColor: '#262b28' },
  dayMarkToday: { borderColor: green, borderWidth: 1.5 },
  dayMarkText: { color: '#9da69f', fontSize: 13, fontWeight: '700', lineHeight: 17 },
  dayMarkTextComplete: { color: '#fff' },
  streakBottom: { minHeight: 42, borderTopWidth: 1, borderTopColor: '#edf1ee', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingTop: 10 },
  todayState: { flexDirection: 'row', alignItems: 'center', gap: 7, flexShrink: 1 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#d1d8d2' },
  statusDotComplete: { width: 7, height: 7, borderRadius: 4, backgroundColor: green },
  todayText: { color: '#4f5e55', fontSize: 11, fontWeight: '600' },
  resetBox: { alignItems: 'flex-end' },
  resetLabel: { color: '#89948c', fontSize: 7, letterSpacing: 1.15, fontWeight: '800' },
  resetTime: { color: dark, fontSize: 12, fontWeight: '800', letterSpacing: 0.6, marginTop: 2, fontVariant: ['tabular-nums'] },
  resetNote: { color: '#9aa39d', fontSize: 9, marginTop: 4 },
  inviteCard: { width: '100%', minHeight: 235, height: '100%', borderRadius: 28, backgroundColor: green, paddingHorizontal: 15, paddingVertical: 16, alignItems: 'flex-start', overflow: 'hidden', shadowColor: '#426b5d', shadowOpacity: 0.18, shadowRadius: 16, shadowOffset: { width: 0, height: 7 }, elevation: 4 },
  invitePressed: { opacity: 0.86, transform: [{ scale: 0.99 }] },
  gameCardArtwork: { width: 58, height: 58, borderRadius: 20, backgroundColor: '#f7f8f5', borderWidth: 1, borderColor: 'rgba(255,255,255,.8)', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  inviteKicker: { color: '#e1eee7', fontSize: 9, fontWeight: '800', letterSpacing: 2.1 },
  inviteTitle: { color: '#fff', fontSize: 18, lineHeight: 22, fontWeight: '800', letterSpacing: -0.35, marginTop: 6 },
  inviteSubtitle: { color: '#e0ebe5', fontSize: 11, lineHeight: 15, marginTop: 6 },
  inviteArrow: { alignSelf: 'flex-start', minHeight: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,.17)', justifyContent: 'center', paddingHorizontal: 12, marginTop: 'auto' },
  inviteArrowText: { color: '#fff', fontSize: 10, fontWeight: '800', letterSpacing: 0.2 },
  scribbleCard: { flex: 1, minWidth: 0, minHeight: 235, height: '100%', borderRadius: 28, borderWidth: 1, borderColor: '#d4e2f4', backgroundColor: '#4775b7', padding: 0, marginTop: 0, shadowColor: '#345b91', shadowOpacity: 0.12, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  scribbleOpen: { flex: 1, minHeight: 235, paddingHorizontal: 15, paddingVertical: 16, alignItems: 'flex-start' },
  scribbleKicker: { color: '#e7f0ff', fontSize: 8, fontWeight: '800', letterSpacing: 1.8 },
  scribbleTitle: { color: '#fff', fontSize: 18, lineHeight: 22, fontWeight: '800', letterSpacing: -0.4, marginTop: 6 },
  scribbleSubtitle: { color: '#f0f5ff', fontSize: 11, lineHeight: 15, marginTop: 6 },
  scribbleArtwork: { width: 58, height: 58, borderRadius: 20, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#e8eff8', marginBottom: 16, overflow: 'hidden' },
  bookVaultCard: { width: '100%', marginTop: 18, padding: 14, borderRadius: 24, borderWidth: 1, borderColor: '#dce6dd', backgroundColor: '#fff', shadowColor: '#344c3d', shadowOpacity: 0.07, shadowRadius: 13, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  bookVaultHeader: { minHeight: 94, flexDirection: 'row', alignItems: 'center', gap: 14 },
  bookVaultLogo: { width: 76, height: 76, borderRadius: 20, backgroundColor: '#f8f8ef' },
  bookVaultCopy: { flex: 1, alignItems: 'flex-start' },
  bookVaultEyebrow: { color: green, fontSize: 8, fontWeight: '900', letterSpacing: 1.5 },
  bookVaultTitle: { color: dark, fontSize: 17, fontWeight: '900', letterSpacing: -0.35, marginTop: 4 },
  bookVaultRevealHint: { color: green, fontSize: 9, fontWeight: '700', marginTop: 5 },
  bookVaultToggle: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: '#262b28' },
  bookVaultToggleText: { color: '#fff', fontSize: 20, lineHeight: 23, fontWeight: '600' },
  bookVaultDetails: { marginTop: 12, padding: 12, borderRadius: 16, backgroundColor: '#f7faf7', borderColor: '#e6eee7' },
  bookVaultSubtitle: { color: '#707d74', fontSize: 10, lineHeight: 14, marginTop: 4 },
  bookVaultButton: { minHeight: 32, borderRadius: 16, backgroundColor: green, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 13, marginTop: 10 },
  bookVaultButtonText: { color: '#fff', fontSize: 9, fontWeight: '900', letterSpacing: 0.4 },
  doodleTile: { width: 46, height: 46, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  scribbleOpenButton: { minHeight: 34, borderRadius: 17, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12, marginTop: 'auto' },
  scribbleOpenText: { color: '#2f568d', fontSize: 10, fontWeight: '800' },
  remainingSpace: { flex: 1, minHeight: 30 },
  navDock: { position: 'absolute', left: 0, right: 0, bottom: 8, alignItems: 'center', paddingHorizontal: 12 },
  navPill: { width: '100%', maxWidth: 470, minHeight: 72, borderRadius: 38, borderWidth: 1, borderColor: '#e2e8e3', backgroundColor: 'rgba(255,255,255,.97)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 7, shadowColor: '#344c3d', shadowOpacity: 0.14, shadowRadius: 18, shadowOffset: { width: 0, height: 7 }, elevation: 8 },
  navItem: { flex: 1, height: 58, borderRadius: 30, alignItems: 'center', justifyContent: 'center', gap: 2, paddingHorizontal: 2 },
  navItemSelected: { backgroundColor: '#262b28' },
  navPressed: { opacity: 0.68, transform: [{ scale: 0.96 }] },
  navLabel: { color: '#68766d', fontSize: 8, fontWeight: '700' },
  navLabelSelected: { color: '#fff' },
});
