import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, type Session, type SupabaseClient } from '@supabase/supabase-js';
import { Platform } from 'react-native';

let client: SupabaseClient | null = null;
export function getSupabase(): SupabaseClient | null {
  const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.trim();
  const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY?.trim();
  if (!url || !key) return null;

  if (!client) {
    const storage = Platform.OS === 'web'
      ? (typeof localStorage === 'undefined' ? undefined : localStorage)
      : AsyncStorage;
    client = createClient(url, key, {
      auth: {
        storage,
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
        flowType: 'pkce',
      },
    });
  }

  return client;
}

export async function ensureAuthenticatedSession(supabase: SupabaseClient): Promise<Session> {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw new Error(error.message || 'Could not restore your account session. Check your connection and try again.');
  if (!data.session) throw new Error('Sign in with Google or your verified email before opening a room.');

  const verified = await supabase.auth.getUser();
  if (verified.error || !verified.data.user) throw new Error('Your session could not be verified. Please sign in again.');
  if (verified.data.user.is_anonymous || !verified.data.user.email_confirmed_at) {
    throw new Error('Verify your email or sign in with Google before opening a room.');
  }
  return data.session;
}
