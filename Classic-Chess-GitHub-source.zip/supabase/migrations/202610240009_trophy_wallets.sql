create table public.trophy_wallets (
  user_id uuid primary key references auth.users (id) on delete cascade,
  silver integer not null default 0 check (silver >= 0),
  gold integer not null default 0 check (gold >= 0),
  updated_at timestamptz not null default now()
);

create table public.trophy_transactions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  currency text not null check (currency in ('silver', 'gold')),
  amount integer not null check (amount <> 0),
  source text not null check (source in ('computer_chess', 'multiplayer_chess', 'conversion')),
  source_id uuid not null,
  created_at timestamptz not null default now(),
  unique (user_id, currency, source, source_id)
);

create table public.trophy_ai_matches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  player_color text not null check (player_color in ('w', 'b')),
  status text not null default 'active' check (status in ('active', 'settled')),
  result text check (result in ('win', 'loss', 'draw')),
  started_at timestamptz not null default now(),
  settled_at timestamptz
);

create table public.trophy_chess_awards (
  room_id uuid primary key references public.chess_rooms (id) on delete cascade,
  winner_id uuid not null references auth.users (id) on delete cascade,
  awarded_at timestamptz not null default now()
);

alter table public.trophy_wallets enable row level security;
alter table public.trophy_transactions enable row level security;
alter table public.trophy_ai_matches enable row level security;
alter table public.trophy_chess_awards enable row level security;

revoke all on public.trophy_wallets, public.trophy_transactions, public.trophy_ai_matches, public.trophy_chess_awards from anon, authenticated;
grant all on public.trophy_wallets, public.trophy_transactions, public.trophy_ai_matches, public.trophy_chess_awards to service_role;
grant usage, select on sequence public.trophy_transactions_id_seq to service_role;
grant select on public.trophy_wallets to authenticated;
grant select on public.trophy_transactions to authenticated;

create policy "Players read their own trophy wallet" on public.trophy_wallets
  for select to authenticated using (user_id = (select auth.uid()));
create policy "Players read their own trophy history" on public.trophy_transactions
  for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.seed_trophy_wallet()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.trophy_wallets (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists seed_new_player_trophy_wallet on auth.users;
create trigger seed_new_player_trophy_wallet after insert on auth.users
  for each row execute function public.seed_trophy_wallet();

insert into public.trophy_wallets (user_id)
select id from auth.users on conflict (user_id) do nothing;

create or replace function public.convert_silver_trophies(p_silver_amount integer)
returns table(silver integer, gold integer)
language plpgsql security definer set search_path = '' as $$
declare
  player_id uuid := (select auth.uid());
  conversion_id uuid := gen_random_uuid();
  wallet public.trophy_wallets%rowtype;
begin
  if player_id is null then raise exception 'Sign in to convert trophies.' using errcode = '28000'; end if;
  if p_silver_amount is null or p_silver_amount < 100 or mod(p_silver_amount, 100) <> 0 then
    raise exception 'Convert silver in multiples of 100.' using errcode = '22023';
  end if;

  insert into public.trophy_wallets (user_id) values (player_id) on conflict (user_id) do nothing;
  update public.trophy_wallets as wallet_row
    set silver = wallet_row.silver - p_silver_amount,
        gold = wallet_row.gold + (p_silver_amount / 2),
        updated_at = now()
    where wallet_row.user_id = player_id and wallet_row.silver >= p_silver_amount
    returning wallet_row.* into wallet;
  if not found then raise exception 'You do not have enough silver trophies.' using errcode = 'P0001'; end if;

  insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
    values (player_id, 'silver', -p_silver_amount, 'conversion', conversion_id),
           (player_id, 'gold', p_silver_amount / 2, 'conversion', conversion_id);
  return query select wallet.silver, wallet.gold;
end $$;

create or replace function public.start_trophy_ai_match(p_player_color text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  player_id uuid := (select auth.uid());
  match_id uuid;
begin
  if player_id is null then raise exception 'Sign in to play for trophies.' using errcode = '28000'; end if;
  if p_player_color not in ('w', 'b') then raise exception 'Choose a valid player color.' using errcode = '22023'; end if;
  insert into public.trophy_wallets (user_id) values (player_id) on conflict (user_id) do nothing;
  insert into public.trophy_ai_matches (user_id, player_color) values (player_id, p_player_color) returning id into match_id;
  return match_id;
end $$;

create or replace function public.settle_trophy_ai_match(p_match_id uuid, p_result text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  match_row public.trophy_ai_matches%rowtype;
  wallet public.trophy_wallets%rowtype;
  award integer := 0;
begin
  if p_result not in ('win', 'loss', 'draw') then raise exception 'Invalid match result.' using errcode = '22023'; end if;
  select * into match_row from public.trophy_ai_matches where id = p_match_id for update;
  if not found then raise exception 'Trophy match was not found.' using errcode = 'P0002'; end if;
  if match_row.status = 'settled' then
    select * into wallet from public.trophy_wallets where user_id = match_row.user_id;
    return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'alreadySettled', true);
  end if;
  if match_row.started_at < now() - interval '12 hours' then raise exception 'This trophy match has expired.' using errcode = 'P0001'; end if;

  insert into public.trophy_wallets (user_id) values (match_row.user_id) on conflict (user_id) do nothing;
  select * into wallet from public.trophy_wallets where user_id = match_row.user_id for update;
  if p_result = 'win' then award := 200;
  elsif p_result = 'loss' and wallet.silver >= 200 then award := -20;
  end if;

  update public.trophy_wallets
    set silver = silver + award, updated_at = now()
    where user_id = match_row.user_id returning * into wallet;
  update public.trophy_ai_matches set status = 'settled', result = p_result, settled_at = now() where id = p_match_id;
  if award <> 0 then
    insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
      values (match_row.user_id, 'silver', award, 'computer_chess', p_match_id);
  end if;
  return jsonb_build_object('silver', wallet.silver, 'gold', wallet.gold, 'awardedSilver', award, 'alreadySettled', false);
end $$;

alter table public.chess_rooms add column if not exists winner_id uuid references auth.users (id) on delete set null;

create or replace function public.award_finished_chess_trophies()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status <> 'finished' or old.status = 'finished' or new.winner_id is null then return new; end if;
  if new.winner_id <> new.host_id and new.winner_id is distinct from new.guest_id then
    raise exception 'Chess winner must be a player in this room.' using errcode = '22023';
  end if;
  insert into public.trophy_wallets (user_id) values (new.winner_id) on conflict (user_id) do nothing;
  insert into public.trophy_chess_awards (room_id, winner_id) values (new.id, new.winner_id)
    on conflict (room_id) do nothing;
  if not found then return new; end if;
  update public.trophy_wallets set gold = gold + 500, updated_at = now() where user_id = new.winner_id;
  insert into public.trophy_transactions (user_id, currency, amount, source, source_id)
    values (new.winner_id, 'gold', 500, 'multiplayer_chess', new.id);
  return new;
end $$;

drop trigger if exists chess_room_trophy_award on public.chess_rooms;
create trigger chess_room_trophy_award after update of status, winner_id on public.chess_rooms
  for each row execute function public.award_finished_chess_trophies();

drop function if exists public.append_chess_move(uuid, uuid, integer, text, boolean);
create function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean,
  p_winner_id uuid
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room from public.chess_rooms where id = p_room_id for update;
  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;
  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;
  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;
  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;
  if (p_finished and p_winner_id is not null and p_winner_id <> p_player_id)
     or (not p_finished and p_winner_id is not null) then
    raise exception 'The reported chess winner is invalid.' using errcode = '22023';
  end if;

  update public.chess_rooms
    set moves = array_append(moves, p_san), ply = ply + 1,
        status = case when p_finished then 'finished' else 'active' end,
        winner_id = case when p_finished then p_winner_id else null end,
        updated_at = now()
    where id = p_room_id and ply = p_expected_ply
    returning * into updated_room;
  if not found then raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001'; end if;
  return to_jsonb(updated_room);
end $$;

create or replace function public.get_trophy_leaderboard()
returns table(rank_position bigint, user_id uuid, username text, display_name text, silver integer, gold integer)
language sql stable security definer set search_path = '' as $$
  select row_number() over (order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc),
         wallet.user_id, profile.username, profile.display_name, wallet.silver, wallet.gold
  from public.trophy_wallets as wallet
  join public.player_profiles as profile on profile.user_id = wallet.user_id
  where profile.username is not null and btrim(profile.username) <> ''
  order by wallet.gold desc, wallet.silver desc, lower(profile.username) asc
  limit 100;
$$;

revoke all on function public.seed_trophy_wallet(), public.award_finished_chess_trophies() from public, anon, authenticated;
revoke all on function public.convert_silver_trophies(integer), public.start_trophy_ai_match(text), public.settle_trophy_ai_match(uuid, text), public.get_trophy_leaderboard() from public, anon;
grant execute on function public.convert_silver_trophies(integer), public.start_trophy_ai_match(text), public.get_trophy_leaderboard() to authenticated;
grant execute on function public.settle_trophy_ai_match(uuid, text) to service_role;
revoke all on function public.append_chess_move(uuid, uuid, integer, text, boolean, uuid) from public, anon, authenticated;
grant execute on function public.append_chess_move(uuid, uuid, integer, text, boolean, uuid) to service_role;
