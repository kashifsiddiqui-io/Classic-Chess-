create or replace function public.scribble_create_room(p_user_id uuid, p_name text, p_code text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype;
begin
  if p_user_id is null or char_length(btrim(p_name)) not between 1 and 24 or p_name ~ '[[:cntrl:]]'
     or p_code !~ '^[A-HJ-NP-Z2-9]{8}$' then raise exception 'Invalid player name or invite code.' using errcode = '22023'; end if;
  insert into public.player_profiles (user_id, display_name) values (p_user_id, btrim(p_name))
    on conflict (user_id) do update set display_name = excluded.display_name, updated_at = now();
  insert into public.scribble_rooms (invite_code, host_id) values (p_code, p_user_id) returning * into room;
  insert into public.scribble_members (room_id, user_id, display_name, seat, status, is_host)
    values (room.id, p_user_id, btrim(p_name), 1, 'active', true);
  return to_jsonb(room);
end $$;

create or replace function public.scribble_join_room(p_code text, p_user_id uuid, p_name text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; member public.scribble_members%rowtype; seats integer; occupied integer;
begin
  if p_user_id is null or p_name is null or char_length(btrim(p_name)) not between 1 and 24 or p_name ~ '[[:cntrl:]]' then
    raise exception 'Enter a valid display name before joining.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where invite_code = upper(btrim(p_code)) for update;
  if not found then raise exception 'This Scribble room was not found.' using errcode = 'P0002'; end if;
  if room.status = 'waiting' and room.invite_expires_at <= clock_timestamp() then
    update public.scribble_rooms set status = 'closed', phase = 'results', state_version = state_version + 1 where id = room.id;
    raise exception 'This invite has expired. Ask for a new room link.' using errcode = 'P0001'; end if;
  if room.status in ('results', 'closed') then raise exception 'This Scribble room has ended.' using errcode = 'P0001'; end if;
  insert into public.player_profiles (user_id, display_name) values (p_user_id, btrim(p_name))
    on conflict (user_id) do update set display_name = excluded.display_name, updated_at = now();
  select * into member from public.scribble_members where room_id = room.id and user_id = p_user_id for update;
  if found and member.status in ('active', 'waiting') then
    update public.scribble_members set display_name = btrim(p_name), last_seen_at = now()
      where room_id = room.id and user_id = p_user_id returning * into member;
  else
    select count(*) into occupied from public.scribble_members where room_id = room.id and status in ('active', 'waiting');
    if occupied >= room.max_players then raise exception 'This Scribble room is full.' using errcode = 'P0001'; end if;
    if room.status = 'waiting' then
      select coalesce(max(seat), 0) + 1 into seats from public.scribble_members where room_id = room.id and seat is not null;
      insert into public.scribble_members (room_id, user_id, display_name, seat, status)
        values (room.id, p_user_id, btrim(p_name), seats, 'active')
      on conflict (room_id, user_id) do update set display_name = excluded.display_name, seat = excluded.seat, status = 'active', left_at = null, last_seen_at = now()
      returning * into member;
    else
      insert into public.scribble_members (room_id, user_id, display_name, status)
        values (room.id, p_user_id, btrim(p_name), 'waiting')
      on conflict (room_id, user_id) do update set display_name = excluded.display_name, status = 'waiting', left_at = null, last_seen_at = now()
      returning * into member;
    end if;
  end if;
  update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = room.id returning * into room;
  return jsonb_build_object('room', to_jsonb(room), 'member', to_jsonb(member));
end $$;

create or replace function public.scribble_make_turn(p_room uuid, p_number integer, p_cycle smallint, p_drawer uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare options text[]; result_id uuid;
begin
  select array_agg(word order by random()) into options from
    (select word from public.scribble_word_bank where enabled order by random() limit 3) words;
  if cardinality(options) <> 3 then raise exception 'At least three Scribble words must be enabled.' using errcode = 'P0001'; end if;
  insert into public.scribble_turns (room_id, turn_number, cycle_number, drawer_id, choices)
    values (p_room, p_number, p_cycle, p_drawer, options) returning id into result_id;
  return result_id;
end $$;

create or replace function public.scribble_start_room(p_room_id uuid, p_user_id uuid, p_cycles smallint default 3)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; roster uuid[]; turn_id uuid;
begin
  if p_cycles not between 1 and 5 then raise exception 'Cycles must be between one and five.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'waiting' or room.invite_expires_at <= clock_timestamp() then raise exception 'This room can no longer start.' using errcode = 'P0001'; end if;
  if room.host_id <> p_user_id then raise exception 'Only the host can start the game.' using errcode = '42501'; end if;
  select array_agg(user_id order by gen_random_uuid()) into roster from public.scribble_members where room_id = p_room_id and status = 'active';
  if cardinality(roster) < 2 then raise exception 'At least two players are needed to start.' using errcode = 'P0001'; end if;
  turn_id := public.scribble_make_turn(p_room_id, 1, 1::smallint, roster[1]);
  update public.scribble_rooms set status = 'active', phase = 'choosing', cycles = p_cycles,
    turn_number = 1, cycle_number = 1, turn_order = roster, drawn_this_cycle = '{}', current_drawer_id = roster[1],
    current_turn_id = turn_id, phase_deadline = now() + make_interval(secs => choose_seconds),
    invite_expires_at = null, started_at = now(), state_version = state_version + 1, updated_at = now()
    where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;

create or replace function public.scribble_choose_word(p_room_id uuid, p_user_id uuid, p_word text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'choosing' or room.phase_deadline <= clock_timestamp() then raise exception 'The word choice window has ended.' using errcode = 'P0001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the drawer can choose a word.' using errcode = '42501'; end if;
  select * into turn from public.scribble_turns where id = room.current_turn_id for update;
  if not (btrim(p_word) = any(turn.choices)) then raise exception 'Choose one of the words provided.' using errcode = '22023'; end if;
  update public.scribble_turns set answer = btrim(p_word) where id = turn.id;
  update public.scribble_rooms set phase = 'drawing', phase_deadline = now() + make_interval(secs => draw_seconds),
    drawer_grace_deadline = null,
    canvas_revision = 0, public_state = jsonb_build_object('masked', regexp_replace(btrim(p_word), '[A-Za-z]', '_', 'g')),
    state_version = state_version + 1, updated_at = now()
    where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;

create or replace function public.scribble_guess(p_room_id uuid, p_user_id uuid, p_guess text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; player_name text;
  points integer; eligible integer; solved_count integer; inserted boolean; correct_answer text;
begin
  if p_guess is null or char_length(btrim(p_guess)) not between 1 and 80 or p_guess ~ '[[:cntrl:]]' then raise exception 'A guess must contain one to eighty characters.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_drawer_id = p_user_id then raise exception 'The drawer cannot guess.' using errcode = '42501'; end if;
  select display_name into player_name from public.scribble_members where room_id = p_room_id and user_id = p_user_id and status = 'active';
  if not found then raise exception 'Join this room before guessing.' using errcode = '42501'; end if;
  if (select count(*) from public.scribble_events where room_id = p_room_id and actor_id = p_user_id and event_type = 'guess' and created_at > now() - interval '10 seconds') >= 6 then
    raise exception 'Slow down before sending another guess.' using errcode = 'P0001'; end if;
  select * into turn from public.scribble_turns where id = room.current_turn_id for update;
  if exists (select 1 from public.scribble_solved where turn_id = turn.id and user_id = p_user_id) then return jsonb_build_object('correct', true, 'alreadySolved', true, 'points', 0); end if;
  correct_answer := lower(regexp_replace(btrim(turn.answer), '\s+', ' ', 'g'));
  if lower(regexp_replace(btrim(p_guess), '\s+', ' ', 'g')) <> correct_answer then
    insert into public.scribble_events (room_id, turn_id, actor_id, event_type, body) values
      (p_room_id, turn.id, p_user_id, 'guess', jsonb_build_object('name', player_name, 'text', btrim(p_guess)));
    update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id;
    return jsonb_build_object('correct', false, 'alreadySolved', false, 'points', 0);
  end if;
  points := 100 + greatest(0, least(100, round(100 * greatest(0, extract(epoch from (room.phase_deadline - clock_timestamp())) / room.draw_seconds)::numeric)::integer));
  insert into public.scribble_solved (room_id, turn_id, user_id, points) values (p_room_id, turn.id, p_user_id, points)
    on conflict (turn_id, user_id) do nothing returning true into inserted;
  if not coalesce(inserted, false) then return jsonb_build_object('correct', true, 'alreadySolved', true, 'points', 0); end if;
  insert into public.scribble_score_events (room_id, turn_id, recipient_id, source_user_id, event_type, points)
    values (p_room_id, turn.id, p_user_id, p_user_id, 'correct_guess', points),
           (p_room_id, turn.id, room.current_drawer_id, p_user_id, 'drawer_bonus', 25);
  update public.scribble_members set score = score + points where room_id = p_room_id and user_id = p_user_id;
  update public.scribble_members set score = score + 25 where room_id = p_room_id and user_id = room.current_drawer_id;
  insert into public.scribble_events (room_id, turn_id, actor_id, event_type, body)
    values (p_room_id, turn.id, p_user_id, 'correct', jsonb_build_object('name', player_name, 'text', player_name || ' guessed the word!', 'points', points));
  select count(*) into eligible from public.scribble_members where room_id = p_room_id and status = 'active' and user_id <> room.current_drawer_id;
  select count(*) into solved_count from public.scribble_solved where turn_id = turn.id;
  if eligible > 0 and solved_count >= eligible then
    update public.scribble_turns set ended_at = now() where id = turn.id;
    update public.scribble_rooms set phase = 'reveal', phase_deadline = now() + make_interval(secs => reveal_seconds),
      public_state = jsonb_build_object('answer', turn.answer, 'reason', 'all_solved'), state_version = state_version + 1, updated_at = now()
      where id = p_room_id;
    insert into public.scribble_events (room_id, turn_id, event_type, body) values
      (p_room_id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'Everyone found the word.'));
  else update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id; end if;
  return jsonb_build_object('correct', true, 'alreadySolved', false, 'points', points);
end $$;

create or replace function public.scribble_append_strokes(p_room_id uuid, p_user_id uuid, p_turn_id uuid, p_revision integer, p_strokes jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; seq bigint; batches integer; stroke jsonb; point jsonb;
begin
  if jsonb_typeof(p_strokes) <> 'array' or jsonb_array_length(p_strokes) not between 1 and 8 or octet_length(p_strokes::text) > 32768 then raise exception 'Drawing update is too large.' using errcode = '22023'; end if;
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_turn_id is distinct from p_turn_id then raise exception 'The drawing turn changed.' using errcode = '40001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the current drawer can draw.' using errcode = '42501'; end if;
  if room.canvas_revision <> p_revision then raise exception 'Canvas revision changed.' using errcode = '40001'; end if;
  for stroke in select value from jsonb_array_elements(p_strokes) loop
    if jsonb_typeof(stroke) <> 'object' or stroke->>'tool' not in ('pen', 'eraser') or coalesce(length(stroke->>'id'), 0) not between 1 and 80
       or (stroke->>'tool' = 'pen' and coalesce(stroke->>'color', '') !~ '^#[0-9a-fA-F]{6}$')
       or jsonb_typeof(stroke->'points') <> 'array' or jsonb_array_length(stroke->'points') not between 1 and 64 then raise exception 'Invalid drawing stroke.' using errcode = '22023'; end if;
    if (stroke->>'width')::numeric not between 1 and 32 then raise exception 'Invalid stroke width.' using errcode = '22023'; end if;
    for point in select value from jsonb_array_elements(stroke->'points') loop
      if (point->>'x')::numeric not between 0 and 1 or (point->>'y')::numeric not between 0 and 1 then raise exception 'Drawing coordinates must be normalized.' using errcode = '22023'; end if;
    end loop;
  end loop;
  select count(*) into batches from public.scribble_drawing_batches where turn_id = room.current_turn_id and canvas_revision = p_revision;
  if batches >= 600 then raise exception 'Drawing turn reached its update limit.' using errcode = 'P0001'; end if;
  select coalesce(max(sequence), 0) + 1 into seq from public.scribble_drawing_batches where turn_id = room.current_turn_id and canvas_revision = p_revision;
  insert into public.scribble_drawing_batches (room_id, turn_id, canvas_revision, sequence, drawer_id, strokes)
    values (p_room_id, room.current_turn_id, p_revision, seq, p_user_id, p_strokes);
  update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id;
  return jsonb_build_object('sequence', seq, 'revision', p_revision);
end $$;

create or replace function public.scribble_clear_canvas(p_room_id uuid, p_user_id uuid, p_turn_id uuid, p_revision integer)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; revision integer;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'active' or room.phase <> 'drawing' or room.phase_deadline <= clock_timestamp() then raise exception 'This drawing turn has ended.' using errcode = 'P0001'; end if;
  if room.current_turn_id is distinct from p_turn_id then raise exception 'The drawing turn changed.' using errcode = '40001'; end if;
  if room.current_drawer_id <> p_user_id then raise exception 'Only the drawer can clear the canvas.' using errcode = '42501'; end if;
  if room.canvas_revision <> p_revision then raise exception 'Canvas revision changed.' using errcode = '40001'; end if;
  revision := p_revision + 1;
  update public.scribble_turns set canvas_revision = revision where id = room.current_turn_id;
  update public.scribble_rooms set canvas_revision = revision, state_version = state_version + 1, updated_at = now() where id = p_room_id;
  return jsonb_build_object('revision', revision);
end $$;

create or replace function public.scribble_ping(p_room_id uuid, p_user_id uuid)
returns timestamptz language plpgsql security definer set search_path = '' as $$
declare seen timestamptz;
begin
  update public.scribble_members set last_seen_at = now() where room_id = p_room_id and user_id = p_user_id and status in ('active', 'waiting') returning last_seen_at into seen;
  if seen is null then raise exception 'You are not an active member of this room.' using errcode = '42501'; end if;
  update public.scribble_rooms set drawer_grace_deadline = null
    where id = p_room_id and phase = 'drawing' and current_drawer_id = p_user_id and drawer_grace_deadline is not null;
  return seen;
end $$;

create or replace function public.scribble_leave_room(p_room_id uuid, p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype; turn public.scribble_turns%rowtype; next_host uuid;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found then return jsonb_build_object('left', true); end if;
  update public.scribble_members set status = 'left', seat = null, left_at = now() where room_id = p_room_id and user_id = p_user_id and status <> 'left';
  if not found then return jsonb_build_object('left', true); end if;
  if room.current_drawer_id = p_user_id and room.phase in ('choosing', 'drawing') then
    select * into turn from public.scribble_turns where id = room.current_turn_id for update;
    update public.scribble_turns set ended_at = now() where id = turn.id;
    update public.scribble_rooms set phase = 'reveal', phase_deadline = now() + interval '3 seconds',
      public_state = jsonb_build_object('answer', turn.answer, 'reason', 'drawer_left'), state_version = state_version + 1, updated_at = now() where id = p_room_id;
    insert into public.scribble_events (room_id, turn_id, event_type, body) values
      (p_room_id, turn.id, 'reveal', jsonb_build_object('answer', turn.answer, 'text', 'The drawer left; the word is revealed.'));
  end if;
  if room.host_id = p_user_id then
    select user_id into next_host from public.scribble_members where room_id = p_room_id and status = 'active' order by seat limit 1;
    if next_host is null then update public.scribble_rooms set status = 'closed', phase = 'results', phase_deadline = null, state_version = state_version + 1, updated_at = now() where id = p_room_id;
    else
      update public.scribble_members set is_host = (user_id = next_host) where room_id = p_room_id and status = 'active';
      update public.scribble_rooms set host_id = next_host, state_version = state_version + 1, updated_at = now() where id = p_room_id;
    end if;
  else update public.scribble_rooms set state_version = state_version + 1, updated_at = now() where id = p_room_id; end if;
  return jsonb_build_object('left', true, 'hostId', next_host);
end $$;

create or replace function public.scribble_rematch(p_room_id uuid, p_user_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare room public.scribble_rooms%rowtype;
begin
  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.host_id <> p_user_id then raise exception 'Only the host can start a rematch.' using errcode = '42501'; end if;
  if room.status <> 'results' then raise exception 'The current Scribble game has not ended.' using errcode = 'P0001'; end if;
  delete from public.scribble_turns where room_id = p_room_id;
  delete from public.scribble_events where room_id = p_room_id;
  with seated as (
    select user_id, row_number() over (order by joined_at)::smallint as new_seat
    from public.scribble_members where room_id = p_room_id and status in ('active', 'waiting')
  )
  update public.scribble_members m set score = 0, status = 'active', seat = seated.new_seat, left_at = null, is_host = (m.user_id = p_user_id)
  from seated where m.room_id = p_room_id and m.user_id = seated.user_id;
  update public.scribble_rooms set status = 'waiting', phase = 'waiting', turn_number = 0, cycle_number = 0, turn_order = '{}',
    drawn_this_cycle = '{}', current_drawer_id = null, current_turn_id = null, phase_deadline = null, canvas_revision = 0,
    public_state = '{}'::jsonb, started_at = null, finished_at = null, invite_expires_at = now() + interval '10 minutes',
    state_version = state_version + 1, updated_at = now() where id = p_room_id returning * into room;
  return to_jsonb(room);
end $$;
