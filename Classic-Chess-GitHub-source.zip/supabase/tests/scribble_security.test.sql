begin;
select plan(12);

select has_table('public', 'scribble_rooms', 'Scribble rooms are installed');
select has_table('public', 'scribble_drawing_batches', 'Drawing checkpoint batches are installed');
select ok((select relrowsecurity from pg_class where oid = 'public.scribble_rooms'::regclass), 'Room rows have RLS enabled');
select ok((select relrowsecurity from pg_class where oid = 'public.scribble_drawing_batches'::regclass), 'Drawing rows have RLS enabled');
select ok(not has_table_privilege('authenticated', 'public.scribble_turns', 'select'), 'Players cannot query private word choices or answers');
select ok(not has_table_privilege('authenticated', 'public.scribble_word_bank', 'select'), 'Players cannot enumerate the word bank');
select ok(not has_table_privilege('authenticated', 'public.scribble_drawing_batches', 'insert'), 'Players cannot write drawing rows directly');
select ok(has_table_privilege('service_role', 'public.scribble_drawing_batches', 'insert'), 'The trusted server can append drawing batches');
select has_function('public', 'scribble_append_strokes', array['uuid', 'uuid', 'uuid', 'integer', 'jsonb'], 'Stroke RPC requires room, authenticated user, turn, revision, and bounded payload');
select has_function('public', 'scribble_clear_canvas', array['uuid', 'uuid', 'uuid', 'integer'], 'Clear RPC is bound to a specific drawing turn');
select ok(not has_function_privilege('authenticated', 'public.scribble_advance_due_rooms(uuid)', 'execute'), 'Players cannot advance server deadlines');
select has_policy('public', 'scribble_rooms', 'Room members read room state', 'Room reads are limited by membership');

select * from finish();
rollback;
