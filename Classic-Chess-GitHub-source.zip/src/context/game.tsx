import { createContext, useCallback, useContext, useMemo, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import type { BoardDesign, ComputerLevel, GameMode, PieceTone, PlayerColor } from '@/constants/chess';
import type { OnlineProfile } from '@/lib/chess-room';

export type GameSettings = {
  mode: GameMode;
  playerColor: PlayerColor;
  board: BoardDesign;
  computerLevel: ComputerLevel;
  whiteTone: PieceTone;
  blackTone: PieceTone;
};

type GameContextValue = {
  settings: GameSettings;
  setSettings: Dispatch<SetStateAction<GameSettings>>;
  moves: string[];
  setMoves: (moves: string[] | ((previous: string[]) => string[])) => void;
  onlineProfile: OnlineProfile;
  setOnlineProfile: Dispatch<SetStateAction<OnlineProfile>>;
};

const initialSettings: GameSettings = {
  mode: 'local',
  playerColor: 'w',
  board: 'wood',
  computerLevel: 'casual',
  whiteTone: 'pearl',
  blackTone: 'onyx',
};

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState(initialSettings);
  const [moves, setMoves] = useState<string[]>([]);
  const [onlineProfile, setOnlineProfile] = useState<OnlineProfile>({
    name: 'Player',
    pieceTone: 'pearl',
    accentColor: '#4e7c6e',
    showName: true,
  });
  const updateOnlineProfile = useCallback<Dispatch<SetStateAction<OnlineProfile>>>((profile) => setOnlineProfile(profile), []);
  const value = useMemo(() => ({ settings, setSettings, moves, setMoves, onlineProfile, setOnlineProfile: updateOnlineProfile }), [settings, moves, onlineProfile, updateOnlineProfile]);

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) throw new Error('useGame must be used within GameProvider');
  return context;
}
