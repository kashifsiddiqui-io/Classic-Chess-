import { withSupabase } from '@supabase/server';
import { Chess } from 'chess.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

const userHandler = withSupabase({ auth: 'user' }, async (request, ctx) => {
  if (request.method !== 'POST') return json({ error: 'Use POST to request a move hint.' }, 405);

  const { data: { user }, error: authError } = await ctx.supabase.auth.getUser();
  if (authError || !user) return json({ error: 'Sign in to request a chess hint.' }, 401);

  let body: { fen?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'The board position is invalid.' }, 400);
  }
  if (typeof body.fen !== 'string' || body.fen.length > 256 || /[\u0000-\u001f\u007f]/.test(body.fen)) {
    return json({ error: 'The board position is invalid.' }, 400);
  }

  let chess: Chess;
  try {
    chess = new Chess(body.fen);
  } catch {
    return json({ error: 'The board position is invalid.' }, 400);
  }
  if (chess.isGameOver()) return json({ error: 'This game has finished; start a new match for another hint.' }, 409);

  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return json({ error: 'There are no legal moves in this position.' }, 409);

  const { data: allowed, error: limitError } = await ctx.supabaseAdmin.rpc('allow_chess_hint_request', { p_user_id: user.id });
  if (limitError) return json({ error: 'The chess coach is temporarily unavailable.' }, 503);
  if (allowed !== true) return json({ error: 'Please wait a few seconds before asking for another hint. The daily hint limit is 40.' }, 429);

  const apiKey = Deno.env.get('GROQ_API_KEY');
  if (!apiKey) return json({ error: 'The chess coach is not configured on the server.' }, 503);

  const model = 'openai/gpt-oss-20b';
  let response: Response;
  try {
    response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        reasoning_effort: 'low',
        max_completion_tokens: 240,
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'chess_move_hint',
            strict: true,
            schema: {
              type: 'object',
              properties: {
                san: { type: 'string', enum: legalMoves.map((move) => move.san) },
                reasons: { type: 'array', items: { type: 'string' } },
              },
              required: ['san', 'reasons'],
              additionalProperties: false,
            },
          },
        },
        messages: [
          {
            role: 'system',
            content: 'You are a friendly chess coach for beginners. Analyze the supplied FEN and choose one useful move for the side to move from the provided legal SAN choices. Explain the move in two short, concrete beginner-friendly points. Never invent a move or claim certainty about a forced win. Return only the requested JSON.',
          },
          {
            role: 'user',
            content: JSON.stringify({ fen: chess.fen(), sideToMove: chess.turn() === 'w' ? 'White' : 'Black', legalMoves: legalMoves.map((move) => ({ san: move.san, from: move.from, to: move.to, piece: move.piece, captured: move.captured ?? null, promotion: move.promotion ?? null })) }),
          },
        ],
      }),
      signal: AbortSignal.timeout(18_000),
    });
  } catch {
    return json({ error: 'The chess coach could not be reached. Check your connection and try again.' }, 502);
  }

  if (!response.ok) {
    if (response.status === 429) return json({ error: 'The chess coach is busy. Wait a moment and try again.' }, 429);
    return json({ error: 'The chess coach could not create a hint. Try again shortly.' }, 502);
  }

  let payload: { choices?: Array<{ message?: { content?: unknown } }> };
  try {
    payload = await response.json();
  } catch {
    return json({ error: 'The chess coach returned an unreadable response. Try again.' }, 502);
  }
  const content = payload.choices?.[0]?.message?.content;
  if (typeof content !== 'string') return json({ error: 'The chess coach returned an incomplete hint. Try again.' }, 502);

  let suggestion: { san?: unknown; reasons?: unknown };
  try {
    suggestion = JSON.parse(content);
  } catch {
    return json({ error: 'The chess coach returned an invalid hint. Try again.' }, 502);
  }
  const move = legalMoves.find((candidate) => candidate.san === suggestion.san);
  if (!move) return json({ error: 'The chess coach could not find a valid move. Try again.' }, 502);

  const pieceNames: Record<string, string> = { p: 'pawn', r: 'rook', n: 'knight', b: 'bishop', q: 'queen', k: 'king' };
  const reasons = Array.isArray(suggestion.reasons)
    ? suggestion.reasons.filter((reason): reason is string => typeof reason === 'string').map((reason) => reason.trim()).filter((reason) => reason.length > 0 && reason.length <= 180).slice(0, 3)
    : [];

  return json({
    san: move.san,
    from: move.from,
    to: move.to,
    piece: pieceNames[move.piece],
    reasons: reasons.length ? reasons : ['This is a legal move to consider in this position.'],
  });
});

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const response = await userHandler(request);
    const headers = new Headers(response.headers);
    Object.entries(corsHeaders).forEach(([name, value]) => headers.set(name, value));
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch {
    return json({ error: 'The chess coach is temporarily unavailable.' }, 500);
  }
});
