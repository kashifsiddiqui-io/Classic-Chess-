import { Chess, type Move, type Square as ChessSquare } from 'chess.js';
import { GlassView } from 'expo-glass-effect';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { ImageBackground, Platform, Pressable, ScrollView, Share, StyleSheet, Text, TextInput, useWindowDimensions, View, type ScrollViewInstance, type StyleProp, type ViewStyle } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';

import { BOARD_COLORS, type PieceTone, type PlayerColor } from '@/constants/chess';
import { ChessPiece } from '@/components/chess-piece';
import { TrophyIcon } from '@/components/trophy-icon';
import { useGame } from '@/context/game';
import { useAuth } from '@/context/auth';
import { recordCompletedGame } from '@/lib/player-activity';
import { isChessRoom, type ChessRoom } from '@/lib/chess-room';
import { callChessRoom } from '@/lib/chess-room';
import { chooseComputerMove, piecePositions } from '@/lib/chess-ai';
import { ensureAuthenticatedSession, getSupabase } from '@/lib/supabase';
import { useChessMoveSound } from '@/lib/chess-sound';
import { speakChessAnnouncement } from '@/lib/chess-voice';
import { settleTrophyAiMatch, startTrophyAiMatch } from '@/lib/trophies';
import { getChessMoveHint, type ChessMoveHint } from '@/lib/chess-hint';

const FILES = 'abcdefgh';
const screenCanvas = '#f3f0eb';
const green = '#4e7c6e';
const BOARD_FRAME_BORDER = 5;
const ROOM_EXPIRED_MESSAGE = 'This room link has expired. Please create a new room.';
const PIECE_NAMES: Record<string, string> = { p: 'pawn', r: 'rook', n: 'knight', b: 'bishop', q: 'queen', k: 'king' };
const RANK_NAMES: Record<string, string> = { '1': 'one', '2': 'two', '3': 'three', '4': 'four', '5': 'five', '6': 'six', '7': 'seven', '8': 'eight' };
const CHAT_EMOJIS = ['😂', '😍', '👏', '🔥', '😮', '👍'] as const;
const CHAT_STICKERS = [
  { key: 'gg', emoji: '🤝', label: 'Good game' },
  { key: 'nice', emoji: '✨', label: 'Nice move' },
  { key: 'fire', emoji: '🔥', label: 'On fire' },
  { key: 'wow', emoji: '😮', label: 'What a move' },
  { key: 'heart', emoji: '💚', label: 'Love it' },
  { key: 'oops', emoji: '😅', label: 'Oops' },
] as const;
type ChessChatKind = 'text' | 'emoji' | 'sticker';
type ChessChatReaction = { room_id: string; message_id: string; user_id: string; emoji: string };
type ChessChatMessage = { id: string; room_id: string; sender_id: string; kind: ChessChatKind; content: string; created_at: string; reactions: ChessChatReaction[]; sending?: boolean };
type ChessChatMessageRow = Omit<ChessChatMessage, 'reactions'>;

function GiftIcon() {
  return <Svg width={22} height={22} viewBox="0 0 24 24" accessibilityLabel="Gift bonus">
    <Path d="M3 10h18v4H3zm2 4h14v7H5zm7-4v11m0-11H8a2.5 2.5 0 1 1 2.5-2.5c0 2.5 1.5 2.5 1.5 2.5Zm0 0h4a2.5 2.5 0 1 0-2.5-2.5c0 2.5-1.5 2.5-1.5 2.5Z" fill="none" stroke="#202923" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>;
}

function BulbIcon() {
  return <Svg width={25} height={25} viewBox="0 0 24 24" accessibilityLabel="Chess hint">
    <Path d="M9 18h6m-5 3h4m-5.8-6.1A7 7 0 1 1 16.8 15c-.9.7-1.3 1.6-1.4 3H8.6c-.1-1.4-.5-2.3-1.4-3ZM12 1v2m8 1.2-1.4 1.4M4 4.2l1.4 1.4M2 11h2m16 0h2" fill="none" stroke="#c18d2d" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>;
}

function isChessChatMessage(value: unknown): value is ChessChatMessageRow {
  if (!value || typeof value !== 'object') return false;
  const message = value as Record<string, unknown>;
  const kind = message.kind;
  const content = message.content;
  const validContent = kind === 'text' && typeof content === 'string' && content.trim().length > 0 && content.length <= 500
    || kind === 'emoji' && typeof content === 'string' && CHAT_EMOJIS.includes(content as typeof CHAT_EMOJIS[number])
    || kind === 'sticker' && typeof content === 'string' && CHAT_STICKERS.some((sticker) => sticker.key === content);
  return typeof message.id === 'string'
    && typeof message.room_id === 'string'
    && typeof message.sender_id === 'string'
    && (kind === 'text' || kind === 'emoji' || kind === 'sticker')
    && validContent
    && typeof message.created_at === 'string'
    && Number.isFinite(Date.parse(message.created_at));
}

function isChessChatReaction(value: unknown): value is ChessChatReaction {
  if (!value || typeof value !== 'object') return false;
  const reaction = value as Record<string, unknown>;
  return typeof reaction.room_id === 'string'
    && typeof reaction.message_id === 'string'
    && typeof reaction.user_id === 'string'
    && typeof reaction.emoji === 'string'
    && CHAT_EMOJIS.includes(reaction.emoji as typeof CHAT_EMOJIS[number]);
}

function chatErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message
    : error && typeof error === 'object' && 'message' in error && typeof error.message === 'string' ? error.message : '';
  if (/chess_chat_messages|chess_chat_reactions|schema cache|42P01/i.test(message)) return 'Chat setup is missing. Run the Chess Chat SQL in Supabase.';
  if (/row-level security|permission denied/i.test(message)) return 'You do not have access to this room conversation.';
  return 'Could not load the conversation. Check your connection and try again.';
}

function stickerFor(key: string) {
  return CHAT_STICKERS.find((sticker) => sticker.key === key) ?? CHAT_STICKERS[0];
}

function ChessChat({ roomId, userId, ownName, opponentName }: { roomId: string; userId: string; ownName: string; opponentName: string }) {
  const [messages, setMessages] = useState<ChessChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [stickerOpen, setStickerOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pendingReaction, setPendingReaction] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const listRef = useRef<ScrollViewInstance | null>(null);
  const localMutationVersion = useRef(0);
  const localMessageSequence = useRef(0);
  const supabase = getSupabase();

  useEffect(() => {
    if (!supabase) return;

    let active = true;
    let newestRequest = 0;
    const refreshMessages = async (requestId: number, versionAtStart: number) => {
      const { data, error: messageError } = await supabase.from('chess_chat_messages')
        .select('id, room_id, sender_id, kind, content, created_at')
        .eq('room_id', roomId)
        .order('created_at', { ascending: false })
        .limit(100);
      if (messageError) throw messageError;
      const rows = (data ?? []).reverse().filter(isChessChatMessage);
      let reactions: ChessChatReaction[] = [];
      if (rows.length) {
        const { data: reactionRows, error: reactionError } = await supabase.from('chess_chat_reactions')
          .select('room_id, message_id, user_id, emoji')
          .eq('room_id', roomId)
          .in('message_id', rows.map((row) => row.id));
        if (reactionError) throw reactionError;
        const messageIds = new Set(rows.map((row) => row.id));
        reactions = (reactionRows ?? []).filter(isChessChatReaction)
          .filter((reaction) => reaction.room_id === roomId && messageIds.has(reaction.message_id));
      }
      if (!active || requestId !== newestRequest || versionAtStart !== localMutationVersion.current) return;
      setMessages((current) => {
        if (versionAtStart !== localMutationVersion.current) return current;
        const sending = current.filter((message) => message.sending);
        const serverMessages = rows.map((row) => ({ ...row, reactions: reactions.filter((reaction) => reaction.message_id === row.id) }));
        return [...serverMessages, ...sending.filter((message) => !serverMessages.some((row) => row.id === message.id))];
      });
      setError('');
      setLoading(false);
    };

    const refreshSafely = () => {
      const requestId = ++newestRequest;
      const versionAtStart = localMutationVersion.current;
      void refreshMessages(requestId, versionAtStart).catch((cause: unknown) => {
        if (!active || requestId !== newestRequest || versionAtStart !== localMutationVersion.current) return;
        setError(chatErrorMessage(cause));
        setLoading(false);
      });
    };
    refreshSafely();
    const channel = supabase.channel(`chess-chat-${roomId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chess_chat_messages', filter: `room_id=eq.${roomId}` }, refreshSafely)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chess_chat_reactions', filter: `room_id=eq.${roomId}` }, refreshSafely)
      .subscribe((status) => {
        if (active && (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT')) setError('Live chat connection was interrupted. Check your internet.');
      });

    return () => {
      active = false;
      void supabase.removeChannel(channel);
    };
  }, [roomId, supabase]);

  async function sendMessage(kind: ChessChatKind, content: string) {
    const supabase = getSupabase();
    const messageContent = kind === 'text' ? content.trim().slice(0, 500) : content;
    if (!supabase || busy || !messageContent) return;
    const temporaryId = `sending-${++localMessageSequence.current}`;
    const optimistic: ChessChatMessage = {
      id: temporaryId,
      room_id: roomId,
      sender_id: userId,
      kind,
      content: messageContent,
      created_at: new Date().toISOString(),
      reactions: [],
      sending: true,
    };
    localMutationVersion.current += 1;
    setMessages((current) => [...current, optimistic]);
    setBusy(true);
    setError('');
    if (kind === 'text') setDraft('');
    try {
      const { data, error: insertError } = await supabase.from('chess_chat_messages').insert({
        room_id: roomId,
        sender_id: userId,
        kind,
        content: messageContent,
      }).select('id, room_id, sender_id, kind, content, created_at').single();
      if (insertError) throw insertError;
      if (!isChessChatMessage(data)) throw new Error('Chat returned an invalid message.');
      localMutationVersion.current += 1;
      setMessages((current) => {
        const confirmed = { ...data, reactions: [] };
        const withoutTemporary = current.filter((message) => message.id !== temporaryId && message.id !== confirmed.id);
        return [...withoutTemporary, confirmed];
      });
      setStickerOpen(false);
    } catch (cause) {
      localMutationVersion.current += 1;
      setMessages((current) => current.filter((message) => message.id !== temporaryId));
      if (kind === 'text') setDraft((current) => current.trim() ? current : messageContent);
      setError(chatErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  }

  async function toggleReaction(message: ChessChatMessage, emoji: string) {
    const supabase = getSupabase();
    if (!supabase || pendingReaction) return;
    const key = `${message.id}:${emoji}`;
    setPendingReaction(key);
    setError('');
    try {
      const existing = message.reactions.some((reaction) => reaction.user_id === userId && reaction.emoji === emoji);
      const result = existing
        ? await supabase.from('chess_chat_reactions').delete().eq('message_id', message.id).eq('user_id', userId).eq('emoji', emoji)
        : await supabase.from('chess_chat_reactions').insert({ room_id: roomId, message_id: message.id, user_id: userId, emoji });
      if (result.error) throw result.error;
    } catch (cause) {
      setError(chatErrorMessage(cause));
    } finally {
      setPendingReaction(null);
    }
  }

  return <View style={styles.chatSection}>
    <View style={styles.chatHeading}>
      <View>
        <Text style={styles.chatEyebrow}>PLAY TOGETHER</Text>
        <Text style={styles.chatTitle}>Game chat</Text>
      </View>
      <View style={styles.chatLivePill}><View style={styles.chatLiveDot} /><Text style={styles.chatLiveText}>PRIVATE ROOM</Text></View>
    </View>
    <ImageBackground
      source={require('../../assets/images/chess-chat-canvas.png')}
      resizeMode="cover"
      imageStyle={styles.chatBackgroundImage}
      style={styles.chatCanvas}
    >
      <View pointerEvents="none" style={styles.chatCanvasWash} />
      <ScrollView
        ref={listRef}
        style={styles.chatMessages}
        contentContainerStyle={styles.chatMessagesContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
      >
        {loading && <Text style={styles.chatEmpty}>Opening your conversation…</Text>}
        {!loading && !error && messages.length === 0 && <Text style={styles.chatEmpty}>Send a quick reaction or say hello.</Text>}
        {messages.map((message) => {
          const mine = message.sender_id === userId;
          const counts = message.reactions.reduce<Record<string, number>>((total, reaction) => {
            total[reaction.emoji] = (total[reaction.emoji] ?? 0) + 1;
            return total;
          }, {});
          return <View key={message.id} style={[styles.chatMessageRow, mine && styles.chatMessageRowMine]}>
            <View style={[styles.chatMessageColumn, mine && styles.chatMessageColumnMine]}>
              <View style={[styles.chatBubble, mine ? styles.chatBubbleMine : styles.chatBubbleFriend, message.sending && styles.chatBubbleSending]}>
                <View style={styles.chatMessageMeta}>
                  <Text style={[styles.chatSender, mine && styles.chatSenderMine]}>{mine ? `You · ${ownName}` : opponentName}</Text>
                  <Text style={[styles.chatTime, mine && styles.chatTimeMine]}>{new Date(message.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</Text>
                </View>
                {message.kind === 'text' && <Text style={[styles.chatMessageText, mine && styles.chatMessageTextMine]}>{message.content}</Text>}
                {message.kind === 'emoji' && <Text style={styles.chatEmojiBubble}>{message.content}</Text>}
                {message.kind === 'sticker' && <View style={[styles.chatStickerBubble, mine && styles.chatStickerBubbleMine]}><Text style={styles.chatStickerArt}>{stickerFor(message.content).emoji}</Text><Text style={[styles.chatStickerLabel, mine && styles.chatStickerLabelMine]}>{stickerFor(message.content).label}</Text></View>}
                {message.sending && <Text style={[styles.chatSending, mine && styles.chatSendingMine]}>Sending…</Text>}
              </View>
              <View style={[styles.chatReactions, mine && styles.chatReactionsMine]}>
                {CHAT_EMOJIS.slice(0, 4).map((emoji) => {
                  const count = counts[emoji] ?? 0;
                  const selected = message.reactions.some((reaction) => reaction.user_id === userId && reaction.emoji === emoji);
                  return <Pressable key={emoji} onPress={() => void toggleReaction(message, emoji)} disabled={Boolean(pendingReaction)} style={[styles.chatReactionChip, selected && styles.chatReactionSelected]} accessibilityRole="button" accessibilityLabel={`React ${emoji} to message`}>
                    <Text style={styles.chatReactionEmoji}>{emoji}</Text>{count > 0 && <Text style={styles.chatReactionCount}>{count}</Text>}
                  </Pressable>;
                })}
              </View>
            </View>
          </View>;
        })}
      </ScrollView>
      {error || !supabase ? <Text style={styles.chatError}>{error || 'Chat setup is missing. Configure Supabase and run the Chess Chat SQL.'}</Text> : null}
      <View style={styles.chatComposerArea}>
        <View style={styles.chatQuickRow}>
          {CHAT_EMOJIS.map((emoji) => <Pressable key={emoji} onPress={() => void sendMessage('emoji', emoji)} disabled={busy} style={styles.chatQuickEmoji} accessibilityRole="button" accessibilityLabel={`Send ${emoji}`}><Text style={styles.chatQuickEmojiText}>{emoji}</Text></Pressable>)}
          <Pressable onPress={() => setStickerOpen((open) => !open)} style={[styles.chatStickerToggle, stickerOpen && styles.chatStickerToggleOpen]} accessibilityRole="button" accessibilityLabel="Open sticker pack"><Text style={styles.chatStickerToggleText}>☺ Sticker</Text></Pressable>
        </View>
        {stickerOpen && <View style={styles.chatStickerTray}>
          {CHAT_STICKERS.map((sticker) => <Pressable key={sticker.key} onPress={() => void sendMessage('sticker', sticker.key)} disabled={busy} style={styles.chatStickerOption} accessibilityRole="button" accessibilityLabel={`Send ${sticker.label} sticker`}>
            <Text style={styles.chatStickerOptionEmoji}>{sticker.emoji}</Text><Text style={styles.chatStickerOptionLabel}>{sticker.label}</Text>
          </Pressable>)}
        </View>}
        <View style={styles.chatComposer}>
          <TextInput nativeID="chess-chat-input" value={draft} onChangeText={(value) => setDraft(value.slice(0, 500))} onSubmitEditing={() => void sendMessage('text', draft)} placeholder="Message your friend…" placeholderTextColor="#87928a" style={styles.chatInput} maxLength={500} returnKeyType="send" accessibilityLabel="Write a message to your opponent" />
          <Pressable onPress={() => void sendMessage('text', draft)} disabled={busy || !draft.trim()} style={[styles.chatSendButton, (busy || !draft.trim()) && styles.chatSendDisabled]} accessibilityRole="button" accessibilityLabel="Send message"><Text style={styles.chatSendText}>↑</Text></Pressable>
        </View>
      </View>
    </ImageBackground>
  </View>;
}

function describeSquare(square: string) {
  return `${square[0].toUpperCase()} ${RANK_NAMES[square[1]] ?? square[1]}`;
}

function describeMove(move: Move, position: Chess, actor: string) {
  let announcement: string;
  if (move.flags.includes('k') || move.flags.includes('q')) {
    announcement = `${actor} castles ${move.flags.includes('k') ? 'king side' : 'queen side'}.`;
  } else if (move.promotion) {
    announcement = `${actor} promotes a pawn to a ${PIECE_NAMES[move.promotion]} on ${describeSquare(move.to)}.`;
  } else {
    const piece = PIECE_NAMES[move.piece] ?? 'piece';
    const action = move.captured ? `captures on ${describeSquare(move.to)}` : `moves from ${describeSquare(move.from)} to ${describeSquare(move.to)}`;
    const lead = actor === 'You' ? `You move your ${piece}` : actor === 'Computer' ? `Computer moves its ${piece}` : `${actor} moves the ${piece}`;
    announcement = `${lead} ${action}.`;
  }

  if (position.isCheckmate()) return `${announcement} Checkmate. ${actor} wins.`;
  if (position.isCheck()) return `${announcement} Check.`;
  if (position.isStalemate()) return `${announcement} Stalemate. The game is a draw.`;
  if (position.isDraw()) return `${announcement} The game is a draw.`;
  return announcement;
}

function GlassPanel({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[styles.glassPanel, style]}>
      <GlassView pointerEvents="none" glassEffectStyle="regular" tintColor="#f7f5ef" style={[StyleSheet.absoluteFill, styles.glassTint]} />
      <View pointerEvents="none" style={styles.glassHighlight} />
      <View style={styles.glassContent}>{children}</View>
    </View>
  );
}

function MovingPiece({ id, file, rank, cell, type, color, tone }: { id: string; file: number; rank: number; cell: number; type: string; color: PlayerColor; tone: PieceTone }) {
  const fromX = useSharedValue(file * cell);
  const fromY = useSharedValue(rank * cell);
  const toX = useSharedValue(file * cell);
  const toY = useSharedValue(rank * cell);
  const progress = useSharedValue(1);
  const initialized = useRef(false);
  useEffect(() => {
    const nextX = file * cell;
    const nextY = rank * cell;
    if (!initialized.current) {
      fromX.value = nextX;
      fromY.value = nextY;
      toX.value = nextX;
      toY.value = nextY;
      initialized.current = true;
      return;
    }
    const currentProgress = progress.value;
    fromX.value += (toX.value - fromX.value) * currentProgress;
    fromY.value += (toY.value - fromY.value) * currentProgress;
    toX.value = nextX;
    toY.value = nextY;
    progress.value = 0;
    progress.value = withTiming(1, { duration: 290, easing: Easing.out(Easing.cubic) });
  }, [cell, file, fromX, fromY, progress, rank, toX, toY]);
  const style = useAnimatedStyle(() => {
    const t = progress.value;
    const lift = Math.sin(Math.PI * t);
    return {
      left: fromX.value + (toX.value - fromX.value) * t,
      top: fromY.value + (toY.value - fromY.value) * t - lift * cell * 0.38,
      zIndex: lift > 0.02 ? 5 : 1,
      transform: [
        { scale: 1 + lift * 0.12 },
        { rotateZ: `${lift * (file % 2 === 0 ? 3 : -3)}deg` },
      ],
    };
  });
  return <Animated.View key={id} pointerEvents="none" style={[styles.movingPiece, { width: cell, height: cell }, style]}><ChessPiece type={type} color={color} tone={tone} size={cell * 0.78} /></Animated.View>;
}

function Board({ chess, selected, legal, disabled, playerColor, board, tones, onSquare, lastMove }: {
  chess: Chess; selected: ChessSquare | null; legal: Move[]; disabled: boolean; playerColor: PlayerColor;
  board: 'wood' | 'classic' | 'green'; tones: Record<PlayerColor, PieceTone>;
  onSquare: (square: ChessSquare) => void; lastMove: { from: ChessSquare; to: ChessSquare } | null;
}) {
  const { width } = useWindowDimensions();
  const boardSize = Math.min(width - 32, 460);
  // The board squares sit inside the frame border, so piece coordinates must
  // use that same inner area to stay centered from the first file to the last.
  const cell = (boardSize - BOARD_FRAME_BORDER * 2) / 8;
  const colors = BOARD_COLORS[board];
  const pieces = useMemo(() => piecePositions(chess.history()), [chess]);

  return (
    <View style={[styles.boardFrame, { width: boardSize, height: boardSize, borderColor: colors.frame, borderWidth: BOARD_FRAME_BORDER }]}>
      {Array.from({ length: 64 }, (_, index) => {
        const row = Math.floor(index / 8);
        const col = index % 8;
        const fileIndex = playerColor === 'w' ? col : 7 - col;
        const rank = playerColor === 'w' ? 8 - row : row + 1;
        const square = `${FILES[fileIndex]}${rank}` as ChessSquare;
        const piece = chess.get(square);
        const highlighted = selected === square;
        const valid = legal.some((move) => move.to === square);
        const last = lastMove?.from === square || lastMove?.to === square;
        const isDark = (fileIndex + rank) % 2 === 1;
        return (
          <Pressable key={square} disabled={disabled} onPress={() => onSquare(square)} accessibilityRole="button" accessibilityLabel={`${square}${piece ? ` ${piece.color === 'w' ? 'white' : 'black'} ${piece.type}` : ' empty'}`} style={({ pressed }) => [styles.square, { left: `${col * 12.5}%`, top: `${row * 12.5}%`, backgroundColor: isDark ? colors.dark : colors.light }, (highlighted || last) && styles.lastMoveSquare, pressed && styles.squarePressed]}>
            {highlighted && <View style={styles.selectedRing} />}
            {valid && <View style={[styles.legalDot, piece && styles.captureRing]} />}
            {col === 0 && <Text style={[styles.rankMark, { color: isDark ? colors.light : colors.dark }]}>{rank}</Text>}
            {row === 7 && <Text style={[styles.fileMark, { color: isDark ? colors.light : colors.dark }]}>{FILES[fileIndex]}</Text>}
          </Pressable>
        );
      })}
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {pieces.map((piece) => {
          const fileIndex = FILES.indexOf(piece.square[0]);
          const rank = Number(piece.square[1]);
          const displayFile = playerColor === 'w' ? fileIndex : 7 - fileIndex;
          const displayRank = playerColor === 'w' ? 8 - rank : rank - 1;
          return <MovingPiece key={piece.id} id={piece.id} file={displayFile} rank={displayRank} cell={cell} type={piece.type} color={piece.color} tone={tones[piece.color]} />;
        })}
      </View>
    </View>
  );
}

export default function GameScreen() {
  const params = useLocalSearchParams<{ room?: string | string[]; roomId?: string | string[] }>();
  const legacyRoomId = Array.isArray(params.room) ? params.room[0] : params.room;
  const routedRoomId = Array.isArray(params.roomId) ? params.roomId[0] : params.roomId;
  const roomId = routedRoomId ?? legacyRoomId;
  const { settings, moves, setMoves, setSettings } = useGame();
  const { user } = useAuth();
  const [selected, setSelected] = useState<ChessSquare | null>(null);
  const [promotion, setPromotion] = useState<{ from: ChessSquare; to: ChessSquare } | null>(null);
  const [aiError, setAiError] = useState('');
  const [moveHintForPosition, setMoveHintForPosition] = useState<{ fen: string; hint: ChessMoveHint } | null>(null);
  const [moveHintLoadingPosition, setMoveHintLoadingPosition] = useState<string | null>(null);
  const [moveHintErrorForPosition, setMoveHintErrorForPosition] = useState<{ fen: string; message: string } | null>(null);
  const hintRequestId = useRef(0);
  const [aiTrophyMatchId, setAiTrophyMatchId] = useState<string | null>(null);
  const [aiTrophyStatus, setAiTrophyStatus] = useState<'idle' | 'active' | 'saved' | 'error' | 'unavailable'>('idle');
  const [aiTrophyError, setAiTrophyError] = useState('');
  const [aiTrophyRetry, setAiTrophyRetry] = useState(0);
  const [aiTrophyStartAttempt, setAiTrophyStartAttempt] = useState(0);
  const aiTrophyInFlight = useRef(false);
  const aiTrophySavedMatch = useRef<string | null>(null);
  const [onlineRoom, setOnlineRoom] = useState<ChessRoom | null>(null);
  const [onlineUserId, setOnlineUserId] = useState<string | null>(null);
  const [onlineLoading, setOnlineLoading] = useState(Boolean(roomId));
  const [onlineMovePending, setOnlineMovePending] = useState(false);
  const [roomExpired, setRoomExpired] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const soundEnabledRef = useRef(true);
  const seenOnlinePly = useRef<number | null>(null);
  const { play: playAudio, unavailable: audioUnavailable } = useChessMoveSound();
  const onlineChannelRef = useRef<ReturnType<NonNullable<ReturnType<typeof getSupabase>>['channel']> | null>(null);
  const roomExpiresAt = onlineRoom?.expires_at;
  const chess = useMemo(() => {
    const next = new Chess();
    moves.forEach((move) => next.move(move));
    return next;
  }, [moves]);
  const fen = chess.fen();
  const currentFenRef = useRef(fen);
  const moveHint = moveHintForPosition?.fen === fen ? moveHintForPosition.hint : null;
  const moveHintLoading = moveHintLoadingPosition === fen;
  const moveHintError = moveHintErrorForPosition?.fen === fen ? moveHintErrorForPosition.message : '';
  const thinking = settings.mode === 'computer' && chess.turn() !== settings.playerColor && !chess.isGameOver();
  const legal = selected ? chess.moves({ square: selected, verbose: true }) : [];
  const lastMove = useMemo(() => {
    if (!moves.length) return null;
    const previous = new Chess();
    moves.slice(0, -1).forEach((move) => previous.move(move));
    const final = previous.move(moves[moves.length - 1]);
    return { from: final.from, to: final.to };
  }, [moves]);

  useEffect(() => { soundEnabledRef.current = soundEnabled; }, [soundEnabled]);

  useEffect(() => {
    if (settings.mode !== 'computer' || roomId || !user?.id || aiTrophyMatchId) return;
    const supabase = getSupabase();
    if (!supabase) return;
    let active = true;
    void startTrophyAiMatch(supabase, settings.playerColor).then((matchId) => {
      if (active) {
        setAiTrophyMatchId(matchId);
        setAiTrophyStatus('active');
        setAiTrophyError('');
      }
    }).catch((cause: unknown) => {
      if (active) {
        setAiTrophyStatus('unavailable');
        setAiTrophyError(cause instanceof Error ? cause.message : 'Could not start trophy tracking.');
      }
    });
    return () => { active = false; };
  }, [aiTrophyMatchId, aiTrophyStartAttempt, roomId, settings.mode, settings.playerColor, user?.id]);

  const playMoveCue = useCallback(() => {
    if (!soundEnabledRef.current) return;
    playAudio();
  }, [playAudio]);

  const announceMove = useCallback((move: Move, position: Chess) => {
    if (!soundEnabledRef.current || settings.mode !== 'computer') return;
    if (move.color === settings.playerColor) {
      if (position.isCheckmate()) void speakChessAnnouncement('Checkmate. You win.');
      else if (position.isCheck()) void speakChessAnnouncement('Check.');
      else if (position.isDraw()) void speakChessAnnouncement('The game is a draw.');
      return;
    }
    void speakChessAnnouncement(describeMove(move, position, 'Computer'));
  }, [settings.mode, settings.playerColor]);

  const recordOnlinePly = useCallback((ply: number) => {
    const previous = seenOnlinePly.current;
    if (previous !== null && ply > previous) playMoveCue();
    seenOnlinePly.current = Math.max(previous ?? ply, ply);
  }, [playMoveCue]);

  useEffect(() => {
    if (!roomId) return;
    const supabase = getSupabase();
    if (!supabase) return;

    let active = true;
    let loadedAfterSubscribe = false;
    seenOnlinePly.current = null;
    void ensureAuthenticatedSession(supabase)
      .then((session) => {
        if (!active) return;
        setOnlineUserId(session.user.id);
        onlineChannelRef.current = supabase.channel(`chess-room-${roomId}`)
          .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chess_rooms', filter: `id=eq.${roomId}` }, (payload) => {
            const room = payload.new;
            if (!active) return;
            if (!isChessRoom(room) || room.id !== roomId) {
              setAiError('The match sent invalid board data. Return to the menu and start a new match.');
              return;
            }
            if (room.host_id !== session.user.id && room.guest_id !== session.user.id) {
              setAiError('You are not a player in this match. Open a valid invite link to join.');
              setOnlineLoading(false);
              return;
            }
            recordOnlinePly(room.ply);
            setOnlineRoom(room);
            setSettings((previous) => ({ ...previous, mode: 'online', playerColor: room.host_id === session.user.id ? 'w' : 'b', whiteTone: room.host_piece_tone, blackTone: room.guest_piece_tone }));
            setMoves(room.moves);
          })
          .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'chess_rooms', filter: `id=eq.${roomId}` }, () => {
            if (!active) return;
            setRoomExpired(true);
            setAiError(ROOM_EXPIRED_MESSAGE);
            setOnlineLoading(false);
            const channel = onlineChannelRef.current;
            onlineChannelRef.current = null;
            if (channel) void supabase.removeChannel(channel);
          })
          .subscribe((status) => {
            if (!active) return;
            if (status === 'SUBSCRIBED' && !loadedAfterSubscribe) {
              loadedAfterSubscribe = true;
              void (async () => {
                try {
                  const { data, error } = await supabase.from('chess_rooms').select('*').eq('id', roomId).single();
                  if (!active) return;
                  if (error) throw error;
                  if (!isChessRoom(data)) throw new Error('The match data is invalid.');
                  const room = data;
                  if (room.host_id !== session.user.id && room.guest_id !== session.user.id) {
                    throw new Error('You are not a player in this match. Open a valid invite link to join.');
                  }
                  recordOnlinePly(room.ply);
                  setOnlineRoom(room);
                  setSettings((previous) => ({ ...previous, mode: 'online', playerColor: room.host_id === session.user.id ? 'w' : 'b', whiteTone: room.host_piece_tone, blackTone: room.guest_piece_tone }));
                  setMoves(room.moves);
                } catch (cause) {
                  if (active) setAiError(cause instanceof Error ? cause.message : 'Could not reconnect to this match.');
                } finally {
                  if (active) setOnlineLoading(false);
                }
              })();
            } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
              setAiError('Live match connection was interrupted. Check your internet and retry.');
              setOnlineLoading(false);
            }
          });
      })
      .catch((cause: unknown) => {
        if (!active) return;
        setAiError(cause instanceof Error ? cause.message : 'Could not start a guest session.');
        setOnlineLoading(false);
      });

    return () => {
      active = false;
      const channel = onlineChannelRef.current;
      onlineChannelRef.current = null;
      if (channel) void supabase.removeChannel(channel);
    };
  }, [recordOnlinePly, roomId, setMoves, setSettings]);

  useEffect(() => {
    if (!roomId || !roomExpiresAt) return;
    const expiresAt = Date.parse(roomExpiresAt);
    const expire = () => {
      setRoomExpired(true);
      setAiError(ROOM_EXPIRED_MESSAGE);
      setOnlineLoading(false);
      const supabase = getSupabase();
      const channel = onlineChannelRef.current;
      onlineChannelRef.current = null;
      if (supabase && channel) void supabase.removeChannel(channel);
    };
    const remaining = expiresAt - Date.now();
    if (!Number.isFinite(expiresAt) || remaining <= 0) {
      expire();
      return;
    }
    const timer = setTimeout(expire, remaining);
    return () => clearTimeout(timer);
  }, [roomExpiresAt, roomId]);

  useEffect(() => {
    if (!thinking) return;
    let cancelled = false;
    chooseComputerMove(fen, settings.computerLevel, () => cancelled)
      .then((move) => {
        if (cancelled) return;
        if (!move) { setAiError('No legal computer move is available.'); return; }
        const next = new Chess(fen);
        const playedMove = next.move(move);
        setMoves((previous) => [...previous, move]);
        playMoveCue();
        if (playedMove) announceMove(playedMove, next);
      })
      .catch(() => { if (!cancelled) setAiError('The computer could not make a move. Start a new match and try again.'); });
    return () => { cancelled = true; };
  }, [announceMove, fen, playMoveCue, settings.computerLevel, settings.mode, settings.playerColor, setMoves, thinking]);

  function commitMove(from: ChessSquare, to: ChessSquare, promote = 'q') {
    try {
      const next = new Chess(fen);
      const move = next.move({ from, to, promotion: promote });
      setSelected(null);
      setPromotion(null);
      setAiError('');
      if (roomId) {
        const supabase = getSupabase();
        if (!supabase || onlineMovePending) return;
        setOnlineMovePending(true);
        void callChessRoom(supabase, { action: 'move', roomId, move: move.san })
          .then((room) => { recordOnlinePly(room.ply); setOnlineRoom(room); setMoves(room.moves); })
          .catch((cause: unknown) => {
            setAiError(cause instanceof Error ? cause.message : 'The move could not be sent.');
            const backend = getSupabase();
            if (cause instanceof Error && cause.message.toLowerCase().includes('expired')) {
              setRoomExpired(true);
              const channel = onlineChannelRef.current;
              onlineChannelRef.current = null;
              if (channel) void backend?.removeChannel(channel);
              return;
            }
            if (backend) void (async () => {
              try {
                const { data, error } = await backend.from('chess_rooms').select('*').eq('id', roomId).single();
                if (error) throw error;
                if (isChessRoom(data)) { setOnlineRoom(data); setMoves(data.moves); }
              } catch {
                setAiError('Could not reconnect to the match. Check your internet and try again.');
              }
            })();
          })
          .finally(() => setOnlineMovePending(false));
      } else {
        setMoves((previous) => [...previous, move.san]);
        playMoveCue();
        announceMove(move, next);
      }
    } catch {
      setAiError('That move is not legal. Choose a highlighted square.');
    }
  }

  function chooseSquare(square: ChessSquare) {
    if (thinking || chess.isGameOver() || promotion) return;
    const candidate = legal.find((move) => move.to === square);
    if (selected && candidate) {
      if (candidate.promotion) setPromotion({ from: selected, to: square });
      else commitMove(selected, square);
      return;
    }
    setSelected(chess.get(square)?.color === chess.turn() ? square : null);
  }

  const turnName = chess.turn() === 'w' ? 'White' : 'Black';
  const onlineWaiting = Boolean(roomId && onlineRoom?.status === 'waiting');
  const isOnlineTurn = Boolean(onlineRoom && onlineUserId && (chess.turn() === 'w' ? onlineRoom.host_id : onlineRoom.guest_id) === onlineUserId);
  const onlineCanPlay = !roomId || Boolean(onlineRoom?.status === 'active' && isOnlineTurn && !onlineLoading && !onlineMovePending && !roomExpired);
  const hasSupabaseConfig = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY);
  function playerNameForColor(color: PlayerColor) {
    if (settings.mode !== 'online' || !onlineRoom) return color === 'w' ? 'White player' : 'Black player';
    const name = color === 'w' ? onlineRoom.host_name : onlineRoom.guest_name;
    const showName = color === 'w' ? onlineRoom.host_show_name : onlineRoom.guest_show_name;
    if (!name) return 'Waiting for friend';
    return showName ? name : `${color === 'w' ? 'White' : 'Black'} player`;
  }
  function playerAccentForColor(color: PlayerColor) {
    if (settings.mode !== 'online' || !onlineRoom) return undefined;
    return color === 'w' ? onlineRoom.host_accent_color : onlineRoom.guest_accent_color;
  }
  const winnerColor: PlayerColor = chess.turn() === 'w' ? 'b' : 'w';
  const status = roomExpired ? ROOM_EXPIRED_MESSAGE
    : roomId && !hasSupabaseConfig ? 'Supabase is not configured.'
    : roomId && onlineLoading ? 'Connecting to the match…'
    : roomId && aiError ? aiError
      : onlineWaiting ? 'Waiting for your friend to join'
        : roomId && onlineRoom?.status === 'active' ? (isOnlineTurn ? 'Your move' : 'Opponent to move')
          : chess.isCheckmate() ? `${settings.mode === 'online' ? playerNameForColor(winnerColor) : winnerColor === 'w' ? 'White' : 'Black'} wins · Checkmate`
            : chess.isDraw() ? 'Game drawn'
              : thinking ? 'Computer is thinking…'
                : `${turnName} to move${chess.isCheck() ? ' · Check' : ''}`;
  const toneBySide: Record<PlayerColor, PieceTone> = {
    w: settings.mode === 'online' && onlineRoom ? onlineRoom.host_piece_tone : settings.whiteTone,
    b: settings.mode === 'online' && onlineRoom ? onlineRoom.guest_piece_tone : settings.blackTone,
  };
  const topColor: PlayerColor = settings.playerColor === 'w' ? 'b' : 'w';
  const topName = settings.mode === 'computer' ? 'Computer' : settings.mode === 'online' ? playerNameForColor(topColor) : settings.playerColor === 'w' ? 'Player 2' : 'Player 1';
  const bottomName = settings.mode === 'online' ? playerNameForColor(settings.playerColor) : settings.mode === 'computer' ? 'You' : settings.playerColor === 'w' ? 'Player 1' : 'Player 2';
  const topAccent = playerAccentForColor(topColor);
  const bottomAccent = playerAccentForColor(settings.playerColor);
  const ended = chess.isGameOver();
  const canAskForHint = settings.mode === 'computer'
    ? chess.turn() === settings.playerColor && !thinking && !ended
    : settings.mode === 'online' && onlineCanPlay && !onlineWaiting && !ended;

  useEffect(() => {
    currentFenRef.current = fen;
    hintRequestId.current += 1;
  }, [fen]);

  async function requestMoveHint() {
    if (moveHintLoading || !canAskForHint) return;
    const supabase = getSupabase();
    if (!supabase) {
      setMoveHintErrorForPosition({ fen, message: 'Chess help needs a Supabase connection.' });
      return;
    }
    const position = fen;
    const requestId = ++hintRequestId.current;
    setMoveHintErrorForPosition(null);
    setMoveHintLoadingPosition(position);
    try {
      const hint = await getChessMoveHint(supabase, position);
      if (requestId !== hintRequestId.current || currentFenRef.current !== position) return;
      setMoveHintForPosition({ fen: position, hint });
    } catch (cause) {
      if (requestId !== hintRequestId.current || currentFenRef.current !== position) return;
      setMoveHintErrorForPosition({ fen: position, message: cause instanceof Error ? cause.message : 'Could not get a move hint. Try again.' });
    } finally {
      if (requestId === hintRequestId.current && currentFenRef.current === position) setMoveHintLoadingPosition(null);
    }
  }

  useEffect(() => {
    if (!ended || moves.length === 0) return;
    void recordCompletedGame(new Date(), onlineUserId ?? user?.id).catch((error: unknown) => console.warn('Could not save the completed game for today’s streak.', error));
  }, [ended, moves.length, onlineUserId, user?.id]);

  useEffect(() => {
    if (!ended || settings.mode !== 'computer' || !aiTrophyMatchId
      || aiTrophySavedMatch.current === aiTrophyMatchId || aiTrophyInFlight.current) return;
    const supabase = getSupabase();
    if (!supabase) return;
    let active = true;
    aiTrophyInFlight.current = true;
    void settleTrophyAiMatch(supabase, aiTrophyMatchId, moves).then(() => {
      aiTrophySavedMatch.current = aiTrophyMatchId;
      if (active) setAiTrophyStatus('saved');
    }).catch((cause: unknown) => {
      if (active) {
        setAiTrophyStatus('error');
        setAiTrophyError(cause instanceof Error ? cause.message : 'Could not save this trophy result.');
      }
    }).finally(() => { aiTrophyInFlight.current = false; });
    return () => { active = false; };
  }, [aiTrophyMatchId, aiTrophyRetry, ended, moves, settings.mode]);

  async function shareInvite() {
    if (!onlineRoom) return;
    const link = Platform.OS === 'web' && typeof window !== 'undefined'
      ? `${window.location.origin}/play/chess/${onlineRoom.id}?code=${encodeURIComponent(onlineRoom.invite_code)}`
      : Linking.createURL(`/play/chess/${onlineRoom.id}`, { queryParams: { code: onlineRoom.invite_code } });
    try {
      const message = `Join my chess match. Enter code ${onlineRoom.invite_code} or open ${link}`;
      try {
        await Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`);
      } catch {
        await Share.share({ message, url: link });
      }
    } catch {
      setAiError('Could not open the share menu. You can send the invite code manually.');
    }
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <StatusBar style="dark" animated />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable onPress={() => router.replace('/play')} hitSlop={12} style={styles.back}><Text style={styles.backText}>← Menu</Text></Pressable>
          <Text style={styles.brand}>CLASSIC CHESS</Text>
          <Text style={styles.mode}>{settings.mode === 'computer' ? 'VS COMPUTER' : settings.mode === 'online' ? 'ONLINE' : '1 VS 1'}</Text>
        </View>
        <GlassPanel style={[styles.statusCard, ended && styles.resultCard]}>
          <View style={styles.statusTopRow}>
            <Text style={styles.statusLabel}>{ended ? 'MATCH COMPLETE' : 'MATCH STATUS'}</Text>
            <Pressable onPress={() => setSoundEnabled((enabled) => !enabled)} style={styles.soundToggle} accessibilityRole="switch" accessibilityLabel={settings.mode === 'computer' ? 'Move sounds and computer voice narration' : 'Move sounds'} accessibilityState={{ checked: soundEnabled }}>
              <Text style={styles.soundToggleText}>{audioUnavailable ? 'AUDIO UNAVAILABLE' : settings.mode === 'computer' ? soundEnabled ? '♫ SOUND + VOICE ON' : '♫ SOUND + VOICE OFF' : soundEnabled ? '♫ MOVE SOUND ON' : '♫ MOVE SOUND OFF'}</Text>
            </Pressable>
          </View>
          <Text style={styles.status}>{aiError || status}</Text>
          {settings.mode === 'computer' && !ended && !aiTrophyMatchId && aiTrophyStatus === 'idle' && hasSupabaseConfig && <Text style={styles.trophyStatus}>Preparing your trophy match…</Text>}
          {settings.mode === 'computer' && ended && !hasSupabaseConfig && <Text style={styles.trophyError}>Trophies need a Supabase connection.</Text>}
          {settings.mode === 'computer' && aiTrophyStatus === 'saved' && ended && <Text style={styles.trophyStatus}>Trophy result saved to your wallet.</Text>}
          {settings.mode === 'computer' && aiTrophyStatus === 'unavailable' && <Text style={styles.trophyError}>{aiTrophyError || 'Could not start trophy tracking.'}</Text>}
          {settings.mode === 'computer' && aiTrophyStatus === 'error' && ended && <>
            <Text style={styles.trophyError}>{aiTrophyError}</Text>
            <Pressable onPress={() => { setAiTrophyError(''); setAiTrophyStatus('active'); setAiTrophyRetry((attempt) => attempt + 1); }} style={styles.trophyRetry} accessibilityRole="button"><Text style={styles.trophyRetryText}>RETRY SAVING TROPHIES</Text></Pressable>
          </>}
          {settings.mode === 'computer' && <Text style={styles.levelTag}>{settings.computerLevel.toUpperCase()} OPPONENT</Text>}
          {roomId && onlineRoom && onlineWaiting && <>
            <Text style={styles.inviteCode}>INVITE CODE  ·  {onlineRoom.invite_code}</Text>
            <Pressable onPress={() => void shareInvite()} style={styles.shareButton} accessibilityRole="button"><Text style={styles.shareButtonText}>SHARE ON WHATSAPP  ↗</Text></Pressable>
          </>}
        </GlassPanel>
        <GlassPanel style={[styles.playerCard, settings.mode === 'online' && topAccent ? { borderColor: `${topAccent}99` } : null]}><View style={styles.playerRow}><View style={[styles.playerPiece, { backgroundColor: toneBySide[topColor], borderColor: topAccent ?? '#ffffff55' }]} /><View>{settings.mode === 'computer' ? <View style={styles.computerPill}><Text style={styles.computerPillText}>COMPUTER</Text></View> : <Text style={[styles.playerName, topAccent ? { color: topAccent } : null]}>{topName}</Text>}<Text style={styles.playerColor}>{topColor === 'w' ? 'WHITE' : 'BLACK'}</Text></View><View style={styles.playerSpacer} /></View></GlassPanel>
        {settings.mode === 'computer' && <View style={styles.computerRewardPill} accessibilityLabel="Win bonus: 50 silver trophies">
          <GiftIcon />
          <Text style={styles.computerRewardLabel}>WIN BONUS</Text>
          <Text style={styles.computerRewardValue}>+50</Text>
          <TrophyIcon metal="silver" label="Silver trophy" size={25} showBackdrop={false} idPrefix="computer-win-bonus" />
          <Text style={styles.computerRewardCurrency}>SILVER</Text>
        </View>}
        <Board chess={chess} selected={selected} legal={legal} disabled={thinking || Boolean(promotion) || ended || !onlineCanPlay} playerColor={settings.playerColor} board={settings.board} tones={toneBySide} onSquare={chooseSquare} lastMove={lastMove} />
        <GlassPanel style={[styles.playerCard, settings.mode === 'online' && bottomAccent ? { borderColor: `${bottomAccent}99` } : null]}><View style={styles.playerRow}><View style={[styles.playerPiece, { backgroundColor: toneBySide[settings.playerColor], borderColor: bottomAccent ?? '#ffffff55' }]} /><View><Text style={[styles.playerName, bottomAccent ? { color: bottomAccent } : null]}>{bottomName}</Text><Text style={styles.playerColor}>{settings.playerColor === 'w' ? 'WHITE' : 'BLACK'}</Text></View><View style={styles.playerSpacer} /></View></GlassPanel>

        {(settings.mode === 'computer' || settings.mode === 'online') && <GlassPanel style={styles.helpCard}>
          <Pressable onPress={() => void requestMoveHint()} disabled={!canAskForHint || moveHintLoading} style={({ pressed }) => [styles.helpHeader, pressed && styles.pressed, (!canAskForHint || moveHintLoading) && styles.helpDisabled]} accessibilityRole="button" accessibilityLabel={moveHint ? 'Get another move hint' : 'Get chess help'} accessibilityState={{ disabled: !canAskForHint || moveHintLoading, busy: moveHintLoading }}>
            <View style={styles.helpBulb}><BulbIcon /></View>
            <View style={styles.helpHeadingCopy}>
              <Text style={styles.helpTitle}>Help with AI</Text>
              <Text style={styles.helpSubtitle}>{moveHintLoading ? 'Looking at the current board…' : canAskForHint ? 'Get a legal move and a simple explanation' : ended ? 'Start a new match to ask for a hint' : 'Move hints are ready on your turn'}</Text>
            </View>
            <View style={styles.helpAction}>
              <Text style={styles.helpActionText}>{moveHintLoading ? 'THINKING' : moveHint ? 'NEW HINT' : 'GET HINT'}</Text>
            </View>
          </Pressable>
          {moveHintLoading && <Text style={styles.helpLoadingText}>Checking the position and legal moves…</Text>}
          {moveHint && <View style={styles.hintResult}>
            <Text style={styles.hintEyebrow}>TRY THIS MOVE</Text>
            <Text style={styles.hintMove}>{moveHint.piece[0].toUpperCase() + moveHint.piece.slice(1)} · {moveHint.from} → {moveHint.to}</Text>
            <Text style={styles.hintNotation}>{moveHint.san}</Text>
            {moveHint.reasons.map((reason, index) => <View key={`${moveHint.san}-${index}`} style={styles.hintReasonRow}><Text style={styles.hintBullet}>•</Text><Text style={styles.hintReason}>{reason}</Text></View>)}
          </View>}
          {moveHintError ? <Text style={styles.helpError}>{moveHintError}</Text> : null}
        </GlassPanel>}

        {promotion && <GlassPanel style={styles.promotionPanel}><Text style={styles.promotionTitle}>Choose a promotion</Text><View style={styles.promotionChoices}>{(['q', 'r', 'b', 'n'] as const).map((type) => <Pressable key={type} onPress={() => commitMove(promotion.from, promotion.to, type)} style={styles.promotionButton}><GlassView pointerEvents="none" glassEffectStyle="regular" tintColor="#ffffff" style={[StyleSheet.absoluteFill, styles.promotionTint]} /><ChessPiece type={type} color={chess.turn()} tone={toneBySide[chess.turn()]} size={33} /><Text style={styles.promotionLabel}>{type.toUpperCase()}</Text></Pressable>)}</View></GlassPanel>}

        <Pressable onPress={() => { if (roomId) { router.replace('/online'); return; } setMoves([]); setSelected(null); setPromotion(null); setAiError(''); if (settings.mode === 'computer') { setAiTrophyMatchId(null); setAiTrophyStatus('idle'); setAiTrophyError(''); setAiTrophyStartAttempt((attempt) => attempt + 1); } }} style={({ pressed }) => [styles.newMatch, pressed && styles.pressed]} accessibilityRole="button">
          <GlassView pointerEvents="none" glassEffectStyle="regular" tintColor="#f8f6f0" style={[StyleSheet.absoluteFill, styles.newMatchTint]} />
          <View pointerEvents="none" style={styles.newMatchHighlight} />
          <View style={styles.newMatchContent}><Text style={styles.newMatchLabel}>{ended ? 'PLAY AGAIN' : 'NEW MATCH'}</Text><Text style={styles.newMatchIcon}>↻</Text></View>
        </Pressable>
        {roomId && onlineRoom && onlineUserId && !roomExpired && <ChessChat
          key={roomId}
          roomId={roomId}
          userId={onlineUserId}
          ownName={playerNameForColor(settings.playerColor)}
          opponentName={playerNameForColor(settings.playerColor === 'w' ? 'b' : 'w')}
        />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: screenCanvas },
  content: { alignItems: 'center', paddingHorizontal: 16, paddingTop: 5, paddingBottom: 30, backgroundColor: screenCanvas, minHeight: '100%' },
  header: { width: '100%', height: 43, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  back: { minWidth: 64, paddingVertical: 7 },
  backText: { color: '#26332d', fontSize: 12, fontWeight: '600' },
  brand: { color: '#596b60', fontSize: 10, fontWeight: '800', letterSpacing: 2 },
  mode: { color: '#77837c', fontSize: 9, letterSpacing: 1.1, minWidth: 64, textAlign: 'right' },
  glassPanel: { position: 'relative', overflow: 'hidden', borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,.92)', backgroundColor: 'rgba(255,255,255,.54)', shadowColor: '#69736b', shadowOpacity: 0.12, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  glassTint: { borderRadius: 18, backgroundColor: 'rgba(247,245,239,.48)' },
  glassHighlight: { position: 'absolute', top: 1, left: 4, right: 4, height: 23, borderTopLeftRadius: 17, borderTopRightRadius: 17, backgroundColor: 'rgba(255,255,255,.38)' },
  glassContent: { position: 'relative' },
  statusCard: { width: '100%', borderRadius: 18, padding: 14, marginTop: 10, marginBottom: 11 },
  resultCard: { borderColor: 'rgba(78,124,110,.55)', backgroundColor: 'rgba(220,237,225,.62)' },
  statusLabel: { color: '#738078', fontSize: 9, letterSpacing: 2, fontWeight: '700' },
  statusTopRow: { minHeight: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  soundToggle: { minHeight: 26, paddingHorizontal: 9, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(78,124,110,.28)', backgroundColor: 'rgba(255,255,255,.32)', alignItems: 'center', justifyContent: 'center' },
  soundToggleText: { color: '#52645a', fontSize: 8, letterSpacing: 1, fontWeight: '800' },
  status: { color: '#202a24', fontSize: 16, fontWeight: '700', marginTop: 5 },
  trophyStatus: { color: '#4e7c6e', fontSize: 10, fontWeight: '700', marginTop: 6 },
  trophyError: { color: '#a33b32', fontSize: 10, lineHeight: 14, marginTop: 6 },
  trophyRetry: { alignSelf: 'flex-start', minHeight: 30, justifyContent: 'center', paddingHorizontal: 10, marginTop: 6, borderRadius: 12, backgroundColor: 'rgba(78,124,110,.12)' },
  trophyRetryText: { color: '#4e7c6e', fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  levelTag: { color: '#4e7c6e', fontSize: 8, letterSpacing: 1.3, marginTop: 7, fontWeight: '800' },
  inviteCode: { color: '#53655a', fontSize: 10, letterSpacing: 1.6, fontWeight: '800', marginTop: 10 },
  shareButton: { minHeight: 37, paddingHorizontal: 15, borderRadius: 13, borderWidth: 1, borderColor: 'rgba(78,124,110,.42)', backgroundColor: 'rgba(78,124,110,.1)', alignItems: 'center', justifyContent: 'center', marginTop: 9 },
  shareButtonText: { color: '#344f41', fontSize: 10, letterSpacing: 1.4, fontWeight: '900' },
  playerCard: { width: '100%', maxWidth: 460, borderRadius: 18, marginBottom: 5 },
  playerRow: { width: '100%', height: 42, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 11 },
  playerPiece: { width: 28, height: 28, borderRadius: 14, borderColor: '#ffffff55', borderWidth: 1 },
  computerPill: { alignSelf: 'flex-start', minHeight: 18, justifyContent: 'center', paddingHorizontal: 8, borderRadius: 9, backgroundColor: '#202923' },
  computerPillText: { color: '#fff', fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  computerRewardPill: { width: '100%', maxWidth: 460, minHeight: 44, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 4, marginBottom: 8, paddingHorizontal: 12, borderRadius: 17, borderWidth: 1.4, borderColor: '#202923', backgroundColor: '#fffdf7' },
  computerRewardLabel: { color: '#68766d', fontSize: 8, fontWeight: '900', letterSpacing: 1 },
  computerRewardValue: { color: '#202923', fontSize: 17, fontWeight: '900', fontVariant: ['tabular-nums'] },
  computerRewardCurrency: { color: '#75818a', fontSize: 8, fontWeight: '900', letterSpacing: 0.8 },
  helpCard: { width: '100%', maxWidth: 460, borderRadius: 19, marginTop: 9, padding: 10, borderColor: 'rgba(193,141,45,.24)', backgroundColor: 'rgba(255,253,247,.72)' },
  helpHeader: { minHeight: 54, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 2 },
  helpBulb: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: '#f8f0dd', borderWidth: 1, borderColor: '#efdfb8' },
  helpHeadingCopy: { flex: 1, gap: 3 },
  helpTitle: { color: '#202923', fontSize: 13, fontWeight: '800', letterSpacing: -0.1 },
  helpSubtitle: { color: '#788078', fontSize: 9, lineHeight: 13 },
  helpAction: { minHeight: 28, justifyContent: 'center', borderRadius: 14, paddingHorizontal: 10, backgroundColor: '#202923' },
  helpActionText: { color: '#fff', fontSize: 8, fontWeight: '900', letterSpacing: 0.7 },
  helpDisabled: { opacity: 0.62 },
  helpLoadingText: { marginHorizontal: 4, marginTop: 5, paddingTop: 9, borderTopWidth: 1, borderTopColor: '#ebe7dc', color: '#69766c', fontSize: 10, fontWeight: '600' },
  hintResult: { marginTop: 5, padding: 11, borderRadius: 14, backgroundColor: 'rgba(248,246,240,.9)', borderWidth: 1, borderColor: '#eee8da' },
  hintEyebrow: { color: '#96712b', fontSize: 8, fontWeight: '900', letterSpacing: 1.25 },
  hintMove: { color: '#202923', fontSize: 15, fontWeight: '800', marginTop: 5 },
  hintNotation: { alignSelf: 'flex-start', marginTop: 5, borderRadius: 9, backgroundColor: '#eae5d8', paddingHorizontal: 8, paddingVertical: 3, color: '#657166', fontSize: 9, fontWeight: '800' },
  hintReasonRow: { flexDirection: 'row', gap: 6, marginTop: 8, alignItems: 'flex-start' },
  hintBullet: { color: '#b08027', fontSize: 13, lineHeight: 17, fontWeight: '900' },
  hintReason: { flex: 1, color: '#59665c', fontSize: 10, lineHeight: 15, fontWeight: '500' },
  helpError: { color: '#a33b32', fontSize: 10, lineHeight: 14, marginHorizontal: 4, marginTop: 7 },
  playerName: { color: '#202a24', fontSize: 12, fontWeight: '700' },
  playerColor: { color: '#77837c', fontSize: 8, letterSpacing: 1.7, marginTop: 2 },
  playerSpacer: { flex: 1 },
  boardFrame: { position: 'relative', overflow: 'hidden', borderWidth: 5, borderRadius: 10, backgroundColor: '#e9e6df' },
  square: { position: 'absolute', width: '12.5%', height: '12.5%', alignItems: 'center', justifyContent: 'center' },
  lastMoveSquare: { opacity: 0.82 },
  squarePressed: { opacity: 0.78 },
  selectedRing: { ...StyleSheet.absoluteFill, borderWidth: 3, borderColor: '#f6e4a6', backgroundColor: 'rgba(238,224,198,.2)' },
  legalDot: { width: 13, height: 13, borderRadius: 7, backgroundColor: 'rgba(18,28,22,.34)' },
  captureRing: { position: 'absolute', width: '88%', height: '88%', borderRadius: 99, borderWidth: 3, borderColor: 'rgba(18,28,22,.38)', backgroundColor: 'transparent' },
  rankMark: { position: 'absolute', left: 3, top: 2, fontSize: 8, fontWeight: '700' },
  fileMark: { position: 'absolute', right: 3, bottom: 1, fontSize: 8, fontWeight: '700' },
  movingPiece: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  promotionPanel: { width: '100%', borderRadius: 18, marginTop: 14, padding: 14 },
  promotionTitle: { color: '#202a24', fontSize: 12, fontWeight: '700', marginBottom: 8 },
  promotionChoices: { flexDirection: 'row', gap: 9 },
  promotionButton: { flex: 1, height: 65, borderRadius: 13, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,.92)', backgroundColor: 'rgba(255,255,255,.38)', alignItems: 'center', justifyContent: 'center' },
  promotionTint: { borderRadius: 13, backgroundColor: 'rgba(255,255,255,.34)' },
  promotionLabel: { color: '#738078', fontSize: 9, marginTop: -1 },
  newMatch: { position: 'relative', overflow: 'hidden', width: '100%', height: 56, backgroundColor: 'rgba(255,255,255,.38)', borderWidth: 1, borderColor: 'rgba(255,255,255,.96)', borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginTop: 13, shadowColor: '#647269', shadowOpacity: 0.13, shadowRadius: 9, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  newMatchTint: { borderRadius: 17, backgroundColor: 'rgba(247,245,239,.38)' },
  newMatchHighlight: { position: 'absolute', top: 1, left: 4, right: 4, height: 21, borderTopLeftRadius: 15, borderTopRightRadius: 15, backgroundColor: 'rgba(255,255,255,.46)' },
  newMatchContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12 },
  newMatchLabel: { color: '#111512', fontSize: 13, fontWeight: '900', letterSpacing: 2 },
  newMatchIcon: { color: '#111512', fontSize: 19 },
  chatSection: { width: '100%', marginTop: 18, marginBottom: 14 },
  chatHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, paddingHorizontal: 2 },
  chatEyebrow: { color: '#78877c', fontSize: 8, letterSpacing: 1.8, fontWeight: '900' },
  chatTitle: { color: '#202a24', fontSize: 19, letterSpacing: -0.45, fontWeight: '800', marginTop: 3 },
  chatLivePill: { minHeight: 25, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 14, borderWidth: 1, borderColor: '#dce6de', backgroundColor: 'rgba(255,255,255,.74)', paddingHorizontal: 9 },
  chatLiveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: green },
  chatLiveText: { color: '#617268', fontSize: 7, letterSpacing: 1.05, fontWeight: '900' },
  chatCanvas: { borderRadius: 24, borderWidth: 1, borderColor: '#e3ddd2', overflow: 'hidden', backgroundColor: '#f4f0e8', minHeight: 370 },
  chatBackgroundImage: { borderRadius: 24, opacity: 0.5 },
  chatCanvasWash: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(248,246,240,.38)' },
  chatMessages: { height: 245, maxHeight: 270 },
  chatMessagesContent: { paddingHorizontal: 12, paddingVertical: 13, gap: 9 },
  chatEmpty: { alignSelf: 'center', marginVertical: 38, borderRadius: 16, backgroundColor: 'rgba(255,255,255,.76)', paddingHorizontal: 14, paddingVertical: 9, color: '#64746a', fontSize: 11, fontWeight: '600' },
  chatMessageRow: { width: '100%', flexDirection: 'row', justifyContent: 'flex-start' },
  chatMessageRowMine: { justifyContent: 'flex-end' },
  chatMessageColumn: { maxWidth: '86%', alignItems: 'flex-start' },
  chatMessageColumnMine: { alignItems: 'flex-end' },
  chatBubble: { minWidth: 88, maxWidth: '100%', paddingHorizontal: 11, paddingTop: 8, paddingBottom: 9, borderRadius: 17, borderWidth: 1, shadowColor: '#382b1d', shadowOpacity: 0.06, shadowRadius: 5, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  chatBubbleFriend: { backgroundColor: 'rgba(255,255,255,.92)', borderColor: 'rgba(255,255,255,.95)', borderBottomLeftRadius: 6 },
  chatBubbleMine: { backgroundColor: '#4e7c6e', borderColor: '#4e7c6e', borderBottomRightRadius: 6 },
  chatBubbleSending: { opacity: 0.78 },
  chatMessageMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 13, marginBottom: 4 },
  chatSender: { color: '#627167', fontSize: 9, fontWeight: '800' },
  chatSenderMine: { color: '#e5f1e9' },
  chatTime: { color: '#929b94', fontSize: 8, fontWeight: '600' },
  chatTimeMine: { color: '#d1e0d7' },
  chatMessageText: { color: '#253129', fontSize: 13, lineHeight: 18, fontWeight: '700' },
  chatMessageTextMine: { color: '#fff' },
  chatSending: { color: '#718078', fontSize: 8, fontWeight: '600', marginTop: 4, alignSelf: 'flex-end' },
  chatSendingMine: { color: '#d1e0d7' },
  chatEmojiBubble: { color: '#202a24', fontSize: 33, lineHeight: 40, textAlign: 'center' },
  chatStickerBubble: { minWidth: 118, minHeight: 92, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(235,241,233,.92)', padding: 9 },
  chatStickerBubbleMine: { backgroundColor: 'rgba(255,255,255,.18)' },
  chatStickerArt: { fontSize: 35, lineHeight: 42 },
  chatStickerLabel: { color: '#52645a', fontSize: 9, fontWeight: '900', letterSpacing: 0.25, marginTop: 2 },
  chatStickerLabelMine: { color: '#fff' },
  chatReactions: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 4, marginLeft: 3 },
  chatReactionsMine: { justifyContent: 'flex-end', marginRight: 3 },
  chatReactionChip: { height: 23, minWidth: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 3, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(220,226,219,.9)', backgroundColor: 'rgba(255,255,255,.88)', paddingHorizontal: 6 },
  chatReactionSelected: { borderColor: '#8eb29d', backgroundColor: '#e6f0e9' },
  chatReactionEmoji: { fontSize: 12, lineHeight: 17 },
  chatReactionCount: { color: '#627167', fontSize: 8, fontWeight: '800' },
  chatError: { marginHorizontal: 11, marginTop: 5, color: '#a33b32', fontSize: 10, lineHeight: 14, fontWeight: '600' },
  chatComposerArea: { paddingHorizontal: 10, paddingTop: 8, paddingBottom: 10, backgroundColor: 'rgba(250,248,243,.77)', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,.8)' },
  chatQuickRow: { minHeight: 34, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 4, marginBottom: 7 },
  chatQuickEmoji: { width: 31, height: 31, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,.82)', borderWidth: 1, borderColor: 'rgba(223,228,222,.8)' },
  chatQuickEmojiText: { fontSize: 15 },
  chatStickerToggle: { height: 30, borderRadius: 15, paddingHorizontal: 9, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,.82)', borderWidth: 1, borderColor: '#dce6de' },
  chatStickerToggleOpen: { backgroundColor: '#e6f0e9', borderColor: '#a9c4b1' },
  chatStickerToggleText: { color: '#52645a', fontSize: 9, fontWeight: '800' },
  chatStickerTray: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 6, marginBottom: 8 },
  chatStickerOption: { width: '31.5%', minHeight: 60, alignItems: 'center', justifyContent: 'center', borderRadius: 15, borderWidth: 1, borderColor: 'rgba(222,228,221,.9)', backgroundColor: 'rgba(255,255,255,.89)', padding: 5 },
  chatStickerOptionEmoji: { fontSize: 22 },
  chatStickerOptionLabel: { color: '#5d6a61', fontSize: 8, fontWeight: '700', marginTop: 2, textAlign: 'center' },
  chatComposer: { minHeight: 43, flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 22, borderWidth: 1, borderColor: '#dfe5df', backgroundColor: 'rgba(255,255,255,.95)', paddingLeft: 13, paddingRight: 5 },
  chatInput: { flex: 1, minWidth: 0, minHeight: 40, color: '#26332d', fontSize: 12, fontWeight: '600', paddingVertical: 7, outlineColor: 'transparent', outlineWidth: 0 },
  chatSendButton: { width: 33, height: 33, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: green },
  chatSendDisabled: { backgroundColor: '#aebbb2' },
  chatSendText: { color: '#fff', fontSize: 21, lineHeight: 24, fontWeight: '800', marginTop: -2 },
  pressed: { opacity: 0.76 },
});
