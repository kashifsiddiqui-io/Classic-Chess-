-- Server-side daily awards use the same 06:00 Asia/Kolkata tracking-day boundary as the app.
create table if not exists public.player_daily_completions (
  user_id uuid not null references auth.users (id) on delete cascade,
  tracking_day date not null,
  source text not null check (source in ('chess', 'scribble')),
  completed_at timestamptz not null default now(),
  primary key (user_id, tracking_day)
);

alter table public.player_daily_completions enable row level security;
revoke all on public.player_daily_completions from anon, authenticated;
grant select on public.player_daily_completions to authenticated;
create policy "Players read their own completed days" on public.player_daily_completions
  for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.record_daily_game_completion(p_user_id uuid, p_source text, p_at timestamptz default clock_timestamp())
returns void language plpgsql security definer set search_path = '' as $$
declare day_key date;
begin
  if p_user_id is null or p_source not in ('chess', 'scribble') then return; end if;
  day_key := ((p_at at time zone 'Asia/Kolkata') - interval '6 hours')::date;
  insert into public.player_daily_completions (user_id, tracking_day, source)
    values (p_user_id, day_key, p_source)
    on conflict (user_id, tracking_day) do nothing;
end $$;

create or replace function public.record_finished_chess_room()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'finished' and old.status is distinct from 'finished' then
    perform public.record_daily_game_completion(new.host_id, 'chess', clock_timestamp());
    if new.guest_id is not null then perform public.record_daily_game_completion(new.guest_id, 'chess', clock_timestamp()); end if;
  end if;
  return new;
end $$;

create trigger chess_room_daily_completion
  after update of status on public.chess_rooms
  for each row execute function public.record_finished_chess_room();

create or replace function public.record_finished_scribble_room()
returns trigger language plpgsql security definer set search_path = '' as $$
declare player record;
begin
  if new.status = 'results' and old.status is distinct from 'results' then
    for player in select user_id from public.scribble_members where room_id = new.id and status = 'active' loop
      perform public.record_daily_game_completion(player.user_id, 'scribble', clock_timestamp());
    end loop;
  end if;
  return new;
end $$;

create trigger scribble_room_daily_completion
  after update of status on public.scribble_rooms
  for each row execute function public.record_finished_scribble_room();

revoke all on function public.record_daily_game_completion(uuid, text, timestamptz),
  public.record_finished_chess_room(), public.record_finished_scribble_room()
from public, anon, authenticated;
