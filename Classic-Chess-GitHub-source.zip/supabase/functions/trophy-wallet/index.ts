import { withSupabase } from '@supabase/server';
import { Chess } from 'chess.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

function validId(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

const userHandler = withSupabase({ auth: 'user' }, async (request, ctx) => {
  if (request.method !== 'POST') return json({ error: 'Use POST for trophy actions.' }, 405);
  const { data: userData, error: authError } = await ctx.supabase.auth.getUser();
  const user = userData.user;
  if (authError || !user || user.is_anonymous || !user.email_confirmed_at) {
    return json({ error: 'Verify your email or sign in with Google to play for trophies.' }, 401);
  }

  let body: { action?: unknown; playerColor?: unknown; matchId?: unknown; moves?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'The trophy request is not valid JSON.' }, 400);
  }

  if (body.action === 'start-ai') {
    if (body.playerColor !== 'w' && body.playerColor !== 'b') return json({ error: 'Choose a valid player color.' }, 400);
    const { data: matchId, error } = await ctx.supabase.rpc('start_trophy_ai_match', { p_player_color: body.playerColor });
    if (error || !validId(matchId)) return json({ error: 'Could not start trophy tracking for this match.' }, 500);
    return json({ matchId });
  }

  if (body.action === 'settle-ai') {
    if (!validId(body.matchId) || !Array.isArray(body.moves) || body.moves.length < 1 || body.moves.length > 300
      || !body.moves.every((move) => typeof move === 'string' && move.length > 0 && move.length <= 16)) {
      return json({ error: 'The completed match record is invalid.' }, 400);
    }
    const { data: match, error: matchError } = await ctx.supabaseAdmin.from('trophy_ai_matches')
      .select('user_id, player_color, status')
      .eq('id', body.matchId).maybeSingle();
    if (matchError || !match || match.user_id !== user.id) return json({ error: 'Trophy match not found.' }, 404);
    if (match.status === 'settled') {
      const { data: wallet } = await ctx.supabaseAdmin.from('trophy_wallets').select('silver, gold').eq('user_id', user.id).single();
      return json({ matchId: body.matchId, alreadySettled: true, wallet });
    }

    let chess: Chess;
    try {
      chess = new Chess();
      for (const san of body.moves as string[]) chess.move(san);
    } catch {
      return json({ error: 'The completed match contains an illegal move.' }, 400);
    }
    if (!chess.isGameOver()) return json({ error: 'The match is not finished yet.' }, 409);
    const result = chess.isCheckmate()
      ? (chess.turn() === match.player_color ? 'loss' : 'win')
      : 'draw';
    const { data: wallet, error: settleError } = await ctx.supabaseAdmin.rpc('settle_trophy_ai_match', {
      p_match_id: body.matchId,
      p_result: result,
    });
    if (settleError) return json({ error: 'Could not record the trophy result. Please try again.' }, 500);
    return json({ matchId: body.matchId, result, wallet });
  }

  return json({ error: 'Unknown trophy action.' }, 400);
});

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const response = await userHandler(request);
    const headers = new Headers(response.headers);
    Object.entries(corsHeaders).forEach(([name, value]) => headers.set(name, value));
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch {
    return json({ error: 'The trophy service is temporarily unavailable.' }, 500);
  }
});
