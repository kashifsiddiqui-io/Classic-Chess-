import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeInUp, useReducedMotion } from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as Linking from 'expo-linking';
import * as WebBrowser from 'expo-web-browser';
import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';

import { ChessPiece } from '@/components/chess-piece';
import { useAuth } from '@/context/auth';
import { clearPendingAuthProfile, completeAuthProfile, consumeAuthReturnTo, getAuthCallbackUrl, saveAuthReturnTo, savePendingAuthProfile } from '@/lib/auth-profile';
import { getSupabase } from '@/lib/supabase';

type Mode = 'signin' | 'signup';

function GoogleMark() {
  return <Svg width={20} height={20} viewBox="0 0 48 48" accessibilityLabel="Google">
    <Path fill="#4285F4" d="M43.6 24.5c0-1.4-.1-2.8-.4-4.1H24v7.8h11a9.4 9.4 0 0 1-4.1 6.2v5.1h6.7c3.9-3.6 6-8.9 6-15Z" />
    <Path fill="#34A853" d="M24 44c5.5 0 10.1-1.8 13.5-4.8l-6.7-5.1c-1.8 1.2-4.1 2-6.8 2-5.2 0-9.6-3.5-11.2-8.2H5.9v5.2A20 20 0 0 0 24 44Z" />
    <Path fill="#FBBC05" d="M12.8 27.9a12 12 0 0 1 0-7.7V15H5.9a20 20 0 0 0 0 17.9l6.9-5Z" />
    <Path fill="#EA4335" d="M24 12c3 0 5.7 1 7.8 3.1l5.9-5.9C34.1 5.9 29.5 4 24 4A20 20 0 0 0 5.9 15l6.9 5.2C14.4 15.5 18.8 12 24 12Z" />
  </Svg>;
}

export default function AuthScreen() {
  const params = useLocalSearchParams<{ returnTo?: string | string[]; profileSetup?: string | string[]; profileError?: string | string[] }>();
  const returnTo = Array.isArray(params.returnTo) ? params.returnTo[0] : params.returnTo;
  const profileSetup = (Array.isArray(params.profileSetup) ? params.profileSetup[0] : params.profileSetup) === '1';
  const profileError = Array.isArray(params.profileError) ? params.profileError[0] : params.profileError;
  const { user, loading: authLoading, error: authError } = useAuth();
  const reducedMotion = useReducedMotion();
  const [mode, setMode] = useState<Mode>(profileSetup ? 'signup' : 'signin');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [confirmGuestSwitch, setConfirmGuestSwitch] = useState(false);
  const activeMode: Mode = profileSetup ? 'signup' : mode;
  const profileSetupName = profileSetup && user
    ? typeof user.user_metadata?.display_name === 'string' ? user.user_metadata.display_name
      : typeof user.user_metadata?.full_name === 'string' ? user.user_metadata.full_name : ''
    : '';
  const profileSetupUsername = profileSetup && user && typeof user.user_metadata?.username === 'string'
    ? user.user_metadata.username : '';

  useEffect(() => { void saveAuthReturnTo(returnTo || '/'); }, [returnTo]);

  useEffect(() => {
    if (user && !user.is_anonymous && user.email_confirmed_at && !authLoading && !profileSetup) {
      router.replace((returnTo || '/') as never);
    }
  }, [authLoading, profileSetup, returnTo, user]);

  useEffect(() => {
    if (profileSetup && !authLoading && (!user || user.is_anonymous)) {
      router.replace({ pathname: '/auth', params: { returnTo: returnTo || '/' } });
    }
  }, [authLoading, profileSetup, returnTo, user]);

  function validateProfile(nameValue = name, usernameValue = username) {
    if (!nameValue.trim()) throw new Error('Enter your name.');
    if (!/^[a-zA-Z0-9._-]{3,20}$/.test(usernameValue.trim().replace(/^@/, ''))) {
      throw new Error('Username must be 3–20 characters using letters, numbers, dots, underscores or hyphens.');
    }
  }

  async function sendEmailLink(allowGuestSwitch = false) {
    const normalizedEmail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      setError('Enter a valid email address.');
      return;
    }
    const supabase = getSupabase();
    if (!supabase) {
      setError('Supabase is not configured. Add the project URL and publishable key to the app environment.');
      return;
    }
    setBusy(true);
    setError('');
    setMessage('');
    try {
      await saveAuthReturnTo(returnTo || '/');
      if (activeMode === 'signup') validateProfile();
      const redirectTo = getAuthCallbackUrl();
      const { data: current } = await supabase.auth.getSession();
      const isGuest = Boolean(current.session?.user.is_anonymous);

      if (activeMode === 'signup' && isGuest) {
        const { error: updateError } = await supabase.auth.updateUser({
          email: normalizedEmail,
          data: {
            display_name: name.trim().replace(/\s+/g, ' ').slice(0, 24),
            full_name: name.trim().replace(/\s+/g, ' ').slice(0, 24),
            username: username.trim().replace(/^@/, '').toLowerCase(),
          },
        }, { emailRedirectTo: redirectTo });
        if (updateError) throw new Error(updateError.message);
        setMessage(`Check ${normalizedEmail} and confirm the link to keep this player and its rooms.`);
      } else {
        if (isGuest && !allowGuestSwitch) {
          setConfirmGuestSwitch(true);
          return;
        }
        if (isGuest) {
          const { error: signOutError } = await supabase.auth.signOut({ scope: 'local' });
          if (signOutError) throw new Error(signOutError.message);
        }
        const { error: otpError } = await supabase.auth.signInWithOtp({
          email: normalizedEmail,
          options: {
            shouldCreateUser: activeMode === 'signup',
            emailRedirectTo: redirectTo,
            ...(activeMode === 'signup' ? { data: {
              display_name: name.trim().replace(/\s+/g, ' ').slice(0, 24),
              full_name: name.trim().replace(/\s+/g, ' ').slice(0, 24),
              username: username.trim().replace(/^@/, '').toLowerCase(),
            } } : {}),
          },
        });
        if (otpError) throw new Error(otpError.message);
        setMessage(`Secure sign-in link sent to ${normalizedEmail}. Open it on this device to continue.`);
      }
      setConfirmGuestSwitch(false);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not send your sign-in email. Try again.');
    } finally {
      setBusy(false);
    }
  }

  async function signInWithGoogle() {
    const supabase = getSupabase();
    if (!supabase) {
      setError('Supabase is not configured. Add the project URL and publishable key to the app environment.');
      return;
    }
    setBusy(true);
    setError('');
    setMessage('');
    try {
      await saveAuthReturnTo(returnTo || '/');
      if (activeMode === 'signup') {
        validateProfile();
        await savePendingAuthProfile(name, username);
      }
      const { data: sessionData } = await supabase.auth.getSession();
      const isGuest = Boolean(sessionData.session?.user.is_anonymous);
      const options = { redirectTo: getAuthCallbackUrl(), skipBrowserRedirect: true } as const;
      const { data, error: oauthError } = isGuest
        ? await supabase.auth.linkIdentity({ provider: 'google', options })
        : await supabase.auth.signInWithOAuth({ provider: 'google', options });
      if (oauthError) throw new Error(oauthError.message);
      if (!data.url) throw new Error('Google sign-in did not return an authorization link.');

      if (Capacitor.isNativePlatform()) {
        await Browser.open({ url: data.url });
        return;
      }
      if (Platform.OS === 'web') {
        window.location.assign(data.url);
        return;
      }
      const result = await WebBrowser.openAuthSessionAsync(data.url, getAuthCallbackUrl());
      if (result.type === 'success' && 'url' in result) {
        const callback = Linking.parse(result.url);
        const query = callback.queryParams ?? {};
        const code = typeof query.code === 'string' ? query.code : undefined;
        const tokenHash = typeof query.token_hash === 'string' ? query.token_hash : undefined;
        const otpType = typeof query.type === 'string' ? query.type : undefined;
        if (code) router.replace({ pathname: '/auth/callback', params: { code } });
        else if (tokenHash && otpType) router.replace({ pathname: '/auth/callback', params: { token_hash: tokenHash, type: otpType } });
        else throw new Error('Google returned without a sign-in code. Check your Supabase redirect URL settings.');
      } else {
        await clearPendingAuthProfile();
      }
    } catch (cause) {
      await clearPendingAuthProfile();
      const text = cause instanceof Error ? cause.message : 'Google sign-in could not be opened.';
      setError(/identity linking|linking.*enabled|manual linking/i.test(text)
        ? 'To keep this guest player’s rooms, enable Manual Identity Linking in Supabase Auth settings, then try Google again.'
        : /provider.*(not enabled|disabled)|unsupported provider/i.test(text)
          ? 'Google sign-in is not enabled for this Supabase project yet. Configure Google under Supabase Auth providers, then try again.'
          : text);
    } finally {
      setBusy(false);
    }
  }

  async function saveProfile() {
    if (!user || user.is_anonymous) return;
    const supabase = getSupabase();
    if (!supabase) { setError('Supabase is not configured.'); return; }
    setBusy(true);
    setError('');
    try {
      const profileName = name || profileSetupName;
      const profileUsername = username || profileSetupUsername;
      validateProfile(profileName, profileUsername);
      await completeAuthProfile(supabase, user, { name: profileName, username: profileUsername.trim().replace(/^@/, '').toLowerCase(), savedAt: Date.now() });
      const destination = await consumeAuthReturnTo();
      router.replace(destination as never);
    } catch (cause) {
      const text = cause instanceof Error ? cause.message : 'Could not save your profile.';
      setError(text.startsWith('USERNAME_TAKEN:') ? 'That username is already in use. Choose another one.' : text);
    } finally {
      setBusy(false);
    }
  }

  const guest = Boolean(user?.is_anonymous);

  return <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
    <StatusBar style="dark" animated />
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Animated.View entering={reducedMotion ? undefined : FadeInDown.duration(230).delay(20)} style={styles.brandRow}>
          <View style={styles.brandTile}><ChessPiece type="k" color="w" tone="pearl" size={30} /></View>
          <Text style={styles.brand}>CLASSIC CHESS</Text>
        </Animated.View>
        <Animated.Text entering={reducedMotion ? undefined : FadeIn.duration(200).delay(55)} style={styles.kicker}>YOUR NEXT MOVE STARTS HERE</Animated.Text>
        <Animated.Text key={`auth-title-${activeMode}`} entering={reducedMotion ? undefined : FadeInUp.duration(260).delay(95)} style={styles.title}>{activeMode === 'signin' ? 'Welcome back' : 'Create your player'}</Animated.Text>
        <Animated.Text key={`auth-subtitle-${activeMode}`} entering={reducedMotion ? undefined : FadeInUp.duration(250).delay(135)} style={styles.subtitle}>{activeMode === 'signin' ? 'Sign in to save your name and play with friends.' : 'Set your name and username, then verify your email.'}</Animated.Text>

        <Animated.View entering={reducedMotion ? undefined : FadeInUp.duration(300).delay(150)} style={styles.form}>
          {!profileSetup && <View style={styles.modeRow}>
            <Pressable onPress={() => { setMode('signin'); setMessage(''); setError(''); setConfirmGuestSwitch(false); }} style={[styles.modeButton, mode === 'signin' && styles.modeSelected]} accessibilityRole="tab" accessibilityState={{ selected: mode === 'signin' }}>
              <Text style={[styles.modeText, activeMode === 'signin' && styles.modeTextSelected]}>Sign in</Text>
            </Pressable>
            <Pressable onPress={() => { setMode('signup'); setMessage(''); setError(''); setConfirmGuestSwitch(false); }} style={[styles.modeButton, mode === 'signup' && styles.modeSelected]} accessibilityRole="tab" accessibilityState={{ selected: mode === 'signup' }}>
              <Text style={[styles.modeText, activeMode === 'signup' && styles.modeTextSelected]}>Sign up</Text>
            </Pressable>
          </View>}

          {activeMode === 'signup' && <Animated.View entering={reducedMotion ? undefined : FadeInUp.duration(220).delay(35)}>
            <Text style={styles.label}>NAME</Text>
            <TextInput value={name || profileSetupName} onChangeText={(value) => { setName(value.slice(0, 24)); setError(''); }} placeholder="Your display name" placeholderTextColor="#8f9a93" autoCapitalize="words" autoCorrect={false} maxLength={24} style={styles.input} accessibilityLabel="Display name" />
            <Text style={styles.label}>USERNAME</Text>
            <TextInput value={username || profileSetupUsername} onChangeText={(value) => { setUsername(value.replace(/\s/g, '').slice(0, 20)); setError(''); }} placeholder="Choose a username" placeholderTextColor="#8f9a93" autoCapitalize="none" autoCorrect={false} maxLength={20} style={styles.input} accessibilityLabel="Username" />
          </Animated.View>}

          <Text style={styles.label}>EMAIL</Text>
          <TextInput value={email} onChangeText={(value) => { setEmail(value); setError(''); setConfirmGuestSwitch(false); }} placeholder="you@example.com" placeholderTextColor="#8f9a93" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} textContentType="emailAddress" style={styles.input} accessibilityLabel="Email address" />
          <Text style={styles.helper}>{activeMode === 'signin' ? 'Your saved name and username load after verification. We’ll send a secure link; no password required.' : 'Your email link verifies ownership. No password required.'}</Text>

          {guest && <View style={styles.guestNote}><Text style={styles.guestNoteText}>You’re using a guest player. Create an account to keep this player and its rooms on this device.</Text></View>}
          {profileSetup && <View style={styles.guestNote}><Text style={styles.guestNoteText}>{profileError === 'username' ? 'That username is already in use. Choose a different one.' : 'Choose a username that is not already used by another player.'}</Text></View>}

          {confirmGuestSwitch && <View style={styles.confirmBox}>
            <Text style={styles.confirmText}>Signing in to another account will switch away from this guest player. Create an account to preserve its rooms.</Text>
            <View style={styles.confirmActions}>
              <Pressable onPress={() => setConfirmGuestSwitch(false)} style={styles.confirmCancel}><Text style={styles.confirmCancelText}>CANCEL</Text></Pressable>
              <Pressable onPress={() => void sendEmailLink(true)} disabled={busy} style={styles.confirmContinue}><Text style={styles.confirmContinueText}>SWITCH ACCOUNT</Text></Pressable>
            </View>
          </View>}

          {!!error && <Text style={styles.error} accessibilityRole="alert">{error}</Text>}
          {!!authError && !error && <Text style={styles.error} accessibilityRole="alert">{authError}</Text>}
          {!!message && <Text style={styles.success} accessibilityRole="status">{message}</Text>}

          <Pressable onPress={() => void (profileSetup ? saveProfile() : sendEmailLink())} disabled={busy || authLoading} style={({ pressed }) => [styles.submit, pressed && styles.pressed, (busy || authLoading) && styles.disabled]} accessibilityRole="button">
            <Text style={styles.submitText}>{busy ? 'PLEASE WAIT…' : profileSetup ? 'SAVE PLAYER PROFILE' : activeMode === 'signin' ? 'SEND SIGN-IN LINK' : 'CREATE ACCOUNT'}</Text>
          </Pressable>

          {!profileSetup && <>
            <View style={styles.divider}><View style={styles.rule} /><Text style={styles.or}>OR CONTINUE WITH</Text><View style={styles.rule} /></View>
            <Pressable onPress={() => void signInWithGoogle()} disabled={busy || authLoading} style={({ pressed }) => [styles.googleButton, pressed && styles.pressed, (busy || authLoading) && styles.disabled]} accessibilityRole="button">
              <GoogleMark /><Text style={styles.googleText}>{busy ? 'OPENING GOOGLE…' : 'Continue with Google'}</Text>
            </Pressable>
          </>}
        </Animated.View>
        <Animated.Text entering={reducedMotion ? undefined : FadeIn.duration(240).delay(260)} style={styles.privacy}>Your name and username are saved to your player profile. Email verification secures account access.</Animated.Text>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f4f3ef' },
  flex: { flex: 1 },
  content: { flexGrow: 1, width: '100%', maxWidth: 480, alignSelf: 'center', justifyContent: 'center', paddingHorizontal: 23, paddingTop: 24, paddingBottom: 30 },
  brandRow: { minHeight: 54, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 21, paddingHorizontal: 9, paddingVertical: 8, borderRadius: 17, backgroundColor: '#4e7c6e', shadowColor: '#345747', shadowOpacity: 0.2, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 4 },
  brandTile: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#806047', alignItems: 'center', justifyContent: 'center' },
  brand: { color: '#fff', fontSize: 9, fontWeight: '900', letterSpacing: 2 },
  kicker: { color: '#668476', fontSize: 9, fontWeight: '900', letterSpacing: 2.1 },
  title: { color: '#1e2b25', fontSize: 31, fontWeight: '900', letterSpacing: -0.9, marginTop: 7 },
  subtitle: { color: '#69756e', fontSize: 13, lineHeight: 19, marginTop: 5, marginBottom: 19 },
  form: { borderRadius: 25, borderWidth: 1, borderColor: '#e3e6e1', backgroundColor: '#fff', padding: 18, shadowColor: '#263c31', shadowOpacity: 0.13, shadowRadius: 22, shadowOffset: { width: 0, height: 9 }, elevation: 5 },
  modeRow: { height: 43, flexDirection: 'row', borderRadius: 14, backgroundColor: '#f1f4f1', padding: 3, marginBottom: 15 },
  modeButton: { flex: 1, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  modeSelected: { backgroundColor: '#fff', shadowColor: '#364c3f', shadowOpacity: 0.08, shadowRadius: 5, shadowOffset: { width: 0, height: 1 }, elevation: 1 },
  modeText: { color: '#7c8880', fontSize: 12, fontWeight: '700' },
  modeTextSelected: { color: '#315c4a' },
  label: { color: '#394941', fontSize: 9, fontWeight: '900', letterSpacing: 1.45, marginTop: 10 },
  input: { height: 49, borderWidth: 1, borderColor: '#d9e0db', borderRadius: 13, backgroundColor: '#fafbf9', color: '#1f2c26', fontSize: 14, paddingHorizontal: 13, marginTop: 7 },
  helper: { color: '#849087', fontSize: 10, marginTop: 8, lineHeight: 14 },
  guestNote: { borderRadius: 12, padding: 10, backgroundColor: '#edf4ef', marginTop: 12 },
  guestNoteText: { color: '#486554', fontSize: 10, lineHeight: 15, fontWeight: '600' },
  confirmBox: { borderRadius: 13, padding: 11, backgroundColor: '#fff7e8', borderWidth: 1, borderColor: '#f0dfbc', marginTop: 12 },
  confirmText: { color: '#72582b', fontSize: 10, lineHeight: 15 },
  confirmActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8, marginTop: 9 },
  confirmCancel: { minHeight: 34, borderRadius: 10, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' },
  confirmCancelText: { color: '#76664c', fontSize: 9, fontWeight: '800' },
  confirmContinue: { minHeight: 34, borderRadius: 10, paddingHorizontal: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#6e6a5f' },
  confirmContinueText: { color: '#fff', fontSize: 8, fontWeight: '900', letterSpacing: 0.5 },
  submit: { height: 50, borderRadius: 14, backgroundColor: '#4e7c6e', alignItems: 'center', justifyContent: 'center', marginTop: 15 },
  submitText: { color: '#fff', fontSize: 10, fontWeight: '900', letterSpacing: 1.4 },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 16 },
  rule: { height: 1, flex: 1, backgroundColor: '#e7ebe7' },
  or: { color: '#909a93', fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  googleButton: { height: 49, borderWidth: 1, borderColor: '#d9e0db', borderRadius: 13, backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  googleText: { color: '#26342c', fontSize: 12, fontWeight: '700' },
  error: { borderRadius: 11, overflow: 'hidden', backgroundColor: '#fcece8', color: '#a13e35', padding: 10, marginTop: 10, fontSize: 10, lineHeight: 15 },
  success: { borderRadius: 11, overflow: 'hidden', backgroundColor: '#edf5ef', color: '#426a50', padding: 10, marginTop: 10, fontSize: 10, lineHeight: 15 },
  privacy: { color: '#859088', fontSize: 9, lineHeight: 14, textAlign: 'center', marginTop: 16, paddingHorizontal: 7 },
  disabled: { opacity: 0.55 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.99 }] },
});
