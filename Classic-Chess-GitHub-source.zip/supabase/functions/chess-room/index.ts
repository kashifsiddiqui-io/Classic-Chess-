import { withSupabase } from '@supabase/server';
import { Chess } from 'chess.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

const inviteAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const pieceTones = { w: ['pearl', 'silver', 'gold'], b: ['onyx', 'emerald', 'sapphire'] } as const;

type Side = keyof typeof pieceTones;
type PlayerInput = { name: string; pieceTone: string; accentColor: string; showName: boolean };

function makeInviteCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  return Array.from(bytes, (byte) => inviteAlphabet[byte % inviteAlphabet.length]).join('');
}

function validRoomId(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function parsePlayerInput(body: Record<string, unknown>, side: Side): PlayerInput | null {
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const pieceTone = body.pieceTone;
  const accentColor = body.accentColor;
  const showName = body.showName;
  if (name.length < 1 || name.length > 24 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  if (typeof pieceTone !== 'string' || !(pieceTones[side] as readonly string[]).includes(pieceTone)) return null;
  if (typeof accentColor !== 'string' || !/^#[0-9a-f]{6}$/i.test(accentColor)) return null;
  if (typeof showName !== 'boolean') return null;
  return { name, pieceTone, accentColor: accentColor.toLowerCase(), showName };
}

function validInviteCode(value: unknown): value is string {
  return typeof value === 'string' && /^[A-HJ-NP-Z2-9]{8}$/.test(value);
}

const userHandler = withSupabase({ auth: 'user' }, async (request, ctx) => {
  if (request.method !== 'POST') return json({ error: 'Use POST for match actions.' }, 405);

  const { data: userData, error: authError } = await ctx.supabase.auth.getUser();
  const user = userData.user;
  if (authError || !user || user.is_anonymous || !user.email_confirmed_at) {
    return json({ error: 'Verify your email or sign in with Google before opening a room.' }, 401);
  }

  let body: { action?: unknown; code?: unknown; roomId?: unknown; move?: unknown; name?: unknown; pieceTone?: unknown; accentColor?: unknown; showName?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'The match request is not valid JSON.' }, 400);
  }

  if (body.action === 'create') {
    const profile = parsePlayerInput(body, 'w');
    if (!profile) return json({ error: 'Choose a valid name and appearance before creating a room.' }, 400);
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const { data: room, error } = await ctx.supabaseAdmin.from('chess_rooms').insert({
        invite_code: makeInviteCode(),
        host_id: user.id,
        host_name: profile.name,
        host_piece_tone: profile.pieceTone,
        host_accent_color: profile.accentColor,
        host_show_name: profile.showName,
      }).select('*').single();
      if (!error && room) return json({ room });
      if (error?.code !== '23505') return json({ error: 'Could not create a match. Try again.' }, 500);
    }
    return json({ error: 'Could not create a unique invite code. Try again.' }, 503);
  }

  if (body.action === 'preview' || body.action === 'join') {
    const code = typeof body.code === 'string' ? body.code.trim().toUpperCase() : '';
    if (!validInviteCode(code)) return json({ error: 'Enter the 8-character invite code.' }, 400);

    const { data: found, error: findError } = await ctx.supabaseAdmin.from('chess_rooms')
      .select('*').eq('invite_code', code).maybeSingle();
    if (findError) return json({ error: 'Could not check this room. Try again.' }, 500);
    if (!found) return json({ error: 'This room link is invalid. Please ask for a new invite.' }, 404);
    if (found.expires_at && new Date(found.expires_at).getTime() <= Date.now()) {
      await ctx.supabaseAdmin.from('chess_rooms').delete().eq('id', found.id).lte('expires_at', new Date().toISOString());
      return json({ error: 'This room link has expired. Please create a new room.' }, 410);
    }
    if (found.status !== 'waiting' || found.guest_id) return json({ error: 'This room already has two players or has ended.' }, 409);
    if (body.action === 'preview') {
      return json({ preview: {
        host_name: found.host_name,
        host_piece_tone: found.host_piece_tone,
        host_accent_color: found.host_accent_color,
        host_show_name: found.host_show_name,
        expires_at: found.expires_at,
      } });
    }

    const profile = parsePlayerInput(body, 'b');
    if (!profile) return json({ error: 'Choose a valid name and appearance before joining.' }, 400);
    if (found.host_id === user.id) return json({ error: 'Open this match from the device that created it.' }, 409);

    let room = found;
    if (!found.guest_id) {
      const { data: joined, error: joinError } = await ctx.supabaseAdmin.from('chess_rooms')
        .update({
          guest_id: user.id,
          guest_name: profile.name,
          guest_piece_tone: profile.pieceTone,
          guest_accent_color: profile.accentColor,
          guest_show_name: profile.showName,
          status: 'active',
          expires_at: null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', found.id).is('guest_id', null).eq('status', 'waiting').gt('expires_at', new Date().toISOString()).select('*').maybeSingle();
      if (joinError) return json({ error: 'Could not join the match. Try again.' }, 500);
      if (joined) room = joined;
      else {
        const { data: current } = await ctx.supabaseAdmin.from('chess_rooms').select('*').eq('id', found.id).maybeSingle();
        if (current?.expires_at && new Date(current.expires_at).getTime() <= Date.now()) {
          await ctx.supabaseAdmin.from('chess_rooms').delete().eq('id', current.id).lte('expires_at', new Date().toISOString());
          return json({ error: 'This room link has expired. Please create a new room.' }, 410);
        }
        if (!current || current.guest_id !== user.id) return json({ error: 'That room already has two players.' }, 409);
        room = current;
      }
    }
    return json({ room });
  }

  if (body.action === 'move') {
    if (!validRoomId(body.roomId) || typeof body.move !== 'string' || body.move.length > 12) {
      return json({ error: 'The move request is invalid.' }, 400);
    }
    const { data: room, error: roomError } = await ctx.supabaseAdmin.from('chess_rooms').select('*').eq('id', body.roomId).maybeSingle();
    if (roomError || !room) return json({ error: 'Match not found.' }, 404);
    if (room.host_id !== user.id && room.guest_id !== user.id) return json({ error: 'You are not a player in this match.' }, 403);
    if (room.expires_at && new Date(room.expires_at).getTime() <= Date.now()) {
      await ctx.supabaseAdmin.from('chess_rooms').delete().eq('id', room.id).lte('expires_at', new Date().toISOString());
      return json({ error: 'This room link has expired. Please create a new room.' }, 410);
    }
    if (room.status !== 'active') return json({ error: 'Wait for the other player to join.' }, 409);

    try {
      const chess = new Chess();
      for (const san of room.moves as string[]) chess.move(san);
      const expectedPlayer = chess.turn() === 'w' ? room.host_id : room.guest_id;
      if (expectedPlayer !== user.id) return json({ error: 'It is the other player’s turn.' }, 409);
      const move = chess.move(body.move);
      if (!move) return json({ error: 'That move is not legal.' }, 400);
      const winnerId = chess.isCheckmate() ? (move.color === 'w' ? room.host_id : room.guest_id) : null;
      const { data: updated, error: updateError } = await ctx.supabaseAdmin.rpc('append_chess_move', {
        p_room_id: room.id,
        p_player_id: user.id,
        p_expected_ply: room.ply,
        p_san: move.san,
        p_finished: chess.isGameOver(),
        p_winner_id: winnerId,
      });
      if (updateError) {
        if (updateError.message.toLowerCase().includes('expired')) {
          await ctx.supabaseAdmin.from('chess_rooms').delete().eq('id', room.id).lte('expires_at', new Date().toISOString());
          return json({ error: 'This room link has expired. Please create a new room.' }, 410);
        }
        return json({ error: updateError.code === '40001' ? 'The board changed. Refresh and try your move again.' : 'Could not save that move. Try again.' }, 409);
      }
      return json({ room: updated });
    } catch {
      return json({ error: 'The match data is invalid. Return to the menu and start a new match.' }, 500);
    }
  }

  return json({ error: 'Unknown match action.' }, 400);
});

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const response = await userHandler(request);
    const headers = new Headers(response.headers);
    Object.entries(corsHeaders).forEach(([name, value]) => headers.set(name, value));
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  } catch {
    return json({ error: 'The match service is temporarily unavailable.' }, 500);
  }
});
