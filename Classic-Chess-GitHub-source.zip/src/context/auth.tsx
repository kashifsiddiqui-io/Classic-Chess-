import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { User } from '@supabase/supabase-js';

import { getSupabase } from '@/lib/supabase';

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  error: string;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const initialSessionVerified = useRef(false);

  const refresh = useCallback(async () => {
    await Promise.resolve();
    try {
      const supabase = getSupabase();
      if (!supabase) {
        setUser(null);
        setError('Supabase is not configured. Add the project URL and publishable key to the app environment.');
        setLoading(false);
        return;
      }

      setLoading(true);
      const { data, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!data.session) {
        setUser(null);
        setError('');
        setLoading(false);
        return;
      }

      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      setUser(userData.user);
      setError('');
      setLoading(false);
    } catch (cause) {
      setUser(null);
      setError(cause instanceof Error ? cause.message : 'Could not verify your account session. Check your connection and retry.');
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const supabase = getSupabase();
    if (!supabase) {
      const timer = setTimeout(() => {
        setUser(null);
        setError('Supabase is not configured. Add the project URL and publishable key to the app environment.');
        setLoading(false);
      }, 0);
      return () => clearTimeout(timer);
    }

    let mounted = true;
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted || !initialSessionVerified.current) return;
      setUser(session?.user ?? null);
      setError('');
      setLoading(false);
    });
    const verifyTimer = setTimeout(() => {
      void refresh().finally(() => { initialSessionVerified.current = true; });
    }, 0);
    return () => {
      mounted = false;
      clearTimeout(verifyTimer);
      subscription.unsubscribe();
    };
  }, [refresh]);

  const value = useMemo(() => ({ user, loading, error, refresh }), [user, loading, error, refresh]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used within AuthProvider');
  return value;
}
