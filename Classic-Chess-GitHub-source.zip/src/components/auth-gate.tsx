import { Redirect, useGlobalSearchParams, usePathname, useSegments } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import type { ReactNode } from 'react';

import { useAuth } from '@/context/auth';

function currentPath(pathname: string, params: Record<string, string | string[] | undefined>) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || key === 'returnTo') return;
    if (Array.isArray(value)) value.forEach((item) => query.append(key, item));
    else query.set(key, value);
  });
  const serialized = query.toString();
  return `${pathname || '/'}${serialized ? `?${serialized}` : ''}`;
}

export function AuthGate({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const segments = useSegments();
  const pathname = usePathname();
  const params = useGlobalSearchParams<Record<string, string | string[] | undefined>>();
  const insideAuth = segments[0] === 'auth';

  if (insideAuth) return children;
  if (loading) return <View style={styles.loading}><ActivityIndicator color="#4e7c6e" size="small" /></View>;
  if (!user || user.is_anonymous || !user.email_confirmed_at) {
    const returnTo = currentPath(pathname, params);
    return <Redirect href={{ pathname: '/auth', params: { returnTo } }} />;
  }
  return children;
}

const styles = StyleSheet.create({ loading: { flex: 1, backgroundColor: '#f7f7f4', alignItems: 'center', justifyContent: 'center' } });
