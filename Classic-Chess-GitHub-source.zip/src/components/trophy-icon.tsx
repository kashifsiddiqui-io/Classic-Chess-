import Svg, { Circle, Defs, LinearGradient, Path, Stop } from 'react-native-svg';

type TrophyIconProps = {
  metal: 'silver' | 'gold';
  label: string;
  size?: number;
  showBackdrop?: boolean;
  idPrefix: string;
};

export function TrophyIcon({ metal, label, size = 62, showBackdrop = true, idPrefix }: TrophyIconProps) {
  const id = `${idPrefix}-trophy-${metal}`;
  const colors = metal === 'silver'
    ? ['#f8fbfc', '#b9c5cc', '#77858d']
    : ['#fff3c5', '#e7b84f', '#a87522'];

  return <Svg width={size} height={size} viewBox="0 0 64 64" accessibilityLabel={label}>
    <Defs>
      <LinearGradient id={id} x1="0" y1="0" x2="1" y2="1">
        <Stop offset="0" stopColor={colors[0]} />
        <Stop offset="0.5" stopColor={colors[1]} />
        <Stop offset="1" stopColor={colors[2]} />
      </LinearGradient>
    </Defs>
    {showBackdrop && <Circle cx="32" cy="32" r="31" fill={metal === 'silver' ? '#edf2f4' : '#fbf3df'} />}
    <Path d="M20 13h24v8c0 11-4.9 17-12 17s-12-6-12-17v-8Z" fill={`url(#${id})`} stroke={colors[2]} strokeWidth="1.2" />
    <Path d="M20 17h-7v5c0 7 4 11 11 11m20-16h7v5c0 7-4 11-11 11" fill="none" stroke={colors[2]} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <Path d="M29 38v8h-7v5h20v-5h-7v-8" fill={`url(#${id})`} stroke={colors[2]} strokeWidth="1.2" strokeLinejoin="round" />
    <Path d="m32 18 1.8 4.1 4.5.4-3.4 3 1 4.4-3.9-2.3-3.9 2.3 1-4.4-3.4-3 4.5-.4L32 18Z" fill="#fff" opacity="0.9" />
    <Path d="M23 16v10" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" opacity="0.7" />
  </Svg>;
}
