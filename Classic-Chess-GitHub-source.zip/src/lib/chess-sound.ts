import { useAudioPlayer } from 'expo-audio';
import { useCallback, useState } from 'react';

export function useChessMoveSound() {
  const player = useAudioPlayer(require('../../assets/audio/chess-move.mp3'));
  const [unavailable, setUnavailable] = useState(false);

  const play = useCallback(() => {
    void player.seekTo(0)
      .then(() => player.play())
      .catch(() => setUnavailable(true));
  }, [player]);

  return { play, unavailable };
}
