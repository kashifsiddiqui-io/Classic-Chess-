import { usePathname } from 'expo-router';
import { createElement, useEffect, useRef, useState } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import Animated, { interpolate, useAnimatedStyle, useReducedMotion, useSharedValue, withDelay, withRepeat, withTiming } from 'react-native-reanimated';

import './route-transition-loader.css';

const scribbleBlue = '#4775b7';
let nextTransitionIsScribble = false;

export function markScribbleTransition() {
  nextTransitionIsScribble = true;
}

function consumeScribbleTransition() {
  const isScribbleTransition = nextTransitionIsScribble;
  nextTransitionIsScribble = false;
  return isScribbleTransition;
}

function LiquidDot({ index, color }: { index: number; color: string }) {
  const progress = useSharedValue(0);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    if (reduceMotion) return;
    progress.value = withDelay(index * 110, withRepeat(withTiming(1, { duration: 620 }), -1, true));
  }, [index, progress, reduceMotion]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: reduceMotion ? 1 : interpolate(progress.value, [0, 0.5, 1], [0.72, 1, 0.72]),
    transform: [
      { translateY: reduceMotion ? 0 : interpolate(progress.value, [0, 0.5, 1], [0, -5, 0]) },
      { scaleX: reduceMotion ? 1 : interpolate(progress.value, [0, 0.5, 1], [1, 1.35, 1]) },
      { scaleY: reduceMotion ? 1 : interpolate(progress.value, [0, 0.5, 1], [1, 0.88, 1]) },
    ],
  }));

  return <Animated.View style={[styles.dot, { left: 17 + index * 15, backgroundColor: color }, animatedStyle]} />;
}

/** Brief route-change feedback; it is intentionally separate from network loading states. */
export function RouteTransitionLoader() {
  const pathname = usePathname();
  const lastPath = useRef(pathname);
  const hideTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [visible, setVisible] = useState(true);
  const [scribbleTransition, setScribbleTransition] = useState(false);

  useEffect(() => {
    if (lastPath.current !== pathname) {
      lastPath.current = pathname;
      setVisible(true);
      const wasRequestedFromScribbleCard = consumeScribbleTransition();
      setScribbleTransition(pathname === '/scribble' && wasRequestedFromScribbleCard);
    }

    if (hideTimeout.current) clearTimeout(hideTimeout.current);
    hideTimeout.current = setTimeout(() => setVisible(false), 680);
    return () => {
      if (hideTimeout.current) clearTimeout(hideTimeout.current);
    };
  }, [pathname]);

  if (!visible) return null;

  if (Platform.OS === 'web') {
    return createElement(
      'div',
      { className: 'route-transition-layer', role: 'status', 'aria-label': 'Opening page' },
      createElement(
        'div',
        { className: 'loader' },
        ...Array.from({ length: 9 }, (_, index) => createElement('div', { className: 'square', id: `sq${index + 1}`, key: index, style: scribbleTransition ? { backgroundColor: scribbleBlue } : undefined })),
      ),
    );
  }

  return (
    <View style={styles.backdrop} pointerEvents="none" accessibilityRole="progressbar" accessibilityLabel="Opening page">
      <View style={styles.loaderCard}>
        <View style={styles.blobTrack}>
          {Array.from({ length: 5 }, (_, index) => <LiquidDot key={index} index={index} color={scribbleTransition ? scribbleBlue : '#4e7c6e'} />)}
        </View>
        <Text style={[styles.label, scribbleTransition && styles.scribbleLabel]}>OPENING</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  backdrop: { ...StyleSheet.absoluteFill, zIndex: 1000, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(247,247,244,0.62)' },
  loaderCard: { width: 152, height: 112, borderRadius: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.96)', borderWidth: 1, borderColor: '#e1e9e3', shadowColor: '#23392e', shadowOpacity: 0.16, shadowRadius: 20, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  blobTrack: { width: 94, height: 34, position: 'relative', alignItems: 'center', justifyContent: 'center' },
  dot: { position: 'absolute', top: 8, width: 19, height: 19, borderRadius: 10, backgroundColor: '#4e7c6e' },
  label: { color: '#52685b', fontSize: 9, fontWeight: '800', letterSpacing: 2, marginTop: 9 },
  scribbleLabel: { color: scribbleBlue },
});
