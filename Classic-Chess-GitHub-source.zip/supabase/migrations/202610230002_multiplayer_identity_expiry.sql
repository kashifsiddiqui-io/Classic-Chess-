alter table public.chess_rooms
  add column host_name text not null default 'Player 1',
  add column guest_name text,
  add column host_piece_tone text not null default 'pearl',
  add column guest_piece_tone text not null default 'onyx',
  add column host_accent_color text not null default '#4e7c6e',
  add column guest_accent_color text not null default '#5277ad',
  add column host_show_name boolean not null default true,
  add column guest_show_name boolean not null default true;

alter table public.chess_rooms
  alter column expires_at set default (now() + interval '10 minutes'),
  add constraint chess_rooms_host_name_length check (char_length(btrim(host_name)) between 1 and 24),
  add constraint chess_rooms_guest_name_length check (guest_name is null or char_length(btrim(guest_name)) between 1 and 24),
  add constraint chess_rooms_host_tone_valid check (host_piece_tone in ('pearl', 'silver', 'gold')),
  add constraint chess_rooms_guest_tone_valid check (guest_piece_tone in ('onyx', 'emerald', 'sapphire')),
  add constraint chess_rooms_host_accent_valid check (host_accent_color ~ '^#[0-9A-Fa-f]{6}$'),
  add constraint chess_rooms_guest_accent_valid check (guest_accent_color ~ '^#[0-9A-Fa-f]{6}$');

-- Existing rooms keep their original server creation time and expire ten minutes after it.
update public.chess_rooms
set expires_at = created_at + interval '10 minutes';

create extension if not exists pg_cron;

select cron.unschedule(jobid)
from cron.job
where jobname = 'cleanup-expired-chess-rooms';

select cron.schedule(
  'cleanup-expired-chess-rooms',
  '* * * * *',
  $job$delete from public.chess_rooms where expires_at <= now();$job$
);

create or replace function public.append_chess_move(
  p_room_id uuid,
  p_player_id uuid,
  p_expected_ply integer,
  p_san text,
  p_finished boolean
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_room public.chess_rooms%rowtype;
  expected_player uuid;
  updated_room public.chess_rooms%rowtype;
begin
  select * into current_room
  from public.chess_rooms
  where id = p_room_id
  for update;

  if not found or current_room.status <> 'active' then
    raise exception 'This match is no longer active.' using errcode = 'P0001';
  end if;

  if current_room.expires_at <= clock_timestamp() then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  if p_player_id <> current_room.host_id and p_player_id <> current_room.guest_id then
    raise exception 'You are not a player in this match.' using errcode = '42501';
  end if;

  if current_room.ply <> p_expected_ply then
    raise exception 'The board changed. Refresh the match and try again.' using errcode = '40001';
  end if;

  expected_player := case when mod(current_room.ply, 2) = 0 then current_room.host_id else current_room.guest_id end;
  if p_player_id <> expected_player then
    raise exception 'It is the other player’s turn.' using errcode = '42501';
  end if;

  update public.chess_rooms
  set moves = array_append(moves, p_san),
      ply = ply + 1,
      status = case when p_finished then 'finished' else 'active' end,
      updated_at = now()
  where id = p_room_id and ply = p_expected_ply and expires_at > clock_timestamp()
  returning * into updated_room;

  if not found then
    raise exception 'This room link has expired. Please create a new room.' using errcode = 'P0001';
  end if;

  return to_jsonb(updated_room);
end;
$$;
