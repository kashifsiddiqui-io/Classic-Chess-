-- Integer literals do not implicitly resolve the smallint parameter in this
-- PL/pgSQL function call, so cast the initial cycle to match scribble_make_turn.
alter table public.scribble_rooms alter column invite_expires_at drop not null;

create or replace function public.scribble_start_room(p_room_id uuid, p_user_id uuid, p_cycles smallint default 3)
returns jsonb language plpgsql security definer set search_path = '' as $function$
declare
  room public.scribble_rooms%rowtype;
  roster uuid[];
  turn_id uuid;
begin
  if p_cycles not between 1 and 5 then
    raise exception 'Cycles must be between one and five.' using errcode = '22023';
  end if;

  select * into room from public.scribble_rooms where id = p_room_id for update;
  if not found or room.status <> 'waiting' or room.invite_expires_at <= clock_timestamp() then
    raise exception 'This room can no longer start.' using errcode = 'P0001';
  end if;
  if room.host_id <> p_user_id then
    raise exception 'Only the host can start the game.' using errcode = '42501';
  end if;

  select array_agg(user_id order by gen_random_uuid()) into roster
  from public.scribble_members where room_id = p_room_id and status = 'active';
  if cardinality(roster) < 2 then
    raise exception 'At least two players are needed to start.' using errcode = 'P0001';
  end if;

  turn_id := public.scribble_make_turn(p_room_id, 1, 1::smallint, roster[1]);
  update public.scribble_rooms set status = 'active', phase = 'choosing', cycles = p_cycles,
    turn_number = 1, cycle_number = 1, turn_order = roster, drawn_this_cycle = '{}', current_drawer_id = roster[1],
    current_turn_id = turn_id, phase_deadline = now() + make_interval(secs => choose_seconds),
    invite_expires_at = null, started_at = now(), state_version = state_version + 1, updated_at = now()
  where id = p_room_id returning * into room;

  return to_jsonb(room);
end
$function$;
